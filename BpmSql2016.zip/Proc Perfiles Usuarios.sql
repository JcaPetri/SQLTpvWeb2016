-- DE CADA USUARIO SUS PERFILES
				SELECT [GUS01_COD]
					  ,[GUS01_USUID]
					  ,[GUS01_ABR]
					  ,[GUS01_APE]
					  ,[GUS01_NOM]
				--	  ,[GUS01_CLAV]
				--	  ,[GUS03_PERTIPO]
					  ,[GPR03_PROCID_FK]
					  ,[GUS03_PERABR]
					  ,[GUS02_PERCOD]
					  ,[GUS03_PERDESC]
				  FROM [PVTWEB].[dbo].[GUS01_USUACT] AS USU WITH (NOLOCK)
					INNER JOIN (
								 SELECT [GUS02_USUCOD]
									  ,[GUS02_PERCOD]
									  ,[GUS03_PERTIPO]
									  ,[GUS03_PERABR]
									  ,[GUS03_PERDESC]
									  ,[GPR03_PROCID_FK]
								 FROM [PVTWEB].[dbo].[GUS02_USUPER] AS UP WITH (NOLOCK) 
									INNER JOIN (SELECT [GUS03_PERCOD]
														   ,[GUS03_PERTIPO]
														   ,[GUS03_PERABR]
														   ,[GUS03_PERDESC]
														   ,[GPR03_PROCID_FK]
													  FROM [PVTWEB].[dbo].[GUS03_PERFIL] WITH (NOLOCK)
														WHERE [GUS03_PERTIPO] = 'PROCESOS'
--																	AND [GPR03_PROCID_FK] = @PAR1
													) AS PER ON
														UP.[GUS02_PERCOD] = PER.[GUS03_PERCOD]
								) AS USPE ON
							USU.[GUS01_COD] = USPE.[GUS02_USUCOD]	
--				  WHERE USU.[GUS01_ABR] = UPPER(@PAR3)