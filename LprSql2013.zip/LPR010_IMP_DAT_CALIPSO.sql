-- ##################################################################################################################################
-- INICIO -- ACTUALIZA LA LISTA DE PRECIOS DESDE CALIPSO
-- ##################################################################################################################################
-- ###################################################################################################################################
-- INICIO - ACTCC_PASO 1
-- ###################################################################################################################################
DECLARE @NUEVOIDACT AS NVARCHAR(36) 
DECLARE @PROCNUM AS NUMERIC(18,0)

-- GENERA EL CODIGO PARA ESTE PROCESO, ESTO PERMITE QUE EN CADA ETAPA SEPARADA CARGUE EL MISMO CODIGO
-- PRIMERO BORRA EL CODIGO DEL PROCESO, ES POR LAS DUDAS SI HUBIERE
DELETE FROM [PVTWEB].[dbo].[GRL098_PROCLAVE] WHERE [GRL098_PROC] = 'LPR_ACT'
INSERT INTO [PVTWEB].[dbo].[GRL098_PROCLAVE]
           ([GRL098_PROC]
           ,[GRL098_PROCNUM])
       SELECT 'LPR_ACT', REPLACE(REPLACE(REPLACE(CONVERT(NVARCHAR(20), GETDATE(), 120), '-', ''), ':', ''), ' ', '')

-- TOMA EL COGIDO DEL PROCESO VIGENTE
-- GENERA EL CODIGO DE LA SUBETAPA PARA LUEGO PODER CARGARLE EL TIEMPO DE FINALIZACION
SET @PROCNUM  = (SELECT TOP 1 [GRL098_PROCNUM] FROM [PVTWEB].[dbo].[GRL098_PROCLAVE] WITH(NOLOCK) WHERE [GRL098_PROC] = 'LPR_ACT')
SET @NUEVOIDACT = NEWID()	-- MARCA TIEMPO DE INICIO

INSERT INTO [PVTWEB].[dbo].[GRL099_ACTREG]
			([GRL099_CODID], [GRL099_PROC], [GRL099_PROCORD], [GRL099_PROCNUM], [GRL099_SUBPROC], [GRL099_ACTPROC], [GRL099_OBJAFEC], [GRL099_PROCDESC]              , [GRL099_FECINIC]                , [GRL099_FECFIN])
	 SELECT  @NUEVOIDACT   , 'LPR_ACT'   , 1                 , @PROCNUM      , 'LPR_IMPDAT'   , 'LPR_DATBORR'  , '[LPR050_LPRCAL]'  , 'Elimina datos de [LPR050_LPRCAL]', CAST(GETDATE() AS DATETIME), NULL
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
-- ELIMINA LA LISTA DE PRECIOS VIEJA
DELETE FROM [PVTWEB].[dbo].[LPR050_LPRCAL]
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
UPDATE [PVTWEB].[dbo].[GRL099_ACTREG] SET [GRL099_FECFIN] = CAST(GETDATE() AS DATETIME) WHERE [GRL099_CODID] = @NUEVOIDACT
-- ###################################################################################################################################
-- FIN - ACTCC_PASO 1
-- ###################################################################################################################################


-- ###################################################################################################################################
-- INICIO - ACTCC_PASO 2
-- ###################################################################################################################################
--DECLARE @NUEVOIDACT AS NVARCHAR(36) 
--DECLARE @PROCNUM AS NUMERIC(18,0)

-- TOMA EL COGIDO DEL PROCESO VIGENTE
-- GENERA EL CODIGO DE LA SUBETAPA PARA LUEGO PODER CARGARLE EL TIEMPO DE FINALIZACION
SET @PROCNUM  = (SELECT TOP 1 [GRL098_PROCNUM] FROM [PVTWEB].[dbo].[GRL098_PROCLAVE] WITH(NOLOCK) WHERE [GRL098_PROC] = 'LPR_ACT')
SET @NUEVOIDACT = NEWID()	-- MARCA TIEMPO DE INICIO

INSERT INTO [PVTWEB].[dbo].[GRL099_ACTREG]	
	([GRL099_CODID], [GRL099_PROC], [GRL099_PROCORD], [GRL099_PROCNUM], [GRL099_SUBPROC], [GRL099_ACTPROC], [GRL099_OBJAFEC], [GRL099_PROCDESC], [GRL099_FECINIC], [GRL099_FECFIN]) 
	 SELECT @NUEVOIDACT, 'LPR_ACT', 2, @PROCNUM, 'LPR_IMPDAT', 'LPR_DATIMP', '[LPR050_LPRCAL]', 'Importa datos de [LPR050_LPRCAL]', CAST(GETDATE() AS DATETIME), NULL
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
-- INSERTA LA LISTA DE PRECIOS
INSERT INTO [PVTWEB].[dbo].[LPR050_LPRCAL]
           ([LPR050_BOPLACE]
		   ,[LPR050_LPEMPR]
           ,[LPR050_ARTMCA]
           ,[LPR050_ARTID]
           ,[LPR050_ARTCOD]
           ,[LPR050_ARTDESC]
           ,[LPR050_ARTCODALT]
           ,[LPR050_ARTRUBRO]
           ,[LPR050_ARTHON]
           ,[LPR050_PCLNETO])
		SELECT [LPR050_BOPLACE]
			  ,[LPEMPR]
			  ,[LPR050_ARTMCA]
			  ,[LPR050_ARTID]
			  ,[LPR050_ARTCOD]
			  ,[LPR050_ARTDESC]
			  ,[LPR050_ARTCODALT]
			  ,[LPR050_ARTRUBRO]
			  ,[LPR050_ARTHON]
			  ,[LPR050_PCLNETO]
		  FROM [SYS-REPLICA].[CalipsoReplicado].[dbo].[JCP_VP_LPR]
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
UPDATE [PVTWEB].[dbo].[GRL099_ACTREG] SET [GRL099_FECFIN] = CAST(GETDATE() AS DATETIME) WHERE [GRL099_CODID] = @NUEVOIDACT
-- ###################################################################################################################################
-- FIN - ACTCC_PASO 2	-- ACTUALIZA LA LISTA DE PRECIOS DESDE CALIPSO
-- ###################################################################################################################################


---- LISTA DE MARCAS DE CADA PIEZA
--SELECT  TOP 50 ALIAS_0.ID AS [MARCA_ID]
----		, ALIAS_0.ACTIVESTATUS ALIAS_0_ACTIVESTATUS
--		, ALIAS_0.CODIGO [MARCA_COD]
--		, ALIAS_0.NOMBRE [MARCA_NOMB]
----		, ALIAS_1.NOMBRE ALIAS_1_NOMBRE 
--FROM   V_ITEMTIPOCLASIFICADOR_ ALIAS_0  
--		LEFT OUTER JOIN V_TIPOCLASIFICADOR_ ALIAS_1 
--			ON ALIAS_0.PLACEOWNER_ID = ALIAS_1.ID  
--WHERE ALIAS_0.BO_PLACE_ID = '{3B191666-544A-442C-A7F3-EE347D6FB187}' 

--SELECT TOP 100 * 
--FROM [CalipsoReplicado].[dbo].[V_PRECIO_]
--
--SELECT ALIAS_0.BO_PLACE_ID, COUNT(*) AS TOTAL
--FROM [CalipsoReplicado].[dbo].[V_PRECIO_] AS ALIAS_0  
--GROUP BY ALIAS_0.BO_PLACE_ID
----51F08CF1-6E48-499F-9018-119408BEC11F	1
----FC056329-D20F-49DC-87FE-2D4D700E85FA	26992	RENAUL
----9BB36DDC-65DF-490C-AC31-8E07295EA30B	3148	NIXA
----2F9A92F4-F5D2-47A9-816E-966DFF804B27	49
----9A7D0DED-0A93-4F0C-8D87-99EC047634BE	26
----CC25BA53-0B6B-400A-A0DD-A5C1864AF684	120
----66E4A3D4-6F39-4DF1-99E3-EECFA1DC3C05	6

