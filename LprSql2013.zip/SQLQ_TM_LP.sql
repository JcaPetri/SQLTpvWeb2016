SELECT TOP 100 [TM_LPR_SERVIC]
           ,[TM_LPR_TIPSER]
           ,[TM_LPR_TIPSUS]
           ,[TM_LPR_TSERLP]
           ,[TM_LPR_VEHCOD]
           ,[TM_LPR_VEHMOD]
           ,[TM_LPR_VEHMOT]
           ,[TM_LPR_VEHMTIP]
           ,[TM_LPR_REFTIP]
           ,[TM_LPR_REFTEC]
           ,[TM_LPR_ARTREF]
           ,[TM_LPR_ARTDESC]
           ,[TM_LPR_ARTCANT]
           ,[TM_LPR_ARTCOST]
           ,[TM_LPR_ARTSUBT]
           ,[TM_LPR_ARTIVA]
           ,[TM_LPR_ARTTOTAL]
           ,[TM_LPR_DIFPRTIMOA]
FROM [TPV].[dbo].[TM_LPR]
WHERE TM_LPR_VEHCOD = 2 AND [TM_LPR_SERVIC] = 'STI 010k TAGLE' AND [TM_LPR_TIPSER] = 'STI 010k B�sico' AND ([TM_LPR_REFTIP] = 'MO' OR [TM_LPR_REFTIP] = 'MOA')





SELECT TOP 100 MIN([TM_LPR_ORDEN]) AS [TM_LPR_ORDEN] 
		   ,[TM_LPR_SERVIC]
           ,[TM_LPR_TIPSER]
           ,[TM_LPR_TIPSUS]
           ,[TM_LPR_TSERLP]
           ,[TM_LPR_VEHCOD]
           ,[TM_LPR_VEHMOD]
           ,[TM_LPR_VEHMOT]
           ,[TM_LPR_VEHMTIP]
           ,CASE [TM_LPR_REFTIP] WHEN 'MOA' THEN 'MO' ELSE [TM_LPR_REFTIP] END AS [TM_LPR_REFTIP]	
           ,[TM_LPR_REFTEC]
           ,[TM_LPR_ARTREF]
           ,[TM_LPR_ARTDESC]
           ,[TM_LPR_ARTCANT]
		   ,ROUND(SUM([TM_LPR_ARTSUBT]) / [TM_LPR_ARTCANT],2) AS [TM_LPR_ARTCOST]
           ,SUM([TM_LPR_ARTSUBT]) AS [TM_LPR_ARTSUBT]
		   ,ROUND(SUM([TM_LPR_ARTSUBT]) * 0.21,2) AS [TM_LPR_ARTTOTAL]
		   ,ROUND(SUM([TM_LPR_ARTSUBT]) * 1.21,2) AS [TM_LPR_DIFPRTIMOA]
FROM [TPV].[dbo].[TM_LPR]
GROUP BY [TM_LPR_SERVIC]
           ,[TM_LPR_TIPSER]
           ,[TM_LPR_TIPSUS]
           ,[TM_LPR_TSERLP]
           ,[TM_LPR_VEHCOD]
           ,[TM_LPR_VEHMOD]
           ,[TM_LPR_VEHMOT]
		   ,[TM_LPR_VEHMTIP]
		   ,CASE [TM_LPR_REFTIP] WHEN 'MOA' THEN 'MO' ELSE [TM_LPR_REFTIP] END 
		   ,[TM_LPR_REFTEC]
           ,[TM_LPR_ARTREF]
           ,[TM_LPR_ARTDESC]
           ,[TM_LPR_ARTCANT]
HAVING CASE [TM_LPR_REFTIP] WHEN 'MOA' THEN 'MO' ELSE [TM_LPR_REFTIP] END = 'MO' 
ORDER BY MIN([TM_LPR_ORDEN])


-- CONSULTA FINAL PARA SISTEMAS
SELECT TOP 15000 *
FROM (SELECT [TM_LPR_ORDEN]
		   ,[TM_LPR_SERVIC]
		   ,[TM_LPR_TIPSER]
           ,[TM_LPR_TIPSUS]
           ,[TM_LPR_TSERLP]
           ,[TM_LPR_VEHCOD]
           ,[TM_LPR_VEHMOD]
           ,[TM_LPR_VEHMOT]
           ,[TM_LPR_VEHMTIP]
           ,[TM_LPR_REFTIP]
           ,[TM_LPR_REFTEC]
           ,[TM_LPR_ARTREF]
           ,[TM_LPR_ARTDESC]
           ,[TM_LPR_ARTCANT]
           ,[TM_LPR_ARTCOST]
           ,[TM_LPR_ARTSUBT]
           ,[TM_LPR_ARTIVA]
           ,[TM_LPR_ARTTOTAL]
	FROM [TPV].[dbo].[TM_LPR]
	WHERE CASE [TM_LPR_REFTIP] WHEN 'MOA' THEN 'MO' ELSE [TM_LPR_REFTIP] END <> 'MO' 
	UNION ALL
	SELECT MIN([TM_LPR_ORDEN]) AS [TM_LPR_ORDEN] 
		   ,[TM_LPR_SERVIC]
           ,[TM_LPR_TIPSER]
           ,[TM_LPR_TIPSUS]
           ,[TM_LPR_TSERLP]
           ,[TM_LPR_VEHCOD]
           ,[TM_LPR_VEHMOD]
           ,[TM_LPR_VEHMOT]
           ,[TM_LPR_VEHMTIP]
           ,CASE [TM_LPR_REFTIP] WHEN 'MOA' THEN 'MO' ELSE [TM_LPR_REFTIP] END AS [TM_LPR_REFTIP]	
           ,[TM_LPR_REFTEC]
           ,[TM_LPR_ARTREF]
           ,[TM_LPR_ARTDESC]
           ,[TM_LPR_ARTCANT]
		   ,ROUND(SUM([TM_LPR_ARTSUBT]) / [TM_LPR_ARTCANT],2) AS [TM_LPR_ARTCOST]
           ,SUM([TM_LPR_ARTSUBT]) AS [TM_LPR_ARTSUBT]
		   ,ROUND(SUM([TM_LPR_ARTSUBT]) * 0.21,2) AS [TM_LPR_ARTTOTAL]
		   ,ROUND(SUM([TM_LPR_ARTSUBT]) * 1.21,2) AS [TM_LPR_DIFPRTIMOA]
	FROM [TPV].[dbo].[TM_LPR]
	GROUP BY [TM_LPR_SERVIC]
           ,[TM_LPR_TIPSER]
           ,[TM_LPR_TIPSUS]
           ,[TM_LPR_TSERLP]
           ,[TM_LPR_VEHCOD]
           ,[TM_LPR_VEHMOD]
           ,[TM_LPR_VEHMOT]
		   ,[TM_LPR_VEHMTIP]
		   ,CASE [TM_LPR_REFTIP] WHEN 'MOA' THEN 'MO' ELSE [TM_LPR_REFTIP] END 
		   ,[TM_LPR_REFTEC]
           ,[TM_LPR_ARTREF]
           ,[TM_LPR_ARTDESC]
           ,[TM_LPR_ARTCANT]
	HAVING CASE [TM_LPR_REFTIP] WHEN 'MOA' THEN 'MO' ELSE [TM_LPR_REFTIP] END = 'MO' 
	) AS LPR
WHERE [TM_LPR_ARTREF] <> 'PP Rep' AND [TM_LPR_ARTREF] <> 'PP Final'
ORDER BY [TM_LPR_ORDEN]












SELECT *
FROM [TPV].[dbo].[TM_GRL_VEH]




