--#################################################################################################################
-- INICIO -- ###### ACTUALIZA EL C�DIGO REAL DE LAS PIEZAS
--#################################################################################################################
UPDATE [TPV].[dbo].[LPR112_LPSTIEST]
   SET [LPR112_PIEZCOD] = [LPR05_LPR_PIEZCOD]
--	SELECT [LPR112_LPRCOD]
--		,[LPR112_LPRDES]
--		,[LPR05_LPR_PIEZCOD]
	FROM [TPV].[dbo].[LPR112_LPSTIEST] AS LPTI 
		INNER JOIN (SELECT [LPR05_LPR_PIEZCOD]
						  ,[LPR05_LPR_PIEZEST]
						  ,[LPR05_LPRCOD]
						  ,[LPR05_LPRDES]
						  ,[LPR05_LPRCDT]
						  ,[LPR05_LPRCDTO]
						  ,[LPR05_LPRPRECIO]
						  ,[LPR05_LPRMARC]
					  FROM [TPV].[dbo].[LPR05_LISTPR]) AS LP ON
			LPTI.[LPR112_LPRCOD] = LP.[LPR05_LPRCOD]

-- VERIFICA LAS PIEZAS QUE NO TIENEN C�DIGO EN CALIPSO
SELECT TOP 100 *
FROM [TPV].[dbo].[LPR05_LISTPR]
WHERE [LPR05_LPRCOD] IN (SELECT [LPR112_LPRCOD]
--							  ,[LPR112_LPRDES]
--							  ,COUNT([LPR112_SSTICANT]) AS CANT
						FROM [TPV].[dbo].[LPR112_LPSTIEST]
						WHERE [LPR112_PIEZCOD] IS NULL	AND [LPR112_REFTIP] <> 'MO'
						GROUP BY [LPR112_LPRCOD]
							  ,[LPR112_LPRDES])
--					
--130C12131R I ESTA EN LA BASE
--130C13191R I ESTA EN LA BASE
--
--SELECT *
--FROM [TPV].[dbo].[LPR05_LISTPR]
--WHERE [LPR05_LPRCOD] = '130C16514R I' OR [LPR05_LPRCODREMP] LIKE '%130C16514R%'  OR [LPR05_LPRPIEREMPI] LIKE '%130C16514R%'

--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- ACTUALIZA EL CODIGO DE LAS PIEZAS DE LA TABLA PAD X MOTOR
UPDATE [TPV].[dbo].[LPR114_PADxMOT]
   SET [LPR114_PIEZCOD] = [LPR05_LPR_PIEZCOD]
      ,[LPR114_LPRDES] = [LPR05_LPRDES]
--SELECT [LPR05_LPR_PIEZCOD]
--	  ,[LPR114_LPRCOD]
--	  ,[LPR05_LPRDES]
	FROM [TPV].[dbo].[LPR114_PADxMOT] AS PM 
		INNER JOIN (SELECT [LPR05_LPR_PIEZCOD]
						  ,[LPR05_LPR_PIEZEST]
						  ,[LPR05_LPRCOD]
						  ,[LPR05_LPRDES]
						  ,[LPR05_LPRCDT]
						  ,[LPR05_LPRCDTO]
						  ,[LPR05_LPRPRECIO]
						  ,[LPR05_LPRMARC]
					  FROM [TPV].[dbo].[LPR05_LISTPR]) AS LP ON
			PM.[LPR114_LPRCOD] = LP.[LPR05_LPRCOD]

-- CONTROL DE LA ACTUALIZACI�N
SELECT *
FROM [TPV].[dbo].[LPR114_PADxMOT]


--#################################################################################################################
-- FIN -- ###### ACTUALIZA EL C�DIGO REAL DE LAS PIEZAS
--#################################################################################################################


--#################################################################################################################
-- INICIO -- ###### GENERA LA COMBINACI�N DE LOS SERVICIOS STI Basicos
--#################################################################################################################
DELETE FROM [TPV].[dbo].[LPR110_LPSTI] WHERE [LPR110_TIPSERV] LIKE '%Basico'

INSERT INTO [TPV].[dbo].[LPR110_LPSTI]
           ([LPR110_TIPSERV]
           ,[LPR110_VEHCOD])
SELECT TS.[LPR108_TIPSERV]
	  ,VH.[TM_GRL_VEHCOD]
--	  ,[TM_GRL_VEHMOD]
--	  ,[TM_GRL_VEHMOT]
--	  ,[TM_GRL_VEHMTIP]
FROM (SELECT [LPR108_TIPSERV]
			 ,[LPR108_TSERCLA]
			 ,1 AS N
		FROM [TPV].[dbo].[LPR108_SSTIP]) AS TS 
	INNER JOIN (SELECT [TM_GRL_VEHORD]
						  ,[TM_GRL_VEHCOD]
						  ,[TM_GRL_VEHMOD]
						  ,[TM_GRL_VEHMOT]
						  ,[TM_GRL_VEHMTIP]
						  ,1 AS N
					  FROM [TPV].[dbo].[TM_GRL_VEH]) AS VH ON 
			TS.N = VH.N
WHERE TS.[LPR108_TSERCLA] = 'STI Basico'
ORDER BY TS.[LPR108_TIPSERV]
		,VH.[TM_GRL_VEHCOD]

-- VERIFICA INSERT
SELECT [LPR110_TIPSERV]
      ,[LPR110_VEHCOD]
      ,[LPR110_STIPRE]
  FROM [TPV].[dbo].[LPR110_LPSTI]
WHERE [LPR110_TIPSERV] LIKE '%Basico'
ORDER BY [LPR110_TIPSERV]
      ,[LPR110_VEHCOD]

-- LUEGO DE IMPORTAR A LA BASE ACTPRE, LOS PRECIOS DE RENAULT SE ACTUALIZA LA LPSTI
UPDATE [TPV].[dbo].[LPR110_LPSTI]
   SET [LPR110_STIPRE] = LPA.[LPR110_STIPRE]
 FROM [TPV].[dbo].[LPR110_LPSTI] AS LPD
	INNER JOIN (SELECT [LPR110_TIPSERV]
					  ,[LPR110_VEHCOD]
					  ,[LPR110_STIPRE]
				  FROM [TPV].[dbo].[LPR111_LPSTI_ACTPRE]) AS LPA ON 
		LPD.[LPR110_TIPSERV] = LPA.[LPR110_TIPSERV]
			AND
		LPD.[LPR110_VEHCOD] = LPA.[LPR110_VEHCOD]
	WHERE LPD.[LPR110_TIPSERV] LIKE '%Basico'

-- BORRA LOS VALORES IMPORTADOS
DELETE FROM [TPV].[dbo].[LPR111_LPSTI_ACTPRE]

-- VERIFICA LOS SERVICIOS / VEH�CULOS QUE NO SE ACTUALIZARON LOS PRECIOS
SELECT [LPR110_TIPSERV]
	  ,[LPR110_VEHCOD]
	  ,[TM_GRL_VEHMOD]
	  ,[TM_GRL_VEHMOT]
	  ,[TM_GRL_VEHMTIP]
	  ,[TM_GRL_VEHEST]
 FROM [TPV].[dbo].[LPR110_LPSTI] AS LP
	INNER JOIN (SELECT [TM_GRL_VEHORD]
						  ,[TM_GRL_VEHCOD]
						  ,[TM_GRL_VEHMOD]
						  ,[TM_GRL_VEHMOT]
						  ,[TM_GRL_VEHMTIP]
						  ,[TM_GRL_VEHEST]
						  ,1 AS N
					  FROM [TPV].[dbo].[TM_GRL_VEH]) AS VH ON 
			LP.[LPR110_VEHCOD] = VH.[TM_GRL_VEHCOD]
WHERE [LPR110_STIPRE] IS NULL


-- AGREGA LOS REPUESTOS POR MOTOR
INSERT INTO [TPV].[dbo].[LPR112_LPSTIEST]
           ([LPR112_TIPSERV]
           ,[LPR112_VEHCOD]
           ,[LPR112_REFTIP]
           ,[LPR112_PIEZCOD]
           ,[LPR112_LPRCOD]
           ,[LPR112_LPRDES]
           ,[LPR112_SSTICANT])
SELECT LPT.[LPR110_TIPSERV]
	  ,LPT.[LPR110_VEHCOD]
	  ,'REP' AS REFTIP
	  ,VM.[LPR114_PIEZCOD]
	  ,VM.[LPR114_LPRCOD]
	  ,VM.[LPR114_LPRDES]
	  ,VM.[LPR114_SSTICANT]
FROM (SELECT [LPR110_TIPSERV]
			  ,[LPR110_VEHCOD]
			  ,[TM_GRL_VEHMOD]
			  ,[TM_GRL_VEHMOT]
			  ,[TM_GRL_VEHMTIP]
			  ,[TM_GRL_VEHEST]
		 FROM [TPV].[dbo].[LPR110_LPSTI] AS LP
			INNER JOIN (SELECT [TM_GRL_VEHORD]
							  ,[TM_GRL_VEHCOD]
							  ,[TM_GRL_VEHMOD]
							  ,[TM_GRL_VEHMOT]
							  ,[TM_GRL_VEHMTIP]
							  ,[TM_GRL_VEHEST]
							  ,1 AS N
						  FROM [TPV].[dbo].[TM_GRL_VEH]) AS VH ON 
					LP.[LPR110_VEHCOD] = VH.[TM_GRL_VEHCOD]
		WHERE LP.[LPR110_TIPSERV] LIKE '%Basico'
	) AS LPT
		INNER JOIN (SELECT [LPR114_VEHMOT]
							  ,[LPR114_PIEZCOD]
							  ,[LPR114_LPRCOD]
							  ,[LPR114_LPRDES]
							  ,[LPR114_SSTICANT]
						  FROM [TPV].[dbo].[LPR114_PADxMOT]) AS VM ON 
					LPT.[TM_GRL_VEHMOT] = VM.[LPR114_VEHMOT]
ORDER BY LPT.[LPR110_TIPSERV]
	  ,LPT.[LPR110_VEHCOD]

--#################################################################################################################
-- CONSULTA DE LOS STI B�SICOS, PRECIOS
SELECT [LPR110_TIPSERV]
      ,[LPR110_VEHCOD]
	  ,[TM_GRL_VEHMOD]
	  ,[TM_GRL_VEHMOT]
	  ,[TM_GRL_VEHMTIP]
      ,[LPR110_STIPRE]
  FROM [TPV].[dbo].[LPR110_LPSTI] AS LP
	INNER JOIN (SELECT [TM_GRL_VEHORD]
						  ,[TM_GRL_VEHCOD]
						  ,[TM_GRL_VEHMOD]
						  ,[TM_GRL_VEHMOT]
						  ,[TM_GRL_VEHMTIP]
						  ,[TM_GRL_VEHEST]
					  FROM [TPV].[dbo].[TM_GRL_VEH]
					  WHERE [TM_GRL_VEHEST] = 'VIGENTE') AS VH ON 
			LP.[LPR110_VEHCOD] = VH.[TM_GRL_VEHCOD]
WHERE LP.[LPR110_TIPSERV] LIKE '%Basico'
ORDER BY LP.[LPR110_TIPSERV]
      ,LP.[LPR110_VEHCOD]

-- CONSULTA DE LA ESTRUCTURA DE LOS STI B�SICOS
SELECT LP.[LPR112_TIPSERV]
      ,LP.[LPR112_VEHCOD]
	  ,VH.[TM_GRL_VEHMOD]
	  ,VH.[TM_GRL_VEHMOT]
	  ,VH.[TM_GRL_VEHMTIP]
      ,LP.[LPR112_REFTIP]
      ,LP.[LPR112_PIEZCOD]
      ,LP.[LPR112_LPRCOD]
      ,LP.[LPR112_LPRDES]
      ,LP.[LPR112_SSTICANT]
  FROM [TPV].[dbo].[LPR112_LPSTIEST] AS LP
	INNER JOIN (SELECT [TM_GRL_VEHORD]
					  ,[TM_GRL_VEHCOD]
					  ,[TM_GRL_VEHMOD]
					  ,[TM_GRL_VEHMOT]
					  ,[TM_GRL_VEHMTIP]
					  ,[TM_GRL_VEHEST]
				  FROM [TPV].[dbo].[TM_GRL_VEH]
				  WHERE [TM_GRL_VEHEST] = 'VIGENTE') AS VH ON 
			LP.[LPR112_VEHCOD] = VH.[TM_GRL_VEHCOD]
WHERE LP.[LPR112_TIPSERV] LIKE '%Basico'
ORDER BY LP.[LPR112_TIPSERV]
        ,LP.[LPR112_VEHCOD]
--#################################################################################################################
-- FIN -- ###### GENERA LA COMBINACI�N DE LOS SERVICIOS STI Basicos
--#################################################################################################################




--#################################################################################################################
-- INICIO -- ###### GENERA LA COMBINACI�N DE LOS SERVICIOS STI Adicional Premium
--#################################################################################################################
DELETE FROM [TPV].[dbo].[LPR110_LPSTI] WHERE [LPR110_TIPSERV] LIKE '%Ad.Premium'

INSERT INTO [TPV].[dbo].[LPR110_LPSTI]
           ([LPR110_TIPSERV]
           ,[LPR110_VEHCOD])
SELECT TS.[LPR108_TIPSERV]
	  ,VH.[TM_GRL_VEHCOD]
--	  ,[TM_GRL_VEHMOD]
--	  ,[TM_GRL_VEHMOT]
--	  ,[TM_GRL_VEHMTIP]
FROM (SELECT [LPR108_TIPSERV]
			 ,[LPR108_TSERCLA]
			 ,1 AS N
		FROM [TPV].[dbo].[LPR108_SSTIP]) AS TS 
	INNER JOIN (SELECT [TM_GRL_VEHORD]
						  ,[TM_GRL_VEHCOD]
						  ,[TM_GRL_VEHMOD]
						  ,[TM_GRL_VEHMOT]
						  ,[TM_GRL_VEHMTIP]
						  ,1 AS N
					  FROM [TPV].[dbo].[TM_GRL_VEH]) AS VH ON 
			TS.N = VH.N
WHERE TS.[LPR108_TSERCLA] = 'STI Adic.Premium'
ORDER BY TS.[LPR108_TIPSERV]
		,VH.[TM_GRL_VEHCOD]

-- VERIFICA INSERT
SELECT [LPR110_TIPSERV]
      ,[LPR110_VEHCOD]
      ,[LPR110_STIPRE]
  FROM [TPV].[dbo].[LPR110_LPSTI]
WHERE [LPR110_TIPSERV] LIKE '%Premium'
ORDER BY [LPR110_TIPSERV]
      ,[LPR110_VEHCOD]

--#################################################################################################################
-- FIN -- ###### GENERA LA COMBINACI�N DE LOS SERVICIOS STI Adicional Premium
--#################################################################################################################


--#################################################################################################################
-- INICIO -- ###### GENERA LOS SERVICIOS STI Adicional Premium
--#################################################################################################################
UPDATE [TPV].[dbo].[LPR110_LPSTI]
   SET [LPR110_STIPRE] = CAST(LSP.[PRSERV] AS DECIMAL(18,0))
FROM [TPV].[dbo].[LPR110_LPSTI] AS LST 
	INNER JOIN (
		SELECT LPP.[LPR110_TIPSERV]
			  ,LPP.[LPR110_VEHCOD]
			  ,LPP.[TM_GRL_VEHMOD]
			  ,LPP.[TM_GRL_VEHMOT]
			  ,LPP.[TM_GRL_VEHMTIP]
			  ,SUM(LPP.[PRSERV]) AS PRSERV
		FROM (SELECT SP.[LPR110_TIPSERV]
				  ,SP.[LPR110_VEHCOD]
				  ,VH.[TM_GRL_VEHMOD]
				  ,VH.[TM_GRL_VEHMOT]
				  ,VH.[TM_GRL_VEHMTIP]
				  ,MOS.[LPR118_MOCOD]
				  ,MOS.[LPR118_MOTPOHS]
				  ,MOS.[PRSERV]
				  ,SP.[LPR110_STIPRE]
			  FROM [TPV].[dbo].[LPR110_LPSTI] AS SP
				INNER JOIN (SELECT [LPR118_VEHCOD]
								  ,[LPR118_MOCOD]
								  ,[LPR118_MOTPOHS]
								  ,[LPR116_MOPRExH]
								  ,CAST((([LPR118_MOTPOHS] * [LPR116_MOPRExH])/60) AS DECIMAL(18,2)) AS 'PRSERV'
							  FROM [TPV].[dbo].[LPR118_MOSER] AS MS 
								INNER JOIN (SELECT [LPR116_MOCOD]
												  ,[LPR116_MOPRExH]
											  FROM [TPV].[dbo].[LPR116_MOPREC]) AS MOP ON
									MS.[LPR118_MOCOD] = MOP.[LPR116_MOCOD]) AS MOS ON
					SP.[LPR110_VEHCOD] = MOS.[LPR118_VEHCOD]
				INNER JOIN (SELECT [TM_GRL_VEHORD]
								  ,[TM_GRL_VEHCOD]
								  ,[TM_GRL_VEHMOD]
								  ,[TM_GRL_VEHMOT]
								  ,[TM_GRL_VEHMTIP]
							  FROM [TPV].[dbo].[TM_GRL_VEH]) AS VH ON
					SP.[LPR110_VEHCOD] = VH.[TM_GRL_VEHCOD]
				WHERE SP.[LPR110_TIPSERV] LIKE '%Ad.Premium') AS LPP
		GROUP BY LPP.[LPR110_TIPSERV]
			  ,LPP.[LPR110_VEHCOD]
			  ,LPP.[TM_GRL_VEHMOD]
			  ,LPP.[TM_GRL_VEHMOT]
			  ,LPP.[TM_GRL_VEHMTIP]
--		ORDER BY LPP.[LPR110_TIPSERV], LPP.[LPR110_VEHCOD]
		) AS LSP ON
		LST.[LPR110_TIPSERV] = LSP.[LPR110_TIPSERV]
			AND
		LST.[LPR110_VEHCOD] = LSP.[LPR110_VEHCOD]

--#################################################################################################################
-- CONSULTA DE LOS STI ADICIONALES PREMIUM
SELECT [LPR110_TIPSERV]
      ,[LPR110_VEHCOD]
	  ,[TM_GRL_VEHMOD]
	  ,[TM_GRL_VEHMOT]
	  ,[TM_GRL_VEHMTIP]
      ,[LPR110_STIPRE]
  FROM [TPV].[dbo].[LPR110_LPSTI] AS LP
	INNER JOIN (SELECT [TM_GRL_VEHORD]
						  ,[TM_GRL_VEHCOD]
						  ,[TM_GRL_VEHMOD]
						  ,[TM_GRL_VEHMOT]
						  ,[TM_GRL_VEHMTIP]
						  ,[TM_GRL_VEHEST]
					  FROM [TPV].[dbo].[TM_GRL_VEH]
					  WHERE [TM_GRL_VEHEST] = 'VIGENTE') AS VH ON 
			LP.[LPR110_VEHCOD] = VH.[TM_GRL_VEHCOD]
WHERE LP.[LPR110_TIPSERV] LIKE '%Basico'
ORDER BY LP.[LPR110_TIPSERV]
      ,LP.[LPR110_VEHCOD]

-- CONSULTA DE LA ESTRUCTURA DE LOS STI ADICIONALES PREMIUM
SELECT SP.[LPR110_TIPSERV]
	  ,SP.[LPR110_VEHCOD]
	  ,VH.[TM_GRL_VEHMOD]
	  ,VH.[TM_GRL_VEHMOT]
	  ,VH.[TM_GRL_VEHMTIP]
	  ,'MO' AS 'REFTIP'
	  ,MOS.[LPR118_MOCOD]
	  ,MOS.[LPR116_MODESC]
	  ,MOS.[LPR118_MOTPOHS]
	  ,CAST(MOS.[PRSERV] AS DECIMAL (18,0)) AS PRSERV
--	  ,SP.[LPR110_STIPRE]
  FROM [TPV].[dbo].[LPR110_LPSTI] AS SP
	INNER JOIN (SELECT [LPR118_VEHCOD]
					  ,[LPR118_MOCOD]
					  ,[LPR116_MODESC]
					  ,[LPR118_MOTPOHS]
					  ,[LPR116_MOPRExH]
					  ,CAST((([LPR118_MOTPOHS] * [LPR116_MOPRExH])/60) AS DECIMAL(18,2)) AS 'PRSERV'
				  FROM [TPV].[dbo].[LPR118_MOSER] AS MS 
					INNER JOIN (SELECT [LPR116_MOCOD]
									  ,[LPR116_MODESC]
									  ,[LPR116_MOPRExH]
								  FROM [TPV].[dbo].[LPR116_MOPREC]) AS MOP ON
						MS.[LPR118_MOCOD] = MOP.[LPR116_MOCOD]) AS MOS ON
		SP.[LPR110_VEHCOD] = MOS.[LPR118_VEHCOD]
	INNER JOIN (SELECT [TM_GRL_VEHORD]
					  ,[TM_GRL_VEHCOD]
					  ,[TM_GRL_VEHMOD]
					  ,[TM_GRL_VEHMOT]
					  ,[TM_GRL_VEHMTIP]
				  FROM [TPV].[dbo].[TM_GRL_VEH]) AS VH ON
		SP.[LPR110_VEHCOD] = VH.[TM_GRL_VEHCOD]
	WHERE SP.[LPR110_TIPSERV] LIKE '%Ad.Premium'
ORDER BY SP.[LPR110_TIPSERV]
	  ,SP.[LPR110_VEHCOD]
	  ,MOS.[LPR118_MOCOD]
--#################################################################################################################
-- FIN -- ###### GENERA LOS SERVICIOS STI Adicional Premium
--#################################################################################################################







--#################################################################################################################
-- INICIO -- ###### GENERA LOS SERVICIOS STI FUERA DE GARANT�A
--#################################################################################################################



SELECT [LPR112_TIPSERV]
      ,[LPR112_VEHCOD]
      ,[LPR112_REFTIP]
      ,[LPR112_PIEZCOD]
      ,[LPR112_LPRCOD]
      ,[LPR112_LPRDES]
      ,[LPR112_SSTICANT]
  FROM [TPV].[dbo].[LPR112_LPSTIEST]
WHERE [LPR112_TIPSERV] LIKE '%Basico' AND [LPR112_REFTIP] = 'MO'
ORDER BY [LPR112_TIPSERV]
      ,[LPR112_VEHCOD]



--#################################################################################################################
-- FIN -- ###### GENERA LOS SERVICIOS STI FUERA DE GARANT�A
--#################################################################################################################
