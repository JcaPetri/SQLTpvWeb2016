-- ###########################################################################################################################################
-- REPUESTOS PRESTADO - DEPOSITO COMERCIAL CORDOBA AL DEPOSITO DE GARANTIA CORDOBA
-- ###########################################################################################################################################
SELECT ALIAS_0.ID AS [RG030_REPDEUID]
		, ALIAS_0.NOMBRE AS [RG030_REPVALE]
		, ALIAS_0.NUMERO AS [RG030_VALENUM]
		, ALIAS_0.NOMBREDESTINATARIO AS [RG030_VALEDEST]
		, ALIAS_0.NOMBREORIGINANTE AS [RG030_DEPORIGEN]
		, ALIAS_1.NOMBRE AS [RG030_RDG]
		, ALIAS_0.SALDADA AS [RG030_ESTADO]
		, ALIAS_0.RELACIONTRORIG_ID AS [RG030_RELTRORIGID]
		, ALIAS_0.UNIDADOPERATIVA_ID AS [RG030_UNIDOPERID]
		, CAST(SUBSTRING(ALIAS_0.FECHATR, 7, 2) + '/' + SUBSTRING(ALIAS_0.FECHATR, 5, 2) + '/' + SUBSTRING(ALIAS_0.FECHATR, 1, 4) AS datetime) AS [RG030_FECHATR]
	    , ALIAS_2.VALORTOTAL AS [RG030_DEUDATOTAL]
		, ALIAS_4.NOMBRE AS [RG030_OTNUMCOMP]
		, ALIAS_4.NUMERODOCUMENTO AS [RG030_OTNUM]
		, ALIAS_4.DETALLE AS [RG030_VEHICULO]
-- SELECT TOP 100 ALIAS_4.*
--SELECT COUNT(*)
FROM   [CalipsoReplicado].[dbo].[V_PENDIENTE_] AS ALIAS_0  
	INNER JOIN [CalipsoReplicado].[dbo].[V_TREGRESOINVENTARIO_] AS ALIAS_2 ON 
		ALIAS_0.TRANSACCION_ID = ALIAS_2.ID   
	INNER JOIN [CalipsoReplicado].[dbo].[V_UD_VALEENTREGAPIEZAS_] AS ALIAS_3 ON 
		ALIAS_2.BOEXTENSION_ID = ALIAS_3.ID   
	INNER JOIN [CalipsoReplicado].[dbo].[V_TRORDENVENTA_] AS ALIAS_4 ON 
		ALIAS_3.OrdenTrabajo_ID = ALIAS_4.ID   
	LEFT OUTER JOIN [CalipsoReplicado].[dbo].[V_TRPROCESOPORLOTE_] AS ALIAS_5 ON 
		ALIAS_4.ID = ALIAS_5.TRANSACCION_ID   
	LEFT OUTER JOIN [CalipsoReplicado].[dbo].[V_AGENTEPROCESOPORLOTE_] AS ALIAS_6 ON 
		ALIAS_5.BO_PLACE_ID = ALIAS_6.TRSORIGEN_ID   
	LEFT OUTER JOIN [CalipsoReplicado].[dbo].[V_TRORDENVENTA_] AS ALIAS_1 ON 
		ALIAS_6.ID = ALIAS_1.GENERADAPOR_ID  
WHERE ALIAS_0.BO_PLACE_ID = '{260F1DE5-D1B2-450A-97A3-2F4C71EA22F6}'   
	AND  ( ALIAS_5.RELACION_ID = '{9090399B-EF8B-400E-BA0D-5A7F5F455D1F}'  OR  ALIAS_5.RELACION_ID IS NULL)  
	AND  ALIAS_0.SALDADA = 'F'  
	AND  ( ( ALIAS_0.RELACIONTRORIG_ID = '{364EE8C0-4B0B-4ACD-BA6C-00FA0F54603B}'  AND  (ALIAS_0.UNIDADOPERATIVA_ID = '{B1AC037C-4C42-4D20-8821-F135777A5F44}') ) )  
	AND ALIAS_0.NOMBREORIGINANTE = 'Deposito Comercial Cordoba'
	AND SUBSTRING(ALIAS_0.FECHATR, 1, 4) = '2015'
ORDER BY ALIAS_0.FECHATR DESC 
-- ###########################################################################################################################################
-- ###########################################################################################################################################



-- ###########################################################################################################################################
-- REPUESTOS PRESTADO - DEPOSITO COMERCIAL CORDOBA AL DEPOSITO DE GARANTIA CORDOBA
-- INFORME POR FECHA, SUMA TOTAL Y CANTIDAD
-- ###########################################################################################################################################
SELECT SUBSTRING(ALIAS_0.FECHATR, 1, 4) + '/' + SUBSTRING(ALIAS_0.FECHATR, 5, 2) AS FechaTR
--	CAST(SUBSTRING(ALIAS_0.FECHATR, 7, 2) + '/' + SUBSTRING(ALIAS_0.FECHATR, 5, 2) + '/' + SUBSTRING(ALIAS_0.FECHATR, 1, 4) AS datetime) AS FechaTR
	, SUM(ALIAS_2.VALORTOTAL) AS Total
	, COUNT(*) AS CANTPTE
FROM   [CalipsoReplicado].[dbo].[V_PENDIENTE_] AS ALIAS_0  
	INNER JOIN [CalipsoReplicado].[dbo].[V_TREGRESOINVENTARIO_] AS ALIAS_2 ON 
		ALIAS_0.TRANSACCION_ID = ALIAS_2.ID   
	INNER JOIN [CalipsoReplicado].[dbo].[V_UD_VALEENTREGAPIEZAS_] AS ALIAS_3 ON 
		ALIAS_2.BOEXTENSION_ID = ALIAS_3.ID   
	INNER JOIN [CalipsoReplicado].[dbo].[V_TRORDENVENTA_] AS ALIAS_4 ON 
		ALIAS_3.OrdenTrabajo_ID = ALIAS_4.ID   
	LEFT OUTER JOIN [CalipsoReplicado].[dbo].[V_TRPROCESOPORLOTE_] AS ALIAS_5 ON 
		ALIAS_4.ID = ALIAS_5.TRANSACCION_ID   
	LEFT OUTER JOIN [CalipsoReplicado].[dbo].[V_AGENTEPROCESOPORLOTE_] AS ALIAS_6 ON 
		ALIAS_5.BO_PLACE_ID = ALIAS_6.TRSORIGEN_ID   
	LEFT OUTER JOIN [CalipsoReplicado].[dbo].[V_TRORDENVENTA_] AS ALIAS_1 ON 
		ALIAS_6.ID = ALIAS_1.GENERADAPOR_ID  
WHERE ALIAS_0.BO_PLACE_ID = '{260F1DE5-D1B2-450A-97A3-2F4C71EA22F6}'   
	AND  ( ALIAS_5.RELACION_ID = '{9090399B-EF8B-400E-BA0D-5A7F5F455D1F}'  OR  ALIAS_5.RELACION_ID IS NULL)  
	AND  ALIAS_0.SALDADA = 'F'  
	AND  ( ( ALIAS_0.RELACIONTRORIG_ID = '{364EE8C0-4B0B-4ACD-BA6C-00FA0F54603B}'  AND  (ALIAS_0.UNIDADOPERATIVA_ID = '{B1AC037C-4C42-4D20-8821-F135777A5F44}') ) )  
	AND ALIAS_0.NOMBREORIGINANTE = 'Deposito Comercial Cordoba'
GROUP BY SUBSTRING(ALIAS_0.FECHATR, 1, 4) + '/' + SUBSTRING(ALIAS_0.FECHATR, 5, 2)
ORDER BY SUBSTRING(ALIAS_0.FECHATR, 1, 4) + '/' + SUBSTRING(ALIAS_0.FECHATR, 5, 2) DESC
-- ###########################################################################################################################################
-- ###########################################################################################################################################




SELECT TOP 100 *
FROM [CalipsoReplicado].[dbo].[V_PENDIENTE_] AS ALIAS_0 


--SELECT SALDADA, COUNT(*) AS CANT
--FROM [CalipsoReplicado].[dbo].[V_PENDIENTE_] AS ALIAS_0  
--GROUP BY SALDADA
--
--A, F, T
