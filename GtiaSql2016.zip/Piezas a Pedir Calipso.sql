

-- LISTADO DE PIEZAS PRESTAMO DEL DEPOSITO COMERCIAL A GARANTIA
SELECT TOP 10000 [OT010_OT_FECHA] 
 -- + '/' + SUBSTRING([OT010_OT_FECHA], 5, 2) + '/' + SUBSTRING([OT010_OT_FECHA], 1, 4) AS FechaOT
-- SUBSTRING([OT010_OT_FECHA],[OT010_OT_MES]
--      ,[OT010_OT_MESULTEST]
--      ,[OT010_OT_MESTUR]
--      ,[OT010_OT_ID]
      ,[OT010_OT_NUM]
--      ,[OT010_CLI_ID]
--      ,[OT010_CLI_COD]
--      ,[OT010_CLI_DESC]
--      ,[OT010_OT_FECHA]
--      ,[OT010_OT_FECULTEST]
      ,[OT010_OT_ESTADO]
--      ,[OT010_OT_FECVTAVN]
--      ,[OT010_OT_FECTURN]
--      ,[OT010_OT_IMPED]
--      ,[OT010_CLI_TELCONT]
--      ,[OT010_OT_FECFINGTIA]
--      ,[OT010_OT_RETIRA]
--      ,[OT010_OT_ANOMAL]
--      ,[OT010_OT_DIAGNO]
--      ,[OT010_OT_INCIDEN]
--      ,[OT010_OT_TIPTALLCOD]
--      ,[OT010_OT_TIPTALL]
--      ,[OT010_OT_SUCCOD]
--      ,[OT010_OT_SUCU]
--      ,[OT010_OT_TIPTRABCOD]
--      ,[OT010_OT_TIPTRAB]
--      ,[OT010_OT_SERVICIO]
--      ,[OT010_OT_DETALLE]
--      ,[OT010_OT_CARGOGRAL]
--      ,[OT010_OT_CCTOCOD]
--      ,[OT010_OT_CTROCTO]
--      ,[OT010_OT_DESCRIP]
--      ,[OT010_VH_DOMINIO]
--      ,[OT010_VH_MARCA]
--      ,[OT010_VH_MODELO]
--      ,[OT010_VH_SUBMODL]
--      ,[OT010_VH_MOTOR]
--      ,[OT010_VH_CHASIS]
--      ,[OT010_VH_KILOM]
--      ,[OT010_REF_ID]
      ,[OT010_REF_COD]
      ,[OT010_REF_DESC]
      ,[OT010_VALEDETAL]
--      ,[OT010_VALEORDEN]
--      ,[OT010_VALEFECHA]
--      ,[OT010_VALEDEPORIG]
--      ,[OT010_VALEDEPDEST]
--      ,[OT010_VALEUSUARIO]
      ,[OT010_REF_CANT]
--      ,[OT010_REF_CTOTOTAL]
--      ,[OT010_REF_FCCPRANETO]
      ,[OT010_REF_DESCTOTOTAL]
--      ,[OT010_REF_TOTNETO]
--      ,[OT010_REF_RUBRO]
--      ,[OT010_REF_TIPO]
--      ,[OT010_REF_CANAL]
--      ,[OT010_OT_USUARIO]
--      ,[OT010_OT_RECEPTOR]
--      ,[OT010_CLI_CIUDAD]
--      ,[OT010_CLI_PROV]
--      ,[OT010_CLI_EMPRESA]
--      ,[OT010_CLI_TIPO]
--      ,[OT010_CLI_CODPTAL]
--      ,[OT010_CLI_DIRCALLE]
--      ,[OT010_CLI_CELU]
--      ,[OT010_CLI_TELLABOR]
--      ,[OT010_CLI_TELPARTI]
--      ,[OT010_CLI_EMAIL]
--      ,[OT010_OT_CARGOITEM]	-- ES CARGO DE LA OT, CAMBIAR
--      ,[OT010_OT_FECHEJECU]
--      ,[OT010_OT_FECHAFINAL]
--      ,[OT010_OT_AVISOCLIENTE]
--      ,[OT010_OT_TIPOSERV]
--      ,[OT010_FV_ID]
--      ,[OT010_FV_NUMCOMP]
--      ,[OT010_FV_TOTCIVA]
--      ,[OT010_FV_FECHANUM]
--      ,[OT010_FV_CANTFAC]
  FROM [PVTWEB].[dbo].[OT010_OTDET]
WHERE [OT010_OT_SUCU] = 'Tagle - Cordoba'
		AND [OT010_VALEDEPORIG] = 'Deposito Comercial Cordoba'
		AND [OT010_REF_CANAL] = '01 - Consignaci�n'
		AND [OT010_REF_RUBRO] = '01 - Repuestos'
--		AND [OT010_OT_MES] = '2014/05'
ORDER BY [OT010_OT_FECHA] DESC




-- OPCIONES VALE DEPOSITO ORIGEN
SELECT [OT010_VALEDEPORIG], COUNT(*) AS TOTAL
FROM [PVTWEB].[dbo].[OT010_OTDET]
GROUP BY [OT010_VALEDEPORIG]
ORDER BY [OT010_VALEDEPORIG]

--OT010_VALEDEPORIG						TOTAL
--NULL	148001
--	15
--Deposito Garantia Cordoba				1559
--Deposito Comercial Cordoba			86798
--Deposito Comercial Cordoba Motcor		5853
--Deposito Comercial Cordoba Nix		14653
--Deposito Comercial Rio IV				28291
--Deposito Comercial Rio IV Nix			5350
--Deposito Comercial RIV Motcor			1117
--Deposito Comercial RM Cordoba			2005
--Deposito Comercial Villa Maria		9452
--Deposito Comercial Villa Maria Motcor	1486
--Deposito Garantia Cordoba				905
--Deposito Garantia Cordoba Nix			616
--Deposito Garantia Rio IV				925
--Deposito Garantia Rio IV Nix			308
--Deposito Garantia Villa Maria			12
--Deposito Rep.Reservados Rio IV		482



-- OPCIONES REFERENCIA CANAL
SELECT [OT010_REF_CANAL], COUNT(*) AS TOTAL
FROM [PVTWEB].[dbo].[OT010_OTDET]
GROUP BY [OT010_REF_CANAL]
ORDER BY [OT010_REF_CANAL]

--OT010_REF_CANAL		TOTAL
--						299012
--01 - Consignaci�n		6619
--02 - Cr�ditos			2197


-- OPCIONES REFERENCIA RUBRO
SELECT [OT010_REF_RUBRO], COUNT(*) AS TOTAL
FROM [PVTWEB].[dbo].[OT010_OTDET]
GROUP BY [OT010_REF_RUBRO]
ORDER BY [OT010_REF_RUBRO]

--NULL	5517
---	3
--01 - Repuestos	156959
--02 - Mano de Obra 	106980
--03 - Trabajos de Terceros	21957
--04 - Lubricantes	16410
--06 - Vehiculos 	1
--08 - Formularios	1
--


-- OPCIONES REFERENCIA TIPO
SELECT [OT010_REF_TIPO], COUNT(*) AS TOTAL
FROM [PVTWEB].[dbo].[OT010_OTDET]
GROUP BY [OT010_REF_TIPO]
ORDER BY [OT010_REF_TIPO]
--
--NULL	5517
--Producto	172703
--Servicio	129608
