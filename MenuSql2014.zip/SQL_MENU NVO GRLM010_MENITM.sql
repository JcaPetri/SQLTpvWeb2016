-- ############################################################################################################################################
-- INICIO -- CARGA UN NUEVO MNITEM
-- ############################################################################################################################################
INSERT INTO [PVTWEB].[dbo].[GRLM010_MENITM]
           ([GRLM010_MNITEMID]
           ,[GRLM010_MNITEM]
           ,[GRLM010_ITMTXT]
           ,[GRLM010_ITMPAGA]
           ,[GRLM010_ITMVINIZ]
           ,[GRLM010_ITMVINDE]
           ,[GRLM010_ITMMSGM]
           ,[GRLM010_ITMTARG]
           ,[GRLM010_ITMHAODES]
           ,[GRLM010_ITMSTYL]
           ,[GRLM010_SUBMNSTY]
           ,[GRLM010_SUBMNITM])
     SELECT 
           NEWID() AS [GRLM010_MNITEMID]
           ,'ITM009999003' AS [GRLM010_MNITEM]
           ,'INICIO SESION' AS [GRLM010_ITMTXT]
           ,'' AS [GRLM010_ITMPAGA]		-- Aqui va el vinculo
           ,'' AS [GRLM010_ITMVINIZ]
           ,'' AS [GRLM010_ITMVINDE]
           ,'' AS [GRLM010_ITMMSGM]
           ,'' AS [GRLM010_ITMTARG]
           ,0 AS [GRLM010_ITMHAODES]		-- 0 = ACTIVADO // 1 = DESACTIVADO
           ,'' AS [GRLM010_ITMSTYL]
           ,'' AS [GRLM010_SUBMNSTY]
           ,'#' AS [GRLM010_SUBMNITM]

-- ############################################################################################################################################
-- FIN -- CARGA UN NUEVO MNITEM
-- ############################################################################################################################################



-- ############################################################################################################################################
-- INICIO -- ASOCIA UN NUEVO ITEM DE MENU A UN PERFIL
-- ############################################################################################################################################
DECLARE @PAR1 AS NVARCHAR(50)
DECLARE @PAR2 AS NVARCHAR(50)
SET @PAR1 = 'GCIA'		--	PVGTIA		ADM		GCIA	
--	LGGRAL		LGCIALMOT		LGCIALTAG
SET @PAR2 = 'ITM009999001'

INSERT INTO [PVTWEB].[dbo].[GRLM011_MNITEMAPLIC]
           ([GRLM011_MITAPLICID]
		   ,[GRLM011_MNITEMID]
           ,[GRLM011_MNITMAPL])
			SELECT NEWID(), MI.[GRLM010_MNITEMID], PF.[GUS03_PERCOD]
--			SELECT MI.[GRLM010_MNITEMID], MI.[GRLM010_MNITEM], MI.[GRLM010_ITMTXT], PF.[GUS03_PERCOD], PF.[GUS03_PERABR], PF.[GUS03_PERDESC]
			FROM (
				  SELECT 1 AS VINCUPERF
						  ,[GUS03_PERCOD]
						  ,[GUS03_PERABR]
						  ,[GUS03_PERDESC]
					  FROM [PVTWEB].[dbo].[GUS03_PERFIL] WITH(NOLOCK)
					  WHERE [GUS03_PERABR] = @PAR1
					) AS PF 
				   INNER JOIN (
								SELECT 1 AS VINCUITEM
									  ,[GRLM010_MNITEMID]
									  ,[GRLM010_MNITEM]
									  ,[GRLM010_ITMTXT]
								FROM [PVTWEB].[dbo].[GRLM010_MENITM] WITH(NOLOCK)
								WHERE [GRLM010_MNITEM] = @PAR2
								) AS MI ON
						PF.VINCUPERF = MI.VINCUITEM
					LEFT OUTER JOIN [PVTWEB].[dbo].[GRLM011_MNITEMAPLIC] AS MIT WITH(NOLOCK) ON
						MI.[GRLM010_MNITEMID] = MIT.[GRLM011_MNITEMID]
							AND 
						PF.[GUS03_PERCOD] = MIT.[GRLM011_MNITMAPL]
			WHERE MIT.[GRLM011_MNITEMID] IS NULL 

-- ############################################################################################################################################
-- FIN -- ASOCIA UN NUEVO ITEM DE MENU A UN PERFIL
-- ############################################################################################################################################


--SELECT     GRLM011_MITAPLICID, GRLM011_MNITEMID, GRLM011_MNITMAPL
--FROM         GRLM011_MNITEMAPLIC


-- ############################################################################################################################################
-- INICIO -- ELIMINA UN ITEM DE MENU DE UN PERFIL
-- ############################################################################################################################################
DECLARE @PAR1 AS NVARCHAR(50)
DECLARE @PAR2 AS NVARCHAR(50)
SET @PAR1 = 'PVTREC'
SET @PAR2 = 'ITM001008220'

DELETE FROM [PVTWEB].[dbo].[GRLM011_MNITEMAPLIC]
	WHERE [GRLM011_MITAPLICID] 
			IN
		       (
				SELECT MIT.[GRLM011_MITAPLICID]
--						, MI.[GRLM010_MNITEMID]
--						, PF.[GUS03_PERCOD]
					FROM (
						  SELECT 1 AS VINCUPERF
								  ,[GUS03_PERCOD]
								  ,[GUS03_PERABR]
								  ,[GUS03_PERDESC]
							  FROM [PVTWEB].[dbo].[GUS03_PERFIL] WITH(NOLOCK)
							  WHERE [GUS03_PERABR] = @PAR1
							) AS PF 
								INNER JOIN (
											SELECT 1 AS VINCUITEM
												  ,[GRLM010_MNITEMID]
												  ,[GRLM010_MNITEM]
												  ,[GRLM010_ITMTXT]
											FROM [PVTWEB].[dbo].[GRLM010_MENITM] WITH(NOLOCK)
											WHERE [GRLM010_MNITEM] = @PAR2
											) AS MI ON
												PF.VINCUPERF = MI.VINCUITEM
							LEFT OUTER JOIN [PVTWEB].[dbo].[GRLM011_MNITEMAPLIC] AS MIT WITH(NOLOCK) ON
								MI.[GRLM010_MNITEMID] = MIT.[GRLM011_MNITEMID]
									AND 
								PF.[GUS03_PERCOD] = MIT.[GRLM011_MNITMAPL]
						) 
-- ############################################################################################################################################
-- FIN -- ASOCIA UN NUEVO ITEM DE MENU A UN PERFIL
-- ############################################################################################################################################




-- ##############################################################################################################
-- INICIO -- INFORMES
-- ##############################################################################################################
SELECT [GRLM010_MNITEM], GRLM010_ITMTXT, GRLM010_ITMPAGA, GRLM010_ITMVINIZ, GRLM010_ITMVINDE, GRLM010_ITMMSGM, GRLM010_ITMTARG, 
                      GRLM010_ITMHAODES, GRLM010_ITMSTYL, GRLM010_SUBMNSTY, GRLM010_SUBMNITM
FROM [PVTWEB].[dbo].[GRLM010_MENITM]
ORDER BY [GRLM010_MNITEM]


-- ####################################################################################################################################
-- DETERMINA QUE USUARIO PUEDEN VER CADA MENU
SELECT [GUS03_PERABR]
	  ,[GRLM010_MNITEM]
	  ,[GRLM010_ITMTXT]
      ,[GRLM011_MNITMAPL]
  FROM [PVTWEB].[dbo].[GRLM011_MNITEMAPLIC] AS MA
	LEFT OUTER JOIN (SELECT [GRLM010_MNITEMID]
					  ,[GRLM010_MNITEM]
					  ,[GRLM010_ITMTXT]
					  ,[GRLM010_ITMPAGA]
					  ,[GRLM010_ITMVINIZ]
					  ,[GRLM010_ITMVINDE]
					  ,[GRLM010_ITMMSGM]
					  ,[GRLM010_ITMTARG]
					  ,[GRLM010_ITMHAODES]
					  ,[GRLM010_ITMSTYL]
					  ,[GRLM010_SUBMNSTY]
					  ,[GRLM010_SUBMNITM]
					FROM [PVTWEB].[dbo].[GRLM010_MENITM]
					) AS MN ON
						MA.[GRLM011_MNITEMID] = MN.[GRLM010_MNITEMID]
	LEFT OUTER JOIN (SELECT [GUS03_PERCOD]
					  ,[GUS03_PERABR]
					  ,[GUS03_PERDESC]
				  FROM [PVTWEB].[dbo].[GUS03_PERFIL]
				) AS GU ON
		MA.[GRLM011_MNITMAPL] = GU.[GUS03_PERCOD]
ORDER BY [GUS03_PERABR]
		, [GRLM010_MNITEM]
		, [GRLM010_ITMTXT]



-- ####################################################################################################################################
-- LOS ITEMS DE MENU QUE NO ESTAN CARGADOS EN EL PERFIL DE UN CLIENTE
SELECT [GRLM010_MNITEM]
	  ,[GRLM010_ITMTXT]
	  ,[GRLM010_ITMPAGA]
	  ,[GRLM010_ITMVINIZ]
	  ,[GRLM010_ITMVINDE]
	  ,[GRLM010_ITMMSGM]
	  ,[GRLM010_ITMTARG]
	  ,[GRLM010_ITMHAODES]
	  ,[GRLM010_ITMSTYL]
	  ,[GRLM010_SUBMNSTY]
	  ,[GRLM010_SUBMNITM]
  FROM [PVTWEB].[dbo].[GRLM010_MENITM] AS MN
	LEFT OUTER JOIN (
					SELECT [GUS03_PERABR]
						  ,[GRLM011_MNITEMID]
						  ,[GRLM011_MNITMAPL]
					  FROM [PVTWEB].[dbo].[GRLM011_MNITEMAPLIC] AS MD
						LEFT OUTER JOIN (SELECT [GUS03_PERCOD]
											  ,[GUS03_PERABR]
											  ,[GUS03_PERDESC]
										  FROM [PVTWEB].[dbo].[GUS03_PERFIL]
										) AS GU ON
								MD.[GRLM011_MNITMAPL] = GU.[GUS03_PERCOD]
					) AS MA ON
		MN.[GRLM010_MNITEM] = MA.[GRLM011_MNITEMID]
WHERE MA.[GRLM011_MNITEMID] IS NULL



-- ####################################################################################################################################
-- MUESTRA EL MENU QUE VE EL USUARIO
DECLARE @PAR1 NVARCHAR(50)
SET @PAR1 = 'NOPOVIN'

SELECT [GRLM010_ITMTXT]
	  ,[GRLM010_ITMPAGA]
	  ,[GRLM010_ITMVINIZ]
	  ,[GRLM010_ITMVINDE]
	  ,[GRLM010_ITMMSGM]
	  ,[GRLM010_ITMTARG]
	  ,[GRLM010_ITMHAODES]
	  ,[GRLM010_ITMSTYL]
	  ,[GRLM010_SUBMNSTY]
	  ,[GRLM010_SUBMNITM]
FROM (
		SELECT DISTINCT [GRLM010_MNITEM]
			  ,[GRLM010_ITMTXT]
			  ,[GRLM010_ITMPAGA]
			  ,[GRLM010_ITMVINIZ]
			  ,[GRLM010_ITMVINDE]
			  ,[GRLM010_ITMMSGM]
			  ,[GRLM010_ITMTARG]
			  ,[GRLM010_ITMHAODES]
			  ,[GRLM010_ITMSTYL]
			  ,[GRLM010_SUBMNSTY]
			  ,[GRLM010_SUBMNITM]
		--	  ,[GUS03_PERABR]
		  FROM [PVTWEB].[dbo].[GRLM010_MENITM] AS MN  WITH(NOLOCK)
			INNER JOIN 
						(SELECT [GRLM011_MNITEMID]
						--      ,[GRLM011_MNITMAPL]
							  ,[GUS03_PERABR]
						  FROM [PVTWEB].[dbo].[GRLM011_MNITEMAPLIC] AS MI WITH(NOLOCK)
							INNER JOIN 
									  (SELECT DISTINCT [GUS03_PERCOD], [GUS03_PERABR]	--, *
										FROM [PVTWEB].[dbo].[GUS03_PERFIL] AS PF WITH(NOLOCK)
											INNER JOIN (SELECT DISTINCT [GUS02_PERCOD]	--, [GUS02_USUCOD], *
														FROM [PVTWEB].[dbo].[GUS02_USUPER] AS UP WITH (NOLOCK)
															INNER JOIN (SELECT [GUS01_COD] --, *
																		FROM [PVTWEB].[dbo].[GUS01_USUACT] AS US WITH (NOLOCK)
																		WHERE [GUS01_ABR] =	@PAR1
																		) AS US ON
															UP.[GUS02_USUCOD] = US.[GUS01_COD]
														) AS USP ON
										PF.[GUS03_PERCOD] = USP.[GUS02_PERCOD]
										) AS PF   ON
								MI.[GRLM011_MNITMAPL] = PF.[GUS03_PERCOD]
--						  WHERE [GUS03_PERTIPO] = 'INGRESO'
						) AS MNA ON
				MN.[GRLM010_MNITEMID] = MNA.[GRLM011_MNITEMID]
		  WHERE [GRLM010_ITMHAODES] = 0 
	) AS MNU
ORDER BY [GRLM010_MNITEM]





-- MUESTRA EL MENU ORDENADO POR TIP
SELECT DISTINCT [GRLM010_MNITEM]
			  ,[GRLM010_ITMTXT]
			  ,[GRLM010_ITMPAGA]
			  ,[GRLM010_ITMVINIZ]
			  ,[GRLM010_ITMVINDE]
			  ,[GRLM010_ITMMSGM]
			  ,[GRLM010_ITMTARG]
			  ,[GRLM010_ITMHAODES]
			  ,[GRLM010_ITMSTYL]
			  ,[GRLM010_SUBMNSTY]
			  ,[GRLM010_SUBMNITM]
		--	  ,[GUS03_PERABR]
		  FROM [PVTWEB].[dbo].[GRLM010_MENITM] AS MN 
			INNER JOIN 
						(SELECT [GRLM011_MNITEMID]
						      --,[GRLM011_MNITMAPL]
							  ,[GUS03_PERABR]
						  FROM [PVTWEB].[dbo].[GRLM011_MNITEMAPLIC] AS MI
							INNER JOIN [PVTWEB].[dbo].[GUS03_PERFIL] AS PF ON
								MI.[GRLM011_MNITMAPL] = PF.[GUS03_PERCOD]
						) AS MNA ON
				MN.[GRLM010_MNITEMID] = MNA.[GRLM011_MNITEMID]
		  WHERE [GRLM010_ITMHAODES] = 0 
--				AND ([GUS03_PERABR] = 'MNGRL' OR [GUS03_PERABR] LIKE CASE WHEN @PAR1 = 'ADM' THEN '%' ELSE @PAR1 END)
	
-- PARA AGREGAR UN ITEM, SE DEBE:
--	1.- AGREGAR EL ITEM EN LA TABLA GRLM010_MENITM
--	2.- AGREGAR EL ITEM EN LA TABLA GRLM011_MNITEMAPLIC, VINCULARLO AL PERFIL
--		para ello poner el codigo del item y copiar el c�digo unico del perfil para pegarlo en la tabla


-- COMBINACI�N DE LOS ITEMS CON LOS PERFILES
SELECT [GUS03_PERABR]
	,[GRLM011_MNITEMID]
	--,[GRLM011_MNITMAPL]
	,[GRLM010_ITMTXT]
FROM [PVTWEB].[dbo].[GRLM011_MNITEMAPLIC] AS MI
	LEFT OUTER JOIN [PVTWEB].[dbo].[GUS03_PERFIL] AS PF ON
		MI.[GRLM011_MNITMAPL] = PF.[GUS03_PERCOD]
	LEFT OUTER JOIN [PVTWEB].[dbo].[GRLM010_MENITM] AS MN ON
		CAST(MI.[GRLM011_MNITEMID] AS VARCHAR(36)) = MN.[GRLM010_MNITEM]
WHERE [GUS03_PERABR] LIKE '%'
ORDER BY [GRLM011_MNITEMID]


-- LISTA LOS ITEMS DE MENU
SELECT [GRLM010_MNITEM]
      ,[GRLM010_ITMTXT]
      ,[GRLM010_ITMPAGA]
      ,[GRLM010_ITMVINIZ]
      ,[GRLM010_ITMVINDE]
      ,[GRLM010_ITMMSGM]
      ,[GRLM010_ITMTARG]
      ,[GRLM010_ITMHAODES]
      ,[GRLM010_ITMSTYL]
      ,[GRLM010_SUBMNSTY]
      ,[GRLM010_SUBMNITM]
  FROM [PVTWEB].[dbo].[GRLM010_MENITM]
ORDER BY [GRLM010_MNITEM]


-- LISTA DE LOS ITEMS A QUE PERFIL SE APLICA
SELECT [GRLM011_MNITEMID]
      ,[GRLM011_MNITMAPL]
  FROM [PVTWEB].[dbo].[GRLM011_MNITEMAPLIC]


-- LISTA LOS PERFILES QUE HAY
SELECT [GUS03_PERABR]
      ,[GUS03_PERDESC]
	  ,[GUS03_PERCOD]
  FROM [PVTWEB].[dbo].[GUS03_PERFIL]
ORDER BY [GUS03_PERABR]

--ADM		ADMINISTRADOR			4218E4A1-1418-45AD-855B-160A0E4545F4
--GCIA		GERENCIA				FA848CA0-5B54-4BE3-B83B-953A5D184AF2
--MNGRL		MENU GENERAL			8723AFB9-D4BE-4237-BD78-7B695C4966B1
--PVTREC	POSTVENTA RECEPTORES	F6BBEA0C-E1FE-4A86-9958-0197364BE008
--REPCLI	CLIENTES DE REPUESTOS	2E502F61-C6CF-49E3-AADB-7BDE56F84B06
--REPVEN	REPUESTOS VENDEDOR		7AB8528E-331B-4A68-873D-4D3475FCE5F5

-- ##############################################################################################################
-- FIN -- INFORMES
-- ##############################################################################################################





-- LISTA LOS ITEMS POSIBLES DE LOS MENUES
SELECT [GRLM010_MNITEM] + ' - ' + [GRLM010_ITMTXT] + '�' + CAST([GRLM010_MNITEMID] AS VARCHAR(36)) + '�' + [GRLM010_MNITEM] + ' - ' + [GRLM010_ITMTXT] AS 'MENU ITEM'
		  ,[GRLM010_ITMPAGA] AS 'PAG VINC'
--		  ,[GRLM010_ITMVINIZ]
--		  ,[GRLM010_ITMVINDE]
--		  ,[GRLM010_ITMMSGM]
--		  ,[GRLM010_ITMTARG]
		  ,[GRLM010_ITMHAODES] AS 'HAB o DESH'
--		  ,[GRLM010_ITMSTYL]
--		  ,[GRLM010_SUBMNSTY]
		  ,[GRLM010_SUBMNITM] AS 'MARCA'
	--	  ,[GUS03_PERABR]
	  FROM [PVTWEB].[dbo].[GRLM010_MENITM] AS MN 
ORDER BY [GRLM010_MNITEM]


-- DETALLE DEL USO DEL ITEM DEL MENU
SELECT [GUS03_PERTIPO] AS 'PERF TIPO'
		,[GUS03_PERABR] + ' - ' + [GUS03_PERDESC] AS 'PREFIL'
--				,[GRLM010_MNITEMID]
--				,[GRLM010_MNITEM]
--				,[GRLM010_ITMTXT]
--				,[GRLM010_ITMPAGA]
		,MIN([GRLM010_ITMHAODES]) AS 'ITEM HAB o DESH'
FROM(
		-- LISTA LOS MENUES QUE ESTA ESTE ITEM
		SELECT [GUS03_PERCOD]
				,[GUS03_PERTIPO]
				,[GUS03_PERABR]
				,[GUS03_PERDESC]
				,[GRLM010_MNITEMID]
				,[GRLM010_MNITEM]
				,[GRLM010_ITMTXT]
				,[GRLM010_ITMPAGA]
				,CASE WHEN [GRLM010_ITMHAODES] = 0 THEN 'HABILI' ELSE 'DESHAB' END AS [GRLM010_ITMHAODES]
		FROM [PVTWEB].[dbo].[GRLM010_MENITM] AS MN WITH(NOLOCK)
			INNER JOIN (SELECT [GUS03_PERABR], [GUS03_PERDESC], [GUS03_PERTIPO], [GRLM011_MNITEMID], [GUS03_PERCOD]
						FROM [PVTWEB].[dbo].[GRLM011_MNITEMAPLIC] AS MI WITH(NOLOCK) 
							INNER JOIN 
									(SELECT *
										FROM [PVTWEB].[dbo].[GUS03_PERFIL] WITH(NOLOCK)
									 ) AS PF  ON
										MI.[GRLM011_MNITMAPL] = PF.[GUS03_PERCOD]
						) AS MP ON	
					MN.[GRLM010_MNITEMID] = MP.[GRLM011_MNITEMID]
		WHERE [GRLM010_MNITEMID] = 'C390620E-A8ED-4B97-BCB5-9D0E27564D13'
		UNION ALL
		SELECT [GUS03_PERCOD]
				,[GUS03_PERTIPO]
				,[GUS03_PERABR]
				,[GUS03_PERDESC]
				,NULL AS [GRLM010_MNITEMID]
				,NULL AS [GRLM010_MNITEM]
				,NULL AS [GRLM010_ITMTXT]
				,NULL AS [GRLM010_ITMPAGA]
				,NULL AS [GRLM010_ITMHAODES]
		FROM [PVTWEB].[dbo].[GUS03_PERFIL] WITH(NOLOCK)
	) AS MID
GROUP BY [GUS03_PERCOD]
		,[GUS03_PERTIPO]
		,[GUS03_PERABR]
		,[GUS03_PERDESC]
ORDER BY [GUS03_PERTIPO]
			,[GUS03_PERABR]


