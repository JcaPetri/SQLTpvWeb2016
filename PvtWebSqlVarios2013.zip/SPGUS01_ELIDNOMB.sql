-- =============================================
-- Author: <Juan Carlos Petri>
-- Create date: <14/04/2012>
-- Description:	<Devuelve el ID del usuario>
-- =============================================
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ================================================
-- Elimina el Procedimiento Almacenado si ya existe
IF EXISTS (
  SELECT * 
    FROM INFORMATION_SCHEMA.ROUTINES 
   WHERE SPECIFIC_SCHEMA = N'dbo'
     AND SPECIFIC_NAME = N'GUS01_ELIDNOMB' 
)
   DROP PROCEDURE [dbo].[GUS01_ELIDNOMB]
GO


CREATE PROCEDURE [dbo].[GUS01_ELIDNOMB]
-- =============================================
-- Author: <Juan Carlos Petri>
-- Create date: <14/04/2012>
-- Description:	<Devuelve el ID del usuario>
-- =============================================

	-- Add the parameters for the stored procedure here
	@USUAbre NVARCHAR(6),
	@USUClave NVARCHAR(8),
	@ID CHAR (6) OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SELECT @ID = [GUS01_COD]
	  FROM [TPV].[dbo].[GUS01_USUACT]
	WHERE [GUS01_ABR] = @USUAbre
	AND [GUS01_CLAV] = @USUClave

END
GO

-- Ejecuta el Procedimiento Almacenado
DECLARE @ID CHAR (6)
EXECUTE [dbo].[GUS01_ELIDNOMB] 'JCP', '123', @ID OUTPUT;
PRINT N'El ID del usuario else es ' + @ID;
GO


SELECT *
FROM [TPV].[dbo].[GUS01_USUACT]

