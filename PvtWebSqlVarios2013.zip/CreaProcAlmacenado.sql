SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[PVta_CtaCte_002] 
	-- Add the parameters for the stored procedure here
	@CPBCTROCTOS AS INT

AS
BEGIN
	-- VALOR TOTAL DE LAS CUENTAS CORRIENTES DE POSTVENTA AGRUPADAS POR SECTOR
	SELECT TOP 1000 [PCC03_CPBCCCOD] + '-' + [PCC03_CPBCCDES] AS 'SECTOR'
		,[PCC03_CTADEN]
		,COUNT([PCC03_TVTANOM]) AS CANTREG
		,CAST(SUM([PCC03_CPBTESLDO]) AS DECIMAL(18,0)) AS IMPTOT
	FROM [TPV].[dbo].[PCC03_SDOPTE]
	WHERE [PCC03_CPBCCCOD] = @CPBCTROCTOS
	GROUP BY [PCC03_CPBCCCOD] + '-' +  [PCC03_CPBCCDES]
			,[PCC03_CTADEN]
	ORDER BY CAST(SUM([PCC03_CPBTESLDO]) AS DECIMAL(18,0)) DESC


END
GO
