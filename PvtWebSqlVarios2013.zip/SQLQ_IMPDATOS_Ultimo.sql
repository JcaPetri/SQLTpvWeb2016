
DELETE FROM [TPV].[dbo].[TM_LPR_IMP]

BULK INSERT [TPV].[dbo].[TM_LPR_IMP]
   FROM 'C:\Users\juan.petri\TAGLE\LISTA DE PRECIOS\LISTA PRECIO TALLER\LP TALL 2012 03 MAR\LP TALL 2012 03.txt'
   WITH 
      (	 DATAFILETYPE = 'char',
         FIELDTERMINATOR = '\t',		--\t = tabulador	; Comas
         ROWTERMINATOR = '\n', 
		 MAXERRORS = 5 
		 --ERRORFILE = 'C:\Users\juan.petri\TAGLE\LISTA DE PRECIOS\LISTA PRECIO TALLER\LP TALL 2012 02 FEB\SQLErrImp.txt' 
      )
DELETE FROM [TPV].[dbo].[TM_LPR_IMP] WHERE [TM_LPRI_ORDEN] IS NULL OR [TM_LPRI_ORDEN] = '	' OR [TM_LPRI_ORDEN] = 'ORDEN'


DELETE FROM [TPV].[dbo].[TM_LPR_IMP]
--      WHERE <Condiciones de b�squeda,,>

BULK INSERT [TPV].[dbo].[TM_LPR_IMP]
   FROM 'C:\Users\juan.petri\TAGLE\LISTA DE PRECIOS\LISTA PRECIO TALLER\LP TALL 2012 02 FEB\LPaImp.txt'
   WITH 
      (	 DATAFILETYPE = 'char',
         FIELDTERMINATOR = '\t',		--\t = tabulador	; Comas
         ROWTERMINATOR = '\n',	 
		 MAXERRORS = 5 
		 --ERRORFILE = 'C:\Users\juan.petri\TAGLE\LISTA DE PRECIOS\LISTA PRECIO TALLER\LP TALL 2012 02 FEB\SQLErrImp.txt' 
      )



SELECT TOP 100 * FROM [TPV].[dbo].[TM_LPR_IMP]

