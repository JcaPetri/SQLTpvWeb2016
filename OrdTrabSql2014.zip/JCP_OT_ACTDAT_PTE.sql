-- ######################################################################################################################################
-- INICIO - ACTUALIZA LA TABLA CON LA INFORMACI�N DE LAS ORDENES DE TRABAJO
-- ######################################################################################################################################

-- ###################################################################################################################################
-- INICIO - ACTCC_PASO 1
-- ###################################################################################################################################
DECLARE @NUEVOIDACT AS NVARCHAR(36) 
DECLARE @PROCNUM AS NUMERIC(18,0)

-- GENERA EL CODIGO PARA ESTE PROCESO, ESTO PERMITE QUE EN CADA ETAPA SEPARADA CARGUE EL MISMO CODIGO
-- PRIMERO BORRA EL CODIGO DEL PROCESO, ES POR LAS DUDAS SI HUBIERE
DELETE FROM [PVTWEB].[dbo].[GRL098_PROCLAVE] WHERE [GRL098_PROC] = 'OT_ACT_PTE'
INSERT INTO [PVTWEB].[dbo].[GRL098_PROCLAVE]
           ([GRL098_PROC]
           ,[GRL098_PROCNUM])
       SELECT 'OT_ACT_PTE', REPLACE(REPLACE(REPLACE(CONVERT(NVARCHAR(20), GETDATE(), 120), '-', ''), ':', ''), ' ', '')

-- TOMA EL COGIDO DEL PROCESO VIGENTE
-- GENERA EL CODIGO DE LA SUBETAPA PARA LUEGO PODER CARGARLE EL TIEMPO DE FINALIZACION
SET @PROCNUM  = (SELECT TOP 1 [GRL098_PROCNUM] FROM [PVTWEB].[dbo].[GRL098_PROCLAVE] WITH(NOLOCK) WHERE [GRL098_PROC] = 'OT_ACT_PTE')
SET @NUEVOIDACT = NEWID()	-- MARCA TIEMPO DE INICIO


INSERT INTO [PVTWEB].[dbo].[GRL099_ACTREG]
			([GRL099_CODID], [GRL099_PROC], [GRL099_PROCORD], [GRL099_PROCNUM], [GRL099_SUBPROC], [GRL099_ACTPROC], [GRL099_OBJAFEC], [GRL099_PROCDESC]              , [GRL099_FECINIC]                , [GRL099_FECFIN])
	 SELECT  @NUEVOIDACT   , 'OT_ACT_PTE'   , 1                 , @PROCNUM      , 'OT_IMPDAT'   , 'OT_DATBORR'  , '[OT010_OTDET_PTE]'  , 'Elimina datos de [OT010_OTDET_PTE]', CAST(GETDATE() AS DATETIME), NULL
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
DELETE FROM [PVTWEB].[dbo].[OT012_OTDET_PTE]
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
UPDATE [PVTWEB].[dbo].[GRL099_ACTREG] SET [GRL099_FECFIN] = CAST(GETDATE() AS DATETIME) WHERE [GRL099_CODID] = @NUEVOIDACT
-- ###################################################################################################################################
-- FIN - ACTCC_PASO 1
-- ###################################################################################################################################



-- ###################################################################################################################################
-- INICIO - ACTCC_PASO 2
-- ###################################################################################################################################
--DECLARE @NUEVOIDACT AS NVARCHAR(36) 
--DECLARE @PROCNUM AS NUMERIC(18,0)

-- TOMA EL COGIDO DEL PROCESO VIGENTE
-- GENERA EL CODIGO DE LA SUBETAPA PARA LUEGO PODER CARGARLE EL TIEMPO DE FINALIZACION
SET @PROCNUM  = (SELECT TOP 1 [GRL098_PROCNUM] FROM [PVTWEB].[dbo].[GRL098_PROCLAVE] WITH(NOLOCK) WHERE [GRL098_PROC] = 'OT_ACT_PTE')
SET @NUEVOIDACT = NEWID()	-- MARCA TIEMPO DE INICIO

INSERT INTO [PVTWEB].[dbo].[GRL099_ACTREG]	
	([GRL099_CODID], [GRL099_PROC], [GRL099_PROCORD], [GRL099_PROCNUM], [GRL099_SUBPROC], [GRL099_ACTPROC], [GRL099_OBJAFEC], [GRL099_PROCDESC], [GRL099_FECINIC], [GRL099_FECFIN]) 
	 SELECT @NUEVOIDACT, 'OT_ACT_PTE', 2, @PROCNUM, 'OT_IMPDAT', 'OT_DATIMP', '[OT010_OTDET_PTE]', 'Importa datos de [OT010_OTDET_PTE]', CAST(GETDATE() AS DATETIME), NULL
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
-- LUEGO IMPORTA LOS DATOS COMPLETOS
INSERT INTO [PVTWEB].[dbo].[OT012_OTDET_PTE]
           ([OT010_OT_MES]
           ,[OT010_OT_MESULTEST]
           ,[OT010_OT_MESTUR]
           ,[OT010_OT_ID]
           ,[OT010_OT_NUM]
           ,[OT010_CLI_ID]
           ,[OT010_CLI_COD]
           ,[OT010_CLI_DESC]
           ,[OT010_OT_FECHA]
           ,[OT010_OT_FECULTEST]
           ,[OT010_OT_ESTADO]
           ,[OT010_OT_FECVTAVN]
           ,[OT010_OT_FECTURN]
           ,[OT010_OT_IMPED]
           ,[OT010_CLI_TELCONT]
           ,[OT010_OT_FECFINGTIA]
           ,[OT010_OT_RETIRA]
           ,[OT010_OT_ANOMAL]
           ,[OT010_OT_DIAGNO]
           ,[OT010_OT_INCIDEN]
           ,[OT010_OT_TIPTALLCOD]
           ,[OT010_OT_TIPTALL]
           ,[OT010_OT_SUCCOD]
           ,[OT010_OT_SUCU]
           ,[OT010_OT_TIPTRABCOD]
           ,[OT010_OT_TIPTRAB]
           ,[OT010_OT_SERVICIO]
           ,[OT010_OT_DETALLE]
           ,[OT010_OT_CARGOGRAL]
           ,[OT010_OT_CCTOCOD]
           ,[OT010_OT_CTROCTO]
		   ,[OT010_VH_CODID]
		   ,[OT010_VH_CODIGO]
           ,[OT010_VH_DESCRIP]
           ,[OT010_VH_DOMINIO]
           ,[OT010_VH_MARCA]
           ,[OT010_VH_MODELO]
           ,[OT010_VH_SUBMODL]
           ,[OT010_VH_MOTOR]
           ,[OT010_VH_CHASIS]
           ,[OT010_VH_KILOM]
           ,[OT010_REF_ID]
           ,[OT010_REF_COD]
           ,[OT010_REF_DESC]
           ,[OT010_VALEDETAL]
           ,[OT010_VALEORDEN]
           ,[OT010_VALEFECHA]
           ,[OT010_VALEDEPORIG]
           ,[OT010_VALEDEPDEST]
           ,[OT010_VALEUSUARIO]
           ,[OT010_REF_CANT]
           ,[OT010_REF_CTOTOTAL]
           ,[OT010_REF_FCCPRANETO]
           ,[OT010_REF_DESCTOTOTAL]
           ,[OT010_REF_TOTNETO]
           ,[OT010_REF_RUBRO]
           ,[OT010_REF_TIPO]
           ,[OT010_REF_CANAL]
           ,[OT010_OT_USUARIO]
           ,[OT010_OT_RECEPTOR]
           ,[OT010_CLI_CIUDAD]
           ,[OT010_CLI_PROV]
           ,[OT010_CLI_EMPRESA]
           ,[OT010_CLI_TIPO]
           ,[OT010_CLI_CODPTAL]
           ,[OT010_CLI_DIRCALLE]
           ,[OT010_CLI_CELU]
           ,[OT010_CLI_TELLABOR]
           ,[OT010_CLI_TELPARTI]
           ,[OT010_CLI_EMAIL]
           ,[OT010_OT_CARGOITEM]
           ,[OT010_OT_FECHEJECU]
           ,[OT010_OT_FECHAFINAL]
           ,[OT010_OT_AVISOCLIENTE]
           ,[OT010_OT_TIPOSERV]
           ,[OT010_FV_ID]
           ,[OT010_FV_NUMCOMP]
           ,[OT010_FV_TOTCIVA]
           ,[OT010_FV_FECHANUM]
		   ,[OT010_SS_VINCID]
           ,[OT010_FV_CANTFAC])
     SELECT [OT010_OT_MES]
			  ,[OT010_OT_MESULTEST]
			  ,[OT010_OT_MESTUR]
			  ,[OT010_OT_ID]
			  ,[OT010_OT_NUM]
			  ,[OT010_CLI_ID]
			  ,[OT010_CLI_COD]
			  ,[OT010_CLI_DESC]
			  ,[OT010_OT_FECHA]
			  ,[OT010_OT_FECULTEST]
			  ,[OT010_OT_ESTADO]
			  ,[OT010_OT_FECVTAVN]
			  ,[OT010_OT_FECTURN]
			  ,[OT010_OT_IMPED]
			  ,[OT010_CLI_TELCONT]
			  ,[OT010_OT_FECFINGTIA]
			  ,[OT010_OT_RETIRA]
			  ,[OT010_OT_ANOMAL]
			  ,[OT010_OT_DIAGNO]
			  ,[OT010_OT_INCIDEN]
			  ,[OT010_OT_TIPTALLCOD]
			  ,[OT010_OT_TIPTALL]
			  ,[OT010_OT_SUCCOD]
			  ,[OT010_OT_SUCU]
			  ,[OT010_OT_TIPTRABCOD]
			  ,[OT010_OT_TIPTRAB]
			  ,[OT010_OT_SERVICIO]
			  ,[OT010_OT_DETALLE]
			  ,[OT010_OT_CARGOGRAL]
			  ,[OT010_OT_CCTOCOD]
			  ,[OT010_OT_CTROCTO]
			  ,[OT010_VH_CODID]
			  ,[OT010_VH_CODIGO]
			  ,[OT010_VH_DESCRIP]
			  ,[OT010_VH_DOMINIO]
			  ,[OT010_VH_MARCA]
			  ,[OT010_VH_MODELO]
			  ,[OT010_VH_SUBMODL]
			  ,[OT010_VH_MOTOR]
			  ,[OT010_VH_CHASIS]
			  ,[OT010_VH_KILOM]
			  ,[OT010_REF_ID]
			  ,[OT010_REF_COD]
			  ,[OT010_REF_DESC]
			  ,[OT010_VALEDETAL]
			  ,[OT010_VALEORDEN]
			  ,[OT010_VALEFECHA]
			  ,[OT010_VALEDEPORIG]
			  ,[OT010_VALEDEPDEST]
			  ,[OT010_VALEUSUARIO]
			  ,[OT010_REF_CANT]
			  ,[OT010_REF_CTOTOTAL]
			  ,[OT010_REF_FCCPRANETO]
			  ,[OT010_REF_DESCTOTOTAL]
			  ,[OT010_REF_TOTNETO]
			  ,[OT010_REF_RUBRO]
			  ,[OT010_REF_TIPO]
			  ,[OT010_REF_CANAL]
			  ,[OT010_OT_USUARIO]
			  ,[OT010_OT_RECEPTOR]
			  ,[OT010_CLI_CIUDAD]
			  ,[OT010_CLI_PROV]
			  ,[OT010_CLI_EMPRESA]
			  ,[OT010_CLI_TIPO]
			  ,[OT010_CLI_CODPTAL]
			  ,[OT010_CLI_DIRCALLE]
			  ,[OT010_CLI_CELU]
			  ,[OT010_CLI_TELLABOR]
			  ,[OT010_CLI_TELPARTI]
			  ,[OT010_CLI_EMAIL]
			  ,[OT010_OT_CARGOITEM]
			  ,[OT010_OT_FECHEJECU]
			  ,[OT010_OT_FECHAFINAL]
			  ,[OT010_OT_AVISOCLIENTE]
			  ,[OT010_OT_TIPOSERV]
			  ,[OT010_FV_ID]
			  ,[OT010_FV_NUMCOMP]
			  ,[OT010_FV_TOTCIVA]
			  ,[OT010_FV_FECHANUM]
			  ,[OT010_SS_VINCID]
			  ,[OT010_FV_CANTFAC]
		  FROM [SYS-REPLICA].[CalipsoReplicado].[dbo].[JCP_VP_OTDET_PTE] WITH (NOLOCK)
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
UPDATE [PVTWEB].[dbo].[GRL099_ACTREG] SET [GRL099_FECFIN] = CAST(GETDATE() AS DATETIME) WHERE [GRL099_CODID] = @NUEVOIDACT
-- ###################################################################################################################################
-- FIN - ACTCC_PASO 2
-- ###################################################################################################################################



-- ###################################################################################################################################
-- INICIO - ACTCC_PASO 3	-- GENERA LA TABLA CON LAS OT INDIVIDUALES
-- ###################################################################################################################################
--DECLARE @NUEVOIDACT AS NVARCHAR(36) 
--DECLARE @PROCNUM AS NUMERIC(18,0)

-- TOMA EL COGIDO DEL PROCESO VIGENTE
-- GENERA EL CODIGO DE LA SUBETAPA PARA LUEGO PODER CARGARLE EL TIEMPO DE FINALIZACION
SET @PROCNUM  = (SELECT TOP 1 [GRL098_PROCNUM] FROM [PVTWEB].[dbo].[GRL098_PROCLAVE] WITH(NOLOCK) WHERE [GRL098_PROC] = 'OT_ACT')
SET @NUEVOIDACT = NEWID()	-- MARCA TIEMPO DE INICIO

INSERT INTO [PVTWEB].[dbo].[GRL099_ACTREG]
			([GRL099_CODID], [GRL099_PROC], [GRL099_PROCORD], [GRL099_PROCNUM], [GRL099_SUBPROC], [GRL099_ACTPROC], [GRL099_OBJAFEC], [GRL099_PROCDESC]              , [GRL099_FECINIC]                , [GRL099_FECFIN])
	 SELECT  @NUEVOIDACT   , 'OT_ACT_PTE'   , 3                 , @PROCNUM      , 'OTG_IMPDAT'   , 'OTG_DATBORR'  , '[OT002_OTGRL_PTE]'  , 'Elimina datos de [OT002_OTGRL_PTE]', CAST(GETDATE() AS DATETIME), NULL
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
DELETE FROM [PVTWEB].[dbo].[OT002_OTGRL_PTE]
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
UPDATE [PVTWEB].[dbo].[GRL099_ACTREG] SET [GRL099_FECFIN] = CAST(GETDATE() AS DATETIME) WHERE [GRL099_CODID] = @NUEVOIDACT
-- ###################################################################################################################################
-- FIN - ACTCC_PASO 3
-- ##################################################################################################################################


-- ###################################################################################################################################
-- INICIO - ACTCC_PASO 4 -- INSERTA LOS DATOS A LA BASE DE OT GENERAL
-- ###################################################################################################################################
--DECLARE @NUEVOIDACT AS NVARCHAR(36) 
--DECLARE @PROCNUM AS NUMERIC(18,0)

-- TOMA EL COGIDO DEL PROCESO VIGENTE
-- GENERA EL CODIGO DE LA SUBETAPA PARA LUEGO PODER CARGARLE EL TIEMPO DE FINALIZACION
SET @PROCNUM  = (SELECT TOP 1 [GRL098_PROCNUM] FROM [PVTWEB].[dbo].[GRL098_PROCLAVE] WITH(NOLOCK) WHERE [GRL098_PROC] = 'OT_ACT_PTE')
SET @NUEVOIDACT = NEWID()	-- MARCA TIEMPO DE INICIO

INSERT INTO [PVTWEB].[dbo].[GRL099_ACTREG]	
	([GRL099_CODID], [GRL099_PROC], [GRL099_PROCORD], [GRL099_PROCNUM], [GRL099_SUBPROC], [GRL099_ACTPROC], [GRL099_OBJAFEC], [GRL099_PROCDESC], [GRL099_FECINIC], [GRL099_FECFIN]) 
	 SELECT @NUEVOIDACT, 'OT_ACT_PTE', 4, @PROCNUM, 'OTG_IMPDAT', 'OTG_DATIMP', '[OT002_OTGRL_PTE]', 'Importa datos de [OT002_OTGRL_PTE]', CAST(GETDATE() AS DATETIME), NULL
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
-- LUEGO IMPORTA LOS DATOS COMPLETOS
INSERT INTO [PVTWEB].[dbo].[OT002_OTGRL_PTE]
           ([OT002_OT_MES]
           ,[OT002_OT_MESULTEST]
           ,[OT002_OT_MESTUR]
           ,[OT002_OT_ID]
           ,[OT002_OT_NUM]
           ,[OT002_CLI_ID]
           ,[OT002_CLI_COD]
           ,[OT002_CLI_DESC]
           ,[OT002_OT_FECHA]
           ,[OT002_OT_FECULTEST]
           ,[OT002_OT_ESTADO]
           ,[OT002_OT_FECVTAVN]
           ,[OT002_OT_FECTURN]
           ,[OT002_OT_IMPED]
           ,[OT002_CLI_TELCONT]
           ,[OT002_OT_FECFINGTIA]
           ,[OT002_OT_RETIRA]
           ,[OT002_OT_ANOM]
           ,[OT002_OT_DIAG]
           ,[OT002_OT_INC]
           ,[OT002_OT_TIPTALLCOD]
           ,[OT002_OT_TIPTALL]
           ,[OT002_OT_SUCCOD]
           ,[OT002_OT_SUCU]
           ,[OT002_OT_TIPTRABCOD]
           ,[OT002_OT_TIPTRAB]
           ,[OT002_OT_SERVICIO]
           ,[OT002_OT_DETALLE]
--           ,[OT002_OT_CARGOGRAL]
           ,[OT002_OT_CTROCTOS]
           ,[OT002_VH_CODID]
           ,[OT002_VH_CODIGO]
           ,[OT002_VH_DESCRIP]
           ,[OT002_VH_DOMINIO]
           ,[OT002_VH_MARCA]
           ,[OT002_VH_MODELO]
           ,[OT002_VH_SUBMODL]
           ,[OT002_VH_MOTOR]
           ,[OT002_VH_CHASIS]
           ,[OT002_VH_KILOM]
           ,[OT002_Q_TOT]
           ,[OT002_PR_NET]
           ,[OT002_DTO_TOT]
           ,[OT002_TOT_NET]
           ,[OT002_OT_USUARIO]
           ,[OT002_OT_RECEPTOR]
           ,[OT002_CLI_CIUDAD]
           ,[OT002_CLI_PROV]
           ,[OT002_CLI_EMPRESA]
           ,[OT002_CLI_TIPO]
           ,[OT002_CLI_CODPTAL]
           ,[OT002_CLI_DIRCALLE]
           ,[OT002_CLI_CELU]
           ,[OT002_CLI_TELLABOR]
           ,[OT002_CLI_TELPARTI]
           ,[OT002_CLI_EMAIL]
           ,[OT002_OT_CARGOITEM]
           ,[OT002_OT_FECHEJECU]
           ,[OT002_OT_FECHAFINAL]
           ,[OT002_OT_AVISOCLIENTE]
           ,[OT002_OT_TIPOSERV]
           ,[OT002_FV_ID]
           ,[OT002_FV_NUMCOMP]
           ,[OT002_FV_TOTCIVA]
           ,[OT002_FV_FECHANUM]
           ,[OT002_SS_VINCID]
           ,[OT002_FV_CANTFAC])
		SELECT OTAGR.[OT010_OT_MES]
					  ,OTAGR.[OT010_OT_MESULTEST]
					  ,OTAGR.[OT010_OT_MESTUR]
					  ,OTAGR.[OT010_OT_ID]
					  ,OTAGR.[OT010_OT_NUM]
					  ,OTAGR.[OT010_CLI_ID]
					  ,OTAGR.[OT010_CLI_COD]
					  ,OTAGR.[OT010_CLI_DESC]
					  ,OTAGR.[OT010_OT_FECHA]
					  ,OTAGR.[OT010_OT_FECULTEST]
					  ,OTAGR.[OT010_OT_ESTADO]
					  ,OTAGR.[OT010_OT_FECVTAVN]
					  ,OTAGR.[OT010_OT_FECTURN]
					  ,OTAGR.[OT010_OT_IMPED]
					  ,OTAGR.[OT010_CLI_TELCONT]
					  ,OTAGR.[OT010_OT_FECFINGTIA]
					  ,OTAGR.[OT010_OT_RETIRA]
					  ,OTAGR.[OT_ANOM]
					  ,OTAGR.[OT_DIAG]
					  ,OTAGR.[OT_INC]
					  ,OTAGR.[OT010_OT_TIPTALLCOD]
					  ,OTAGR.[OT010_OT_TIPTALL]
					  ,OTAGR.[OT010_OT_SUCCOD]
					  ,OTAGR.[OT010_OT_SUCU]
					  ,OTAGR.[OT010_OT_TIPTRABCOD]
					  ,OTAGR.[OT010_OT_TIPTRAB]
					  ,OTAGR.[OT010_OT_SERVICIO]
					  ,OTAGR.[OT010_OT_DETALLE]
					  ,CtroCto.[OT_CtroCto]
					  ,OTAGR.[OT010_VH_CODID]
					  ,OTAGR.[OT010_VH_CODIGO]
					  ,OTAGR.[OT010_VH_DESCRIP]
					  ,OTAGR.[OT010_VH_DOMINIO]
					  ,OTAGR.[OT010_VH_MARCA]
					  ,OTAGR.[OT010_VH_MODELO]
					  ,OTAGR.[OT010_VH_SUBMODL]
					  ,OTAGR.[OT010_VH_MOTOR]
					  ,OTAGR.[OT010_VH_CHASIS]
					  ,OTAGR.[OT010_VH_KILOM]
					  ,OTAGR.[Q_TOT]
					  ,OTAGR.[PR_NET]
					  ,OTAGR.[DTO_TOT]
					  ,OTAGR.[TOT_NET]
					  ,OTAGR.[OT010_OT_USUARIO]
					  ,OTAGR.[OT010_OT_RECEPTOR]
					  ,OTAGR.[OT010_CLI_CIUDAD]
					  ,OTAGR.[OT010_CLI_PROV]
					  ,OTAGR.[OT010_CLI_EMPRESA]
					  ,OTAGR.[OT010_CLI_TIPO]
					  ,OTAGR.[OT010_CLI_CODPTAL]
					  ,OTAGR.[OT010_CLI_DIRCALLE]
					  ,OTAGR.[OT010_CLI_CELU]
					  ,OTAGR.[OT010_CLI_TELLABOR]
					  ,OTAGR.[OT010_CLI_TELPARTI]
					  ,OTAGR.[OT010_CLI_EMAIL]
					  ,CgoUni.[OT_CargoItem]
					  ,OTAGR.[OT010_OT_FECHEJECU]
					  ,OTAGR.[OT010_OT_FECHAFINAL]
					  ,OTAGR.[OT010_OT_AVISOCLIENTE]
					  ,OTAGR.[OT010_OT_TIPOSERV]
					  ,OTAGR.[OT010_FV_ID]
					  ,OTAGR.[OT010_FV_NUMCOMP]
					  ,OTAGR.[OT010_FV_TOTCIVA]
					  ,OTAGR.[OT010_FV_FECHANUM]
					  ,OTAGR.[OT010_SS_VINCID]
					  ,OTAGR.[OT010_FV_CANTFAC]
		FROM (
				SELECT [OT010_OT_MES]
					  ,[OT010_OT_MESULTEST]
					  ,[OT010_OT_MESTUR]
					  ,[OT010_OT_ID]
					  ,[OT010_OT_NUM]
					  ,[OT010_CLI_ID]
					  ,[OT010_CLI_COD]
					  ,[OT010_CLI_DESC]
					  ,[OT010_OT_FECHA]
					  ,[OT010_OT_FECULTEST]
					  ,[OT010_OT_ESTADO]
					  ,[OT010_OT_FECVTAVN]
					  ,[OT010_OT_FECTURN]
					  ,[OT010_OT_IMPED]
					  ,[OT010_CLI_TELCONT]
					  ,[OT010_OT_FECFINGTIA]
					  ,[OT010_OT_RETIRA]
					  ,CAST([OT010_OT_ANOMAL] AS VARCHAR(255)) AS [OT_ANOM]
					  ,CAST([OT010_OT_DIAGNO] AS VARCHAR(255)) AS [OT_DIAG]
					  ,CAST([OT010_OT_INCIDEN] AS VARCHAR(255)) AS [OT_INC]
					  ,[OT010_OT_TIPTALLCOD]
					  ,[OT010_OT_TIPTALL]
					  ,[OT010_OT_SUCCOD]
					  ,[OT010_OT_SUCU]
					  ,[OT010_OT_TIPTRABCOD]
					  ,[OT010_OT_TIPTRAB]
					  ,[OT010_OT_SERVICIO]
					  ,[OT010_OT_DETALLE]
		--			  ,[OT010_OT_CARGOGRAL]
--					  ,[OT010_OT_CCTOCOD]
--					  ,[OT010_OT_CTROCTO]
					  ,[OT010_VH_CODID]
					  ,[OT010_VH_CODIGO]
					  ,[OT010_VH_DESCRIP]
					  ,[OT010_VH_DOMINIO]
					  ,[OT010_VH_MARCA]
					  ,[OT010_VH_MODELO]
					  ,[OT010_VH_SUBMODL]
					  ,[OT010_VH_MOTOR]
					  ,[OT010_VH_CHASIS]
					  ,[OT010_VH_KILOM]
				--      ,[OT010_REF_ID]
				--      ,[OT010_REF_COD]
				--      ,[OT010_REF_DESC]
				--      ,[OT010_VALEDETAL]
				--      ,[OT010_VALEORDEN]
				--      ,[OT010_VALEFECHA]
				--      ,[OT010_VALEDEPORIG]
				--      ,[OT010_VALEDEPDEST]
				--      ,[OT010_VALEUSUARIO]
				--      ,[OT010_REF_CANT]
					  ,SUM([OT010_REF_CTOTOTAL]) AS [Q_TOT]
					  ,SUM([OT010_REF_FCCPRANETO]) AS [PR_NET]
					  ,SUM([OT010_REF_DESCTOTOTAL]) AS [DTO_TOT]
					  ,SUM([OT010_REF_TOTNETO]) AS [TOT_NET]
				--      ,[OT010_REF_RUBRO]
				--      ,[OT010_REF_TIPO]
				--      ,[OT010_REF_CANAL]
					  ,[OT010_OT_USUARIO]
					  ,[OT010_OT_RECEPTOR]
					  ,[OT010_CLI_CIUDAD]
					  ,[OT010_CLI_PROV]
					  ,[OT010_CLI_EMPRESA]
					  ,[OT010_CLI_TIPO]
					  ,[OT010_CLI_CODPTAL]
					  ,[OT010_CLI_DIRCALLE]
					  ,[OT010_CLI_CELU]
					  ,[OT010_CLI_TELLABOR]
					  ,[OT010_CLI_TELPARTI]
					  ,[OT010_CLI_EMAIL]
					  ,[OT010_OT_FECHEJECU]
					  ,[OT010_OT_FECHAFINAL]
					  ,[OT010_OT_AVISOCLIENTE]
					  ,[OT010_OT_TIPOSERV]
					  ,[OT010_FV_ID]
					  ,[OT010_FV_NUMCOMP]
					  ,[OT010_FV_TOTCIVA]
					  ,[OT010_FV_FECHANUM]
					  ,[OT010_SS_VINCID]
					  ,[OT010_FV_CANTFAC]
				  FROM [PVTWEB].[dbo].[OT012_OTDET_PTE] WITH(NOLOCK)
--				WHERE [OT010_OT_ID] = '6C6F7336-6B70-4898-B42D-A1F04A3554AA'
		--		WHERE [OT010_OT_NUM] = '21486'	--'21486'	--39128
				GROUP BY [OT010_OT_MES]
					  ,[OT010_OT_MESULTEST]
					  ,[OT010_OT_MESTUR]
					  ,[OT010_OT_ID]
					  ,[OT010_OT_NUM]
					  ,[OT010_CLI_ID]
					  ,[OT010_CLI_COD]
					  ,[OT010_CLI_DESC]
					  ,[OT010_OT_FECHA]
					  ,[OT010_OT_FECULTEST]
					  ,[OT010_OT_ESTADO]
					  ,[OT010_OT_FECVTAVN]
					  ,[OT010_OT_FECTURN]
					  ,[OT010_OT_IMPED]
					  ,[OT010_CLI_TELCONT]
					  ,[OT010_OT_FECFINGTIA]
					  ,[OT010_OT_RETIRA]
					  ,CAST([OT010_OT_ANOMAL] AS VARCHAR(255)) 
					  ,CAST([OT010_OT_DIAGNO] AS VARCHAR(255))
					  ,CAST([OT010_OT_INCIDEN] AS VARCHAR(255))
					  ,[OT010_OT_TIPTALLCOD]
					  ,[OT010_OT_TIPTALL]
					  ,[OT010_OT_SUCCOD]
					  ,[OT010_OT_SUCU]
					  ,[OT010_OT_TIPTRABCOD]
					  ,[OT010_OT_TIPTRAB]
					  ,[OT010_OT_SERVICIO]
					  ,[OT010_OT_DETALLE]
--					  ,[OT010_OT_CARGOGRAL]
--					  ,[OT010_OT_CCTOCOD]
--					  ,[OT010_OT_CTROCTO]
					  ,[OT010_VH_CODID]
					  ,[OT010_VH_CODIGO]
					  ,[OT010_VH_DESCRIP]
					  ,[OT010_VH_DOMINIO]
					  ,[OT010_VH_MARCA]
					  ,[OT010_VH_MODELO]
					  ,[OT010_VH_SUBMODL]
					  ,[OT010_VH_MOTOR]
					  ,[OT010_VH_CHASIS]
					  ,[OT010_VH_KILOM]
				--      ,[OT010_REF_ID]
				--      ,[OT010_REF_COD]
				--      ,[OT010_REF_DESC]
				--      ,[OT010_VALEDETAL]
				--      ,[OT010_VALEORDEN]
				--      ,[OT010_VALEFECHA]
				--      ,[OT010_VALEDEPORIG]
				--      ,[OT010_VALEDEPDEST]
				--      ,[OT010_VALEUSUARIO]
				--      ,[OT010_REF_CANT]
				--      ,SUM([OT010_REF_CTOTOTAL]) AS [Q_TOT]
				--      ,SUM([OT010_REF_FCCPRANETO]) AS [PR_NET]
				--      ,SUM([OT010_REF_DESCTOTOTAL]) AS [DTO_TOT]
				--      ,SUM([OT010_REF_TOTNETO]) AS [TOT_NET]
				--      ,[OT010_REF_RUBRO]
				--      ,[OT010_REF_TIPO]
				--      ,[OT010_REF_CANAL]
					  ,[OT010_OT_USUARIO]
					  ,[OT010_OT_RECEPTOR]
					  ,[OT010_CLI_CIUDAD]
					  ,[OT010_CLI_PROV]
					  ,[OT010_CLI_EMPRESA]
					  ,[OT010_CLI_TIPO]
					  ,[OT010_CLI_CODPTAL]
					  ,[OT010_CLI_DIRCALLE]
					  ,[OT010_CLI_CELU]
					  ,[OT010_CLI_TELLABOR]
					  ,[OT010_CLI_TELPARTI]
					  ,[OT010_CLI_EMAIL]
					  ,[OT010_OT_FECHEJECU]
					  ,[OT010_OT_FECHAFINAL]
					  ,[OT010_OT_AVISOCLIENTE]
					  ,[OT010_OT_TIPOSERV]
					  ,[OT010_FV_ID]
					  ,[OT010_FV_NUMCOMP]
					  ,[OT010_FV_TOTCIVA]
					  ,[OT010_FV_FECHANUM]
					  ,[OT010_SS_VINCID]
					  ,[OT010_FV_CANTFAC]
				) AS OTAGR 
			-- Agrupa el cargo ya que hay varias OT que tienen distintos cargos.
			LEFT OUTER JOIN 
					(SELECT [OT010_OT_ID], CASE WHEN SUBSTRING([OT_Cargo],LEN([OT_Cargo]),1) = '/' THEN
								LEFT([OT_Cargo], LEN([OT_Cargo])-1)
								ELSE [OT_Cargo]
						  END  AS [OT_CargoItem]
					 FROM (
								SELECT [OT010_OT_ID], CASE WHEN [Cgo1] IS NULL THEN '' ELSE [Cgo1] + '/' END + 
															CASE WHEN [Cgo2] IS NULL THEN '' ELSE [Cgo2] + '/' END + 
															CASE WHEN [Cgo3] IS NULL THEN '' ELSE [Cgo3] + '/' END + 
															CASE WHEN [Cgo4] IS NULL THEN '' ELSE [Cgo4] + '/' END + 
															CASE WHEN [Cgo5] IS NULL THEN '' ELSE [Cgo5] + '/' END + 
															CASE WHEN [Cgo6] IS NULL THEN '' ELSE [Cgo6] + '/' END + 
															CASE WHEN [Cgo7] IS NULL THEN '' ELSE [Cgo7] + '/' END + 
															CASE WHEN [Cgo8] IS NULL THEN '' ELSE [Cgo8] + '/' END + 
															CASE WHEN [Cgo9] IS NULL THEN '' ELSE [Cgo9] + '/' END + 
															CASE WHEN [Cgo10] IS NULL THEN '' ELSE [Cgo10] + '/' END + 
															CASE WHEN [Cgo11] IS NULL THEN '' ELSE [Cgo11] + '/' END + 
															CASE WHEN [Cgo12] IS NULL THEN '' ELSE [Cgo12] 
													  END  AS [OT_Cargo]
														, CANT
								FROM (
										SELECT [OT010_OT_ID]
												, MIN(CASE WHEN [OT010_OT_CARGOITEM] IS NULL THEN 'A DEF' END) AS [Cgo1]
												, MIN(CASE [OT010_OT_CARGOITEM] WHEN 'Cliente' THEN 'Cliente' WHEN 'Clientes' THEN 'Cliente' WHEN 'Motcor - Clientes' THEN 'Cliente' END) AS [Cgo2]
												, MIN(CASE [OT010_OT_CARGOITEM] WHEN 'Empleados' THEN 'Empleados' END) AS [Cgo3]
												, MIN(CASE [OT010_OT_CARGOITEM] WHEN 'Gerencia' THEN 'Gerencia' END) AS [Cgo4]
												, MIN(CASE [OT010_OT_CARGOITEM] WHEN 'Repuestos' THEN 'Repuestos' END) AS [Cgo5]
												, MIN(CASE [OT010_OT_CARGOITEM] WHEN 'Garantias Fabrica' THEN 'Gtias Fabrica' WHEN 'Motcor - Garantias Fabrica' THEN 'Gtias Fabrica' END) AS [Cgo6]
												, MIN(CASE [OT010_OT_CARGOITEM] WHEN 'Motcor - Taller Mecanico Garantias Int' THEN 'PVTA Gtias Interna' WHEN 'Tagle - Taller Chapa y Pintura - Garantias Int.' THEN 'PVTA Gtias Interna' WHEN 'Taller Mecanico - Garantias Int.' THEN 'PVTA Gtias Interna' END) AS [Cgo7]
												, MIN(CASE [OT010_OT_CARGOITEM] WHEN 'Taller Mecanico Indumentaria Operario' THEN 'PVTA' WHEN 'Taller Mecanico Herramientas' THEN 'PVTA' END) AS [Cgo8]
												, MIN(CASE [OT010_OT_CARGOITEM] WHEN 'Tagle - Taller Chapa y Pintura - Ate. Clientes' THEN 'PVTA Ate. Clientes' WHEN 'Taller Mecanico - Ate. Clientes' THEN 'PVTA Ate. Clientes' END) AS [Cgo9]
												, MIN(CASE [OT010_OT_CARGOITEM] WHEN 'Ventas' THEN 'Ventas' WHEN 'VN Service Gratuito' THEN 'Ventas' WHEN 'VN Catalogo y Papeleria' THEN 'Ventas' WHEN 'VN Gastos Preentrega' THEN 'Ventas' WHEN  'VN Veh Uso Interno' THEN 'Ventas' END) AS [Cgo10]
												, MIN(CASE [OT010_OT_CARGOITEM] WHEN 'Usados' THEN 'Usados' END) AS [Cgo11]
												, MIN(CASE LEFT([OT010_OT_CARGOITEM],13) WHEN 'Planes Ahorro' THEN 'Planes' END) AS [Cgo12]
												, COUNT(*) AS CANT
										  FROM [PVTWEB].[dbo].[OT012_OTDET_PTE] WITH(NOLOCK)
--										  WHERE [OT010_OT_ID] = '6C6F7336-6B70-4898-B42D-A1F04A3554AA'
--											WHERE (LEFT([OT010_OT_CARGOITEM],4) <> 'Anul' AND LEFT([OT010_OT_CARGOITEM],4) <> 'Abie'
--													AND LEFT([OT010_OT_CARGOITEM],4) <> 'Ejec' AND LEFT([OT010_OT_CARGOITEM],4) <> 'Fina'
--													AND [OT010_OT_TIPTRAB] <> 'Mensual')
--												  AND [OT010_OT_SUCU] LIKE 'Tagle%'
								--		WHERE [OT010_OT_ID] = '0022B670-1205-47FC-B586-DE8D949749E9'
										--WHERE [OT010_OT_CCTOCOD] = '2020105'
										GROUP BY [OT010_OT_ID]
										--, [OT010_OT_CARGOGRAL]
								--		HAVING COUNT(*) > 1
								--		ORDER BY [OT010_OT_ID]
									) AS MIng
						) AS Cgo
					) AS CgoUni ON
					OTAGR.[OT010_OT_ID] = CgoUni.[OT010_OT_ID]
			-- Agrupas los centros de costos, ya que hay OT que imputan a varios centros de costos
			LEFT OUTER JOIN (
					SELECT [OT010_OT_ID], CASE WHEN SUBSTRING([OT_CtroCto],LEN([OT_CtroCto]),1) = ' / ' THEN
								LEFT([OT_CtroCto], LEN([OT_CtroCto])-1)
								ELSE [OT_CtroCto]
						  END  AS [OT_CtroCto]
					 FROM (
								SELECT [OT010_OT_ID], CASE WHEN [CtoCod01] IS NULL THEN '' ELSE [CtoCod01] + ' / ' END + 
															CASE WHEN [CtoCod02] IS NULL THEN '' ELSE [CtoCod02] + ' / ' END + 
															CASE WHEN [CtoCod03] IS NULL THEN '' ELSE [CtoCod03] + ' / ' END + 
															CASE WHEN [CtoCod04] IS NULL THEN '' ELSE [CtoCod04] + ' / ' END + 
															CASE WHEN [CtoCod05] IS NULL THEN '' ELSE [CtoCod05] + ' / ' END + 
															CASE WHEN [CtoCod06] IS NULL THEN '' ELSE [CtoCod06] + ' / ' END + 
															CASE WHEN [CtoCod07] IS NULL THEN '' ELSE [CtoCod07] + ' / ' END + 
															CASE WHEN [CtoCod08] IS NULL THEN '' ELSE [CtoCod08] + ' / ' END + 
															CASE WHEN [CtoCod09] IS NULL THEN '' ELSE [CtoCod09] + ' / ' END + 
															CASE WHEN [CtoCod10] IS NULL THEN '' ELSE [CtoCod10] + ' / ' END + 

															CASE WHEN [CtoCod11] IS NULL THEN '' ELSE [CtoCod11] + ' / ' END + 
															CASE WHEN [CtoCod12] IS NULL THEN '' ELSE [CtoCod12] + ' / ' END + 
															CASE WHEN [CtoCod13] IS NULL THEN '' ELSE [CtoCod13] + ' / ' END + 
															CASE WHEN [CtoCod14] IS NULL THEN '' ELSE [CtoCod14] + ' / ' END + 
															CASE WHEN [CtoCod15] IS NULL THEN '' ELSE [CtoCod15] + ' / ' END + 
															CASE WHEN [CtoCod16] IS NULL THEN '' ELSE [CtoCod16] + ' / ' END + 
															CASE WHEN [CtoCod17] IS NULL THEN '' ELSE [CtoCod17] + ' / ' END + 
															CASE WHEN [CtoCod18] IS NULL THEN '' ELSE [CtoCod18] + ' / ' END + 
															CASE WHEN [CtoCod19] IS NULL THEN '' ELSE [CtoCod19] + ' / ' END + 
															CASE WHEN [CtoCod20] IS NULL THEN '' ELSE [CtoCod20] + ' / ' END + 

															CASE WHEN [CtoCod21] IS NULL THEN '' ELSE [CtoCod21] + ' / ' END + 
															CASE WHEN [CtoCod22] IS NULL THEN '' ELSE [CtoCod22] + ' / ' END + 
															CASE WHEN [CtoCod23] IS NULL THEN '' ELSE [CtoCod23] + ' / ' END + 
															CASE WHEN [CtoCod24] IS NULL THEN '' ELSE [CtoCod24] + ' / ' END + 
															CASE WHEN [CtoCod25] IS NULL THEN '' ELSE [CtoCod25] + ' / ' END + 
															CASE WHEN [CtoCod26] IS NULL THEN '' ELSE [CtoCod26] + ' / ' END + 
															CASE WHEN [CtoCod27] IS NULL THEN '' ELSE [CtoCod27] + ' / ' END + 
															CASE WHEN [CtoCod28] IS NULL THEN '' ELSE [CtoCod28] + ' / ' END + 
															CASE WHEN [CtoCod29] IS NULL THEN '' ELSE [CtoCod29] + ' / ' END + 
															CASE WHEN [CtoCod30] IS NULL THEN '' ELSE [CtoCod30] + ' / ' END + 

															CASE WHEN [CtoCod31] IS NULL THEN '' ELSE [CtoCod31] + ' / ' END + 
															CASE WHEN [CtoCod32] IS NULL THEN '' ELSE [CtoCod32] + ' / ' END + 
															CASE WHEN [CtoCod33] IS NULL THEN '' ELSE [CtoCod33] + ' / ' END + 
															CASE WHEN [CtoCod34] IS NULL THEN '' ELSE [CtoCod34] + ' / ' END + 
															CASE WHEN [CtoCod35] IS NULL THEN '' ELSE [CtoCod35] + ' / ' END + 
															CASE WHEN [CtoCod36] IS NULL THEN '' ELSE [CtoCod36] + ' / ' END + 
															CASE WHEN [CtoCod37] IS NULL THEN '' ELSE [CtoCod37] + ' / ' END + 
															CASE WHEN [CtoCod38] IS NULL THEN '' ELSE [CtoCod38] 
													  END  AS [OT_CtroCto]
														, CANT
								FROM (
										SELECT [OT010_OT_ID]
												, MIN(CASE WHEN [OT010_OT_CCTOCOD] IS NULL THEN 'A DEF' END) AS [CtoCod01]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '1110600' THEN '1110600' + '-' + [GRL030_DESCABR]  END) AS [CtoCod02]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '1110400' THEN '1110400' + '-' + [GRL030_DESCABR] END) AS [CtoCod03]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '2020105' THEN '2020105' + '-' + [GRL030_DESCABR] END) AS [CtoCod04]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '1110100' THEN '1110100' + '-' + [GRL030_DESCABR] END) AS [CtoCod05]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '2020101' THEN '2020101' + '-' + [GRL030_DESCABR] END) AS [CtoCod06]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '4030105' THEN '4030105' + '-' + [GRL030_DESCABR] END) AS [CtoCod07]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '4030101' THEN '4030101' + '-' + [GRL030_DESCABR] END) AS [CtoCod08]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '1120600' THEN '1120600' + '-' + [GRL030_DESCABR] END) AS [CtoCod09]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '2020103' THEN '2020103' + '-' + [GRL030_DESCABR] END) AS [CtoCod10]

												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '1130600' THEN '1130600' + '-' + [GRL030_DESCABR] END) AS [CtoCod11]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '2020109' THEN '2020109' + '-' + [GRL030_DESCABR] END) AS [CtoCod12]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '1120400' THEN '1120400' + '-' + [GRL030_DESCABR] END) AS [CtoCod13]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '2020110' THEN '2020110' + '-' + [GRL030_DESCABR] END) AS [CtoCod14]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '2020106' THEN '2020106' + '-' + [GRL030_DESCABR] END) AS [CtoCod15]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '1130400' THEN '1130400' + '-' + [GRL030_DESCABR] END) AS [CtoCod16]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '1120100' THEN '1120100' + '-' + [GRL030_DESCABR] END) AS [CtoCod17]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '2020405' THEN '2020405' + '-' + [GRL030_DESCABR] END) AS [CtoCod18]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '1110300' THEN '1110300' + '-' + [GRL030_DESCABR] END) AS [CtoCod19]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '1130100' THEN '1130100' + '-' + [GRL030_DESCABR] END) AS [CtoCod20]

												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '2020401' THEN '2020401' + '-' + [GRL030_DESCABR] END) AS [CtoCod21]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '2020705' THEN '2020705' + '-' + [GRL030_DESCABR] END) AS [CtoCod22]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '2020406' THEN '2020406' + '-' + [GRL030_DESCABR] END) AS [CtoCod23]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '2020102' THEN '2020102' + '-' + [GRL030_DESCABR] END) AS [CtoCod24]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '2020701' THEN '2020701' + '-' + [GRL030_DESCABR] END) AS [CtoCod25]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '1120300' THEN '1120300' + '-' + [GRL030_DESCABR] END) AS [CtoCod26]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '4030102' THEN '4030102' + '-' + [GRL030_DESCABR] END) AS [CtoCod27]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '2020104' THEN '2020104' + '-' + [GRL030_DESCABR] END) AS [CtoCod28]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '2020403' THEN '2020403' + '-' + [GRL030_DESCABR] END) AS [CtoCod29]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '1130300' THEN '1130300' + '-' + [GRL030_DESCABR] END) AS [CtoCod30]

												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '4030405' THEN '4030405' + '-' + [GRL030_DESCABR] END) AS [CtoCod31]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '4030104' THEN '4030104' + '-' + [GRL030_DESCABR] END) AS [CtoCod32]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '4030109' THEN '4030109' + '-' + [GRL030_DESCABR] END) AS [CtoCod33]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '2020402' THEN '2020402' + '-' + [GRL030_DESCABR] END) AS [CtoCod34]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '2021301' THEN '2021301' + '-' + [GRL030_DESCABR] END) AS [CtoCod35]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '2020409' THEN '2020409' + '-' + [GRL030_DESCABR] END) AS [CtoCod36]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '1110900' THEN '1110900' + '-' + [GRL030_DESCABR] END) AS [CtoCod37]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '1110500' THEN '1110500' + '-' + [GRL030_DESCABR] END) AS [CtoCod38]

												, COUNT(*) AS CANT
										  FROM [PVTWEB].[dbo].[OT012_OTDET_PTE] AS OTD WITH(NOLOCK)
												LEFT OUTER JOIN 
																(SELECT [GRL030_CODIGO]
																	  ,[GRL030_DESCRIPC]
																	  ,[GRL030_DESCABR]
																	  ,[GRL030_ABRTIPO]
																	  ,[GRL030_AGR01]
																  FROM [PVTWEB].[dbo].[GRL030_ABRDESC] WITH(NOLOCK)
																) AS ABR ON
															OTD.[OT010_OT_CCTOCOD] = ABR.[GRL030_CODIGO]
--										  WHERE [OT010_OT_ID] = '6C6F7336-6B70-4898-B42D-A1F04A3554AA'
--											WHERE (LEFT([OT010_OT_CARGOITEM],4) <> 'Anul' AND LEFT([OT010_OT_CARGOITEM],4) <> 'Abie'
--													AND LEFT([OT010_OT_CARGOITEM],4) <> 'Ejec' AND LEFT([OT010_OT_CARGOITEM],4) <> 'Fina'
--													AND [OT010_OT_TIPTRAB] <> 'Mensual')
--												  AND [OT010_OT_SUCU] LIKE 'Tagle%'
								--		WHERE [OT010_OT_ID] = '0022B670-1205-47FC-B586-DE8D949749E9'
										--WHERE [OT010_OT_CCTOCOD] = '2020105'
										GROUP BY [OT010_OT_ID]
										--, [OT010_OT_CARGOGRAL]
								--		HAVING COUNT(*) > 1
								--		ORDER BY [OT010_OT_ID]
									) AS MIng
						) AS CtroCtos
					) AS CtroCto ON
					OTAGR.[OT010_OT_ID] = CtroCto.[OT010_OT_ID]
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
UPDATE [PVTWEB].[dbo].[GRL099_ACTREG] SET [GRL099_FECFIN] = CAST(GETDATE() AS DATETIME) WHERE [GRL099_CODID] = @NUEVOIDACT
-- ###################################################################################################################################
-- FIN - ACTCC_PASO 4
-- ##################################################################################################################################



