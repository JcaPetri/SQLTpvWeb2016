SELECT OT.MesOT AS OT010_OT_MES
		, OT.MesUltimoestado AS OT010_OT_MESULTEST
		, OT.MesTurno AS OT010_OT_MESTUR
		, OT.OTID AS OT010_OT_ID
		, OT.OrdenTrabajo AS OT010_OT_NUM
		, OT.DESTINATARIO_ID AS OT010_CLI_ID
		, OT.ClienteCOD AS OT010_CLI_COD
		, OT.Cliente AS OT010_CLI_DESC
		, OT.FechaOT AS OT010_OT_FECHA
		, OT.FechaUltimoEstado AS OT010_OT_FECULTEST
		, OT.Estado AS OT010_OT_ESTADO
		, OT.FechaVentaVehiculo AS OT010_OT_FECVTAVN
		, OT.Fechaturno AS OT010_OT_FECTURN
		, OT.Impedimento AS OT010_OT_IMPED
		, OT.TelefonoContacto AS OT010_CLI_TELCONT
		, OT.FechaFinGarantia AS OT010_OT_FECFINGTIA
		, OT.Retira AS OT010_OT_RETIRA
		, OT.Anomalias AS OT010_OT_ANOMAL
		, OT.Diagnostico AS OT010_OT_DIAGNO
		, OT.Incidentes AS OT010_OT_INCIDEN
		, OT.TipoTallerCod AS OT010_OT_TIPTALLCOD
		, OT.TipoTaller AS OT010_OT_TIPTALL
		, OT.SucursalCod AS OT010_OT_SUCCOD
		, OT.Sucursal AS OT010_OT_SUCU
		, OT.TipoTrabajoCod AS OT010_OT_TIPTRABCOD
		, OT.TipoTrabajo AS OT010_OT_TIPTRAB
		, OT.TipoService AS OT010_OT_SERVICIO
		, OT.Detalle AS OT010_OT_DETALLE
		, OT.Cargo AS OT010_OT_CARGOGRAL
		, OT.CentrocostosCOD AS OT010_OT_CCTOCOD
		, OT.Centrocostos AS OT010_OT_CTROCTO
		, OT.ProdID AS OT010_VH_CODID
		, OT.ProdCodigo AS OT010_VH_CODIGO
		, OT.DESCRIPCION AS OT010_VH_DESCRIP
		, OT.Dominio AS OT010_VH_DOMINIO
		, OT.Marca AS OT010_VH_MARCA
		, OT.Modelo AS OT010_VH_MODELO
		, OT.Submodelo AS OT010_VH_SUBMODL
		, OT.Motor AS OT010_VH_MOTOR
		, OT.NumeroChasis AS OT010_VH_CHASIS
		, OT.Kilometros AS OT010_VH_KILOM
		, OT.CodigoReferenciaID AS OT010_REF_ID
		, OT.CodigoReferencia AS OT010_REF_COD
		, OT.DescripcionReferencia AS OT010_REF_DESC
		, VAL.VALECOMP AS OT010_VALEDETAL
		, OT.VALEORDEN AS OT010_VALEORDEN
		, VAL.VALEFECHENT AS OT010_VALEFECHA
		, VAL.VALEDEPORIG AS OT010_VALEDEPORIG
		, VAL.VALEDEPDEST AS OT010_VALEDEPDEST
		, VAL.VALEUSU AS OT010_VALEUSUARIO
		, OT.Cantidad AS OT010_REF_CANT
		, OT.TotalCosto AS OT010_REF_CTOTOTAL
		, OT.NetoFacturaCompra AS OT010_REF_FCCPRANETO
		, OT.TotalDescuento AS OT010_REF_DESCTOTOTAL
		, OT.TotalNeto AS OT010_REF_TOTNETO
		, OT.Rubro AS OT010_REF_RUBRO
		, OT.Tipo AS OT010_REF_TIPO
		, OT.Canal AS OT010_REF_CANAL
		, OT.USUARIO AS OT010_OT_USUARIO
		, OT.Receptor AS OT010_OT_RECEPTOR
		, OT.CiudadCliente AS OT010_CLI_CIUDAD
		, OT.ProvinciaCliente AS OT010_CLI_PROV
		, OT.Empresa AS OT010_CLI_EMPRESA
		, OT.TipoCliente AS OT010_CLI_TIPO
		, OT.CodigoPostal AS OT010_CLI_CODPTAL
		, OT.CALLE AS OT010_CLI_DIRCALLE
		, OT.Celular AS OT010_CLI_CELU
		, OT.TelefonoLaboral AS OT010_CLI_TELLABOR
		, OT.TelefonoParticular AS OT010_CLI_TELPARTI
		, OT.Email AS OT010_CLI_EMAIL
		, OT.CargoOT AS OT010_OT_CARGOITEM
		, OT.FechaEjecucion AS OT010_OT_FECHEJECU
		, OT.FechaFinalizada AS OT010_OT_FECHAFINAL
		, OT.AvisoCliente AS OT010_OT_AVISOCLIENTE
		, OT.TipoService AS OT010_OT_TIPOSERV
		, FV.[FV_ID] AS OT010_FV_ID	-- FV.FVID
		, FV.[FV_NUMCOMP] AS OT010_FV_NUMCOMP	-- FV.FVNUMCOMP
		, FV.[FV_TOTALCIVA] AS OT010_FV_TOTCIVA	-- FV.FVTOTAL
		, FV.[FV_FECHNUM] AS OT010_FV_FECHANUM		-- CAST(SUBSTRING(FV.FVFECHANUM, 7, 2) + '/' + SUBSTRING(FV.FVFECHANUM, 5, 2) + '/' + SUBSTRING(FV.FVFECHANUM, 1, 4) AS datetime) AS OT010_FV_FECHANUM
		, OT.VINCSERVICIOS AS OT010_SS_VINCID
		, NULL AS OT010_FV_CANTFAC	-- cantfacturas.cant
--		, NC.NCID, NC.NCNUMCOMP, NC.NCTOTAL, NC.NCFECHANUM, cantnotasdecredito.cant AS CantNCre
FROM (
		-- OT SIN TRABAJO DE TERCEROS
		SELECT SUBSTRING(OT.FECHAULTIMOESTADO, 1, 4) + '/' + SUBSTRING(OT.FECHAACTUAL, 5, 2) AS MesOT
				, SUBSTRING(OT.FECHAULTIMOESTADO, 1, 4) + '/' + SUBSTRING(OT.FECHAULTIMOESTADO, 5, 2) AS MesUltimoestado
				, SUBSTRING(ud1.FechaHoraTurno, 1, 4) + '/' + SUBSTRING(ud1.FechaHoraTurno, 5, 2) AS MesTurno
				, OT.ID AS OTID
				, OT.NUMERODOCUMENTO AS OrdenTrabajo
				, OT.DESTINATARIO_ID
				, C1.CODIGO AS ClienteCOD
				, OT.NOMBREDESTINATARIO AS Cliente
				, CASE WHEN OT.FECHAACTUAL = NULL THEN NULL
						WHEN CAST(SUBSTRING(OT.FECHAACTUAL,1, 4) AS NUMERIC(18,0)) <= 1902 THEN NULL
						 WHEN CAST(SUBSTRING(OT.FECHAACTUAL,1, 4) AS NUMERIC(18,0)) > YEAR(GETDATE()) THEN NULL
						 ELSE CAST(SUBSTRING(OT.FECHAACTUAL, 7, 2) + '/' + SUBSTRING(OT.FECHAACTUAL, 5, 2) + '/' + SUBSTRING(OT.FECHAACTUAL,1, 4) AS datetime)
					END AS FechaOT
				, CASE WHEN OT.FECHAULTIMOESTADO = NULL THEN NULL
						WHEN CAST(SUBSTRING(OT.FECHAULTIMOESTADO,1, 4) AS NUMERIC(18,0)) <= 1902 THEN NULL
						 WHEN CAST(SUBSTRING(OT.FECHAULTIMOESTADO,1, 4) AS NUMERIC(18,0)) > YEAR(GETDATE()) THEN NULL
						 ELSE CAST(SUBSTRING(OT.FECHAULTIMOESTADO, 7, 2) + '/' + SUBSTRING(OT.FECHAULTIMOESTADO, 5, 2) + '/' + SUBSTRING(OT.FECHAULTIMOESTADO,1, 4) AS datetime)
					END AS FechaUltimoEstado
				, f.DESCRIPCION AS Estado
				, CASE WHEN ud1.FechaventaVehiculo = NULL THEN NULL
						WHEN CAST(SUBSTRING(ud1.FechaventaVehiculo,1, 4) AS NUMERIC(18,0)) <= 1902 THEN NULL
						 WHEN CAST(SUBSTRING(ud1.FechaventaVehiculo,1, 4) AS NUMERIC(18,0)) > YEAR(GETDATE()) THEN NULL
						 ELSE CAST(SUBSTRING(ud1.FechaventaVehiculo, 7, 2) + '/' + SUBSTRING(ud1.FechaventaVehiculo, 5, 2) + '/' + SUBSTRING(ud1.FechaventaVehiculo,1, 4) AS datetime)
					END AS FechaVentaVehiculo
				, CASE WHEN ud1.FechaHoraTurno = NULL THEN NULL
						WHEN CAST(SUBSTRING(ud1.FechaHoraTurno,1, 4) AS NUMERIC(18,0)) <= 1902 THEN NULL
						 WHEN CAST(SUBSTRING(ud1.FechaHoraTurno,1, 4) AS NUMERIC(18,0)) > YEAR(GETDATE()) THEN NULL
						 ELSE CAST(SUBSTRING(ud1.FechaHoraTurno, 7, 2) + '/' + SUBSTRING(ud1.FechaHoraTurno, 5, 2) + '/' + SUBSTRING(ud1.FechaHoraTurno,1, 4) +' '+substring(ud1.fechahoraturno,9,2)+':'+substring(ud1.fechahoraturno,11,2) AS datetime)
					END AS Fechaturno
				, itc11.nombre AS 'Impedimento'
				, ud1.TelContacto AS TelefonoContacto
				, ud1.FechaFinGarantia
				, ud1.Retira
				, ud1.Anomalias
				, ud1.Diagnostico
				, ud1.Incidentes
				, ud1.correoElectronico
				, itc1.CODIGO AS TipoTallerCod
				, itc1.NOMBRE AS TipoTaller
				, itc2.CODIGO AS SucursalCod
				, itc2.NOMBRE AS Sucursal
				, itc3.CODIGO AS TipoTrabajoCod
				, itc3.NOMBRE AS TipoTrabajo
				, OT.DETALLE AS Detalle
				, itc4.NOMBRE AS Cargo
				, cc.CODIGO AS CentrocostosCOD
				, cc.NOMBRE AS Centrocostos
				, Prod.ID AS ProdID
				, Prod.CODIGO AS ProdCodigo
				, Prod.DESCRIPCION
				, ProdUd3.Dominio
				, itc5.NOMBRE AS Marca
				, itc6.NOMBRE AS Modelo
				, itc7.NOMBRE AS Submodelo
				, itc8.CODIGO + ' - ' + itc8.NOMBRE AS Motor
				, ProdUd3.NumeroChasis
				, ud1.Kilometros
				, OT.ITEMSTRANSACCION_ID AS CodigoReferenciaID
				, ioT.NOMBREREFERENCIA AS CodigoReferencia
				, ioT.DESCRIPCION AS DescripcionReferencia
				, ioT.CANTIDAD2_CANTIDAD AS Cantidad
				, ud2.Costo * ioT.CANTIDAD2_CANTIDAD AS TotalCosto
				, 0 as NetoFacturaCompra
				, (ioT.VALOR2_IMPORTE * ioT.PORCENTAJEBONIFICACION / 100 * ioT.CANTIDAD2_CANTIDAD) AS TotalDescuento
				, ioT.TOTAL2_IMPORTE AS TotalNeto
				, re.Rubro
				, re.Tipo
				, ISNULL(itc9.CODIGO + ' - ' + itc9.NOMBRE, '') AS Canal
				, PF.USUARIO AS USUARIO
				, PF.NOMBRE AS Receptor
				, ciu.NOMBRE AS CiudadCliente
				, Pro.NOMBRE AS ProvinciaCliente
				, eo.DESCRIPCION AS Empresa
				, itc10.NOMBRE AS TipoCliente
				, dom.CODPOS AS CodigoPostal
				, dom.CALLE
				, ud4.Celular
				, ud4.TeLaboral AS TelefonoLaboral
				, ud4.TeParticular AS TelefonoParticular
				, de.DIRECCIONELECTRONICA AS 'Email'
				, itcc.NOMBRE AS 'CargoOT'
				, CASE WHEN UD1.FECHAEJECUCION = NULL THEN NULL
						WHEN CAST(SUBSTRING(UD1.FECHAEJECUCION,1, 4) AS NUMERIC(18,0)) <= 1902 THEN NULL
						 WHEN CAST(SUBSTRING(UD1.FECHAEJECUCION,1, 4) AS NUMERIC(18,0)) > YEAR(GETDATE()) THEN NULL
						 ELSE CAST(SUBSTRING(UD1.FECHAEJECUCION, 7, 2) + '/' + SUBSTRING(UD1.FECHAEJECUCION, 5, 2) + '/' + SUBSTRING(UD1.FECHAEJECUCION,1, 4) +' '+substring(UD1.FECHAEJECUCION,9,2)+':'+substring(UD1.FECHAEJECUCION,11,2) AS datetime)
					END AS FechaEjecucion
				, CASE WHEN HFF.FECHA = NULL THEN NULL
						WHEN CAST(SUBSTRING(HFF.FECHA,1, 4) AS NUMERIC(18,0)) <= 1902 THEN NULL
						 WHEN CAST(SUBSTRING(HFF.FECHA,1, 4) AS NUMERIC(18,0)) > YEAR(GETDATE()) THEN NULL
						 ELSE CAST(SUBSTRING(HFF.FECHA, 7, 2) + '/' + SUBSTRING(HFF.FECHA, 5, 2) + '/' + SUBSTRING(HFF.FECHA,1, 4) AS datetime)
					END AS FechaFinalizada
				, cast(ud1.AvisoCliente AS nvarchar(500)) AS AvisoCliente
				, TipoService.nombre AS TipoService
				, ioT.REFERENCIA_ID AS REFID
				, ioT.DETALLE AS VALEORDEN
				, ud1.Servicios_ID AS VINCSERVICIOS
				, FVMAX.[FVCLAVEFCULT] AS FVCLAVEULTEST
		FROM dbo.TRORDENVENTA AS OT WITH (nolock) 
					LEFT OUTER JOIN dbo.ITEMORDENVENTA AS ioT WITH (nolock) ON 
							OT.ITEMSTRANSACCION_ID  = ioT.BO_PLACE_ID
					INNER JOIN dbo.UD_ORDENTRABAJO AS ud1 WITH (nolock) ON 
							OT.BOEXTENSION_ID = ud1.ID 
					LEFT OUTER JOIN dbo.UD_ITEMORDENTRABAJO AS ud2 WITH (nolock) ON 
							ioT.BOEXTENSION_ID = ud2.ID  
					INNER JOIN dbo.FLAG AS f WITH (nolock) ON 
							OT.FLAG_ID = f.ID 
					LEFT OUTER JOIN dbo.PRODUCTO AS Prod WITH (nolock) ON 
							ud1.Vehiculo_ID = Prod.ID
					LEFT OUTER JOIN dbo.UD_PRODUCTO AS ProdUd3 WITH (nolock) ON 
							Prod.BOEXTENSION_ID = ProdUd3.ID 
					LEFT OUTER JOIN dbo.ITEMTIPOCLASIFICADOR AS itc1 WITH (nolock) ON 
							ud1.TipoTaller_ID = itc1.ID 
					LEFT OUTER JOIN dbo.ITEMTIPOCLASIFICADOR AS itc2 WITH (nolock) ON 
							ud1.Sucursal_ID = itc2.ID 
					LEFT OUTER JOIN  dbo.ITEMTIPOCLASIFICADOR AS itc3 WITH (nolock) ON 
							ud1.TipoTrabajo_ID = itc3.ID 
					LEFT OUTER JOIN dbo.ITEMTIPOCLASIFICADOR AS itc4 WITH (nolock) ON 
							ud2.Cargo_ID = itc4.ID 
					LEFT OUTER JOIN dbo.ITEMTIPOCLASIFICADOR AS itc11 WITH (nolock) ON 
							ud1.Impedimentos_ID = itc11.ID 
					LEFT OUTER JOIN dbo.ITEMTIPOCLASIFICADOR AS TipoService WITH (nolock) ON 
							ud1.tiposervice_id = TipoService.ID 
					LEFT OUTER JOIN dbo.CENTROCOSTOS AS cc WITH (nolock) ON 
							ioT.CENTROCOSTOS_ID = cc.ID 
					LEFT OUTER JOIN dbo.ITEMTIPOCLASIFICADOR AS itc5 WITH (nolock) ON 
							ProdUd3.OMarca_ID = itc5.ID 
					LEFT OUTER JOIN dbo.ITEMTIPOCLASIFICADOR AS itc6 WITH (nolock) ON 
							ProdUd3.OModelo_ID = itc6.ID 
					LEFT OUTER JOIN dbo.ITEMTIPOCLASIFICADOR AS itc7 WITH (nolock) ON 
							ProdUd3.OSubModelo_ID = itc7.ID 
					LEFT OUTER JOIN dbo.ITEMTIPOCLASIFICADOR AS itc8 WITH (nolock) ON 
							ProdUd3.OMotor_ID = itc8.ID 
					LEFT OUTER JOIN dbo.VP_Referencia_ AS re ON 
							ioT.REFERENCIA_ID = re.ID 
					LEFT OUTER JOIN dbo.ITEMTIPOCLASIFICADOR AS itc9 WITH (nolock) ON 
							ud2.Canal_ID = itc9.ID 
					LEFT OUTER JOIN dbo.EMPLEADO AS emp WITH (nolock) ON 
							ud1.Receptor_ID = emp.ID 
					LEFT OUTER JOIN dbo.CLIENTE AS c1 WITH (nolock) ON 
							OT.DESTINATARIO_ID = c1.ID 
					LEFT OUTER JOIN dbo.V_PERSONA PER ON 
							c1.ENTEASOCIADO_ID = PER.ID 
					LEFT OUTER JOIN dbo.DIRECCIONELECTRONICA DE WITH (nolock) ON 
							PER.DIRECELECTRONICAPRINCIPAL_ID  = DE.ID
					LEFT OUTER JOIN dbo.DOMICILIO AS dom WITH (nolock) ON 
							c1.DOMICILIOFACTURACION_ID = dom.ID 
					LEFT OUTER JOIN dbo.CIUDAD AS ciu WITH (nolock) ON 
							dom.CIUDAD_ID = ciu.ID 
					LEFT OUTER JOIN dbo.PROVINCIA AS Pro WITH (nolock) ON 
							dom.PROVINCIA_ID = Pro.ID 
					INNER JOIN dbo.V_UNIDADOPERATIVA AS uo ON 
							OT.UNIDADOPERATIVA_ID = uo.ID 
					INNER JOIN dbo.ESQUEMAOPERATIVO AS eo WITH (nolock) ON 
							uo.ESQUEMAOPERATIVO_ID = eo.ID 
					LEFT OUTER JOIN dbo.UD_CLIENTE AS ud4 WITH (nolock) ON 
							c1.BOEXTENSION_ID = ud4.ID 
					LEFT OUTER JOIN dbo.ITEMTIPOCLASIFICADOR AS itc10 WITH (nolock) ON 
							ud4.TipoCliente_ID = itc10.ID 
					LEFT OUTER JOIN dbo.ITEMTIPOCLASIFICADOR AS itcc WITH (nolock) ON 
							ud1.CARGO_ID = itcc.ID 
					LEFT OUTER JOIN dbo.PERSONAFISICA AS PF WITH (nolock) ON 
							emp.ENTEASOCIADO_ID = PF.ID 
					OUTER APPLY (SELECT TOP 1 *    
									FROM HISTORYFLAG HFF WITH (nolock)    
									WHERE HFF.OBJ_ID = OT.ID 
											AND 
										  HFF.FLAG_ID = '0F15BE4E-0C92-46C8-B6AB-DCB6F720D850'    
									ORDER BY FECHA DESC
								 ) AS HFF    
				   --dbo.UD_FACTURACOMPRA AS UDFACC WITH (nolock) ON UDFACC.ordentrabajo_id = OT.ID LEFT OUTER JOIN    
				   --dbo.TRFACTURACOMPRA AS trfacc WITH (nolock) ON trfacc.BOEXTENSION_ID = UDFACC.ID LEFT OUTER JOIN    
				   -- DATOS DE LA FACTURA
					LEFT OUTER JOIN (							-- COMO PUEDE HABER VARIAS FC POR CADA OT, YA QUE SE PUEDEN HABER ANULADO, LO QUE HAGO							-- ES OBTENER LA ULTIMA FACTURA REALIZADA PARA LA OT Y LUEGO, VUELVO A VINCULAR CON LA							-- FACTURA PARA OBTENER LOS DATOS							-- HAY QUE VERIFICAR QUE EL MAX ID ES EL MAXIMO							  SELECT TRPPL.TRANSACCION_ID									 , MAX(FECHAULTIMOESTADO + NUMERODOCUMENTO) AS [FVCLAVEFCULT]--									 , MAX(FVM.FECHAULTIMOESTADO) AS [FVFUE]-- EL BINARY(16) NO SIRVE PARA ORDENAR--									 , CAST(MAX(CAST(FVM.ID AS BINARY(16))) AS UNIQUEIDENTIFIER) AS [FVM_ID] --									 , MAX(CAST(FVM.ID AS BINARY(16))) AS IDBIN --								SELECT TOP 100 NUMERODOCUMENTO, FECHAULTIMOESTADO, FECHAULTIMOESTADO + NUMERODOCUMENTO AS CLAVEFCULT, *							  FROM dbo.TRFACTURAVENTA AS FVM WITH(NOLOCK)								LEFT OUTER JOIN dbo.AGENTEPROCESOPORLOTE AS APL WITH(NOLOCK) ON									FVM.GENERADAPOR_ID = APL.ID										AND									-- Esto lo que permite hacer un filtro en la tabla AgenteProcesoPorLote									APL.RELACIONORIGEN_ID = '84F37DBB-911D-46C6-8645-92CEE27283D8'		-- De  OT a Factura Venta RT								LEFT OUTER JOIN TRPROCESOPORLOTE AS TRPPL WITH(NOLOCK) ON									TRPPL.BO_PLACE_ID = APL.TRSORIGEN_ID											AND									-- Esto hace un filtro sobre la tabla TRProcesoPorLote									TRPPL.RELACION_ID = '84F37DBB-911D-46C6-8645-92CEE27283D8'	-- De  OT a Factura Venta RT--								WHERE TRPPL.TRANSACCION_ID = '220FF745-7A6B-4E59-9436-7D6F1D450129'								GROUP BY TRPPL.TRANSACCION_ID
							 ) AS FVMAX ON 
								OT.ID = FVMAX.TRANSACCION_ID
		WHERE (OT.LOCKSTATUS = 0)
--				AND OT.NUMERODOCUMENTO = '21486'
		-- Sacamos trabajos de terceros, esto se pone en otra tabla
	) AS OT
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
			-- AQU� HACELA UNION CON VENTAS
			LEFT OUTER JOIN (
							 SELECT TEI.NOMBRE AS VALECOMP
									, TEI.USUARIO AS VALEUSU
									, TEI.FECHAENTREGA AS VALEFECHENT
									, TEI.NOMBREORIGINANTE AS VALEDEPORIG
									, TEI.NOMBREDESTINATARIO AS VALEDEPDEST
									, UDP.OrdenTrabajo_ID, ITEI.REFERENCIATIPO_ID, ITEI.NOMBRETR AS VALE, TEI.ID, UDP.BO_OWNER_ID
							  FROM ITEMEGRESOINVENTARIO AS ITEI with(nolock)
									INNER JOIN TREGRESOINVENTARIO AS TEI WITH (nolock) ON
										ITEI.PLACEOWNER_ID = TEI.ID
									INNER JOIN UD_VALEENTREGAPIEZAS AS UDP WITH (nolock) ON
										TEI.ID = UDP.BO_OWNER_ID
							  ) AS VAL ON
									OT.OTID = VAL.OrdenTrabajo_ID
										AND
									OT.REFID = VAL.REFERENCIATIPO_ID
			LEFT OUTER JOIN (							-- TOMA LOS DATOS DE LA �LTIMA FACTURA DE LA OT							  SELECT TRPPL.TRANSACCION_ID								    , FV.GENERADAPOR_ID									, FV.ID AS [FV_ID]									, FV.NOMBRE AS [FV_NUMCOMP]									, FV.VALORTOTAL AS [FV_TOTALCIVA]									, FV.FECHAULTIMOESTADO AS [FV_FECHNUM]									, FV.FECHAULTIMOESTADO + FV.[NUMERODOCUMENTO] AS [FVCLAULTEST]							  FROM dbo.TRFACTURAVENTA AS FV WITH(NOLOCK)								LEFT OUTER JOIN dbo.AGENTEPROCESOPORLOTE AS APL WITH(NOLOCK) ON									FV.GENERADAPOR_ID = APL.ID										AND									-- Esto lo que permite hacer un filtro en la tabla AgenteProcesoPorLote									APL.RELACIONORIGEN_ID = '84F37DBB-911D-46C6-8645-92CEE27283D8'		-- De  OT a Factura Venta RT								LEFT OUTER JOIN TRPROCESOPORLOTE AS TRPPL WITH(NOLOCK) ON									TRPPL.BO_PLACE_ID = APL.TRSORIGEN_ID											AND									-- Esto hace un filtro sobre la tabla TRProcesoPorLote									TRPPL.RELACION_ID = '84F37DBB-911D-46C6-8645-92CEE27283D8'	-- De  OT a Factura Venta RT							) AS FV ON
								OT.[OTID] = FV.TRANSACCION_ID
									AND 
								OT.[FVCLAVEULTEST] = FV.[FVCLAULTEST]
--WHERE OT.OTID = '220FF745-7A6B-4E59-9436-7D6F1D450129'
--WHERE OT.OTID = '6E226B3B-F5EC-4D2D-B3CC-BBBB116EC1DB'--WHERE OT.Estado <> 'Cerrada' AND OT.Estado <> 'Anulada'			