--SELECT DISTINCT  TOP 100 
--		Empresa
--		, Sucursal
--		, TipoTaller
--		, OrdenTrabajo
--		, CAST(Fechaturno AS datetime) AS Fechaturno
--		, CAST(FechaOT AS datetime) AS FechaOT
--		, FechaEjecucion
--		, FechaFinalizada AS FechaFinalizada
--		, Estado
--		, Impedimento
--		, Receptor
--		, Cliente
--		, Modelo
--		, Submodelo
--		, NumeroChasis
--		, Dominio
--		, Kilometros
--		, TipoTrabajo
--		, Incidentes
--		, TelefonoContacto
--		, Celular
--		, TelefonoParticular
--		, TelefonoLaboral
--		, Factura
--		, CAST(FechaFactura AS datetime) AS FechaFactura
--		, CargoOT
--		, SUM(Cantidad) AS cantidad
--		, SUM(TotalCosto) AS TotalCosto
--		, SUM(TotalDescuento) AS TotalDescuento
--		, SUM(TotalNetoRepuestos) AS TotalNetoRepuestos
--		, SUM(TotalNetoMOTerceros) AS TotalNetoMOTerceros
--		, SUM(TotalNetoMOPropia) AS TotalNetoMOPropia
--		, SUM(TotalFactura) AS TotalFactura
--		, TipoCliente
--		, CALLE
--		, CiudadCliente
--		, CodigoPostal
--		, ProvinciaCliente
--		, Marca
--		, Detalle
--		, DESCRIPCION
--		, Motor
--		, CAST(FechaVentaVehiculo AS datetime) AS FechaVentaVehiculo
--		, CAST(SUBSTRING(FechaFinGarantia, 1, 8) AS datetime) AS FechaFinGarantia
--		, Retira
--		, CAST(FechaUltimoEstado AS datetime) AS FechaUltimoEstado
--		, Email
--		, MesOT
--		, MesUltimoestado
--		, MesTurno
--		, (SELECT TOP 1 DESCRIPCION
--			FROM ITEMORDENVENTA IOV WITH (nolock) 
--				INNER JOIN TRORDENVENTA OT WITH (nolock) ON 
--					IOV.PLACEOWNER_ID = OT.ID
--			WHERE Q.ORDENTRABAJO = OT.NUMERODOCUMENTO 
--				AND OT.TIPOTRANSACCION_ID = 'AEDA2553-10E7-4258-9E74-ACC1EAE15580'
--			ORDER BY IOV.NUMEROITEM) AS PrimerItem
--		, Anulada AS 'AnuladaPorComprobante'
--		, TipoService
--		, AvisoCliente
--	FROM (
		  SELECT top 100 VP_OrdenTrabajo.OrdenTrabajo
				, VP_OrdenTrabajo.Cliente
				, VP_OrdenTrabajo.FechaOT
				, VP_OrdenTrabajo.FechaFinalizada
				, VP_OrdenTrabajo.Estado
				, VP_OrdenTrabajo.FechaVentaVehiculo
				, VP_OrdenTrabajo.Fechaturno
				, VP_OrdenTrabajo.TelefonoContacto
				, VP_OrdenTrabajo.FechaFinGarantia
				, VP_OrdenTrabajo.Retira
				, VP_OrdenTrabajo.TipoTaller
				, VP_OrdenTrabajo.TipoTrabajo
				, VP_OrdenTrabajo.Detalle
				, VP_OrdenTrabajo.DESCRIPCION
				, VP_OrdenTrabajo.Dominio
				, VP_OrdenTrabajo.Marca
				, VP_OrdenTrabajo.Modelo
				, VP_OrdenTrabajo.Submodelo
				, VP_OrdenTrabajo.Motor
				, VP_OrdenTrabajo.NumeroChasis
				, VP_OrdenTrabajo.Kilometros
				, VP_OrdenTrabajo.Receptor
				, VP_OrdenTrabajo.CiudadCliente
				, VP_OrdenTrabajo.ProvinciaCliente
				, VP_OrdenTrabajo.CodigoReferencia
				, VP_OrdenTrabajo.DescripcionReferencia
				, 0 AS Cantidad
				, 0 AS TotalCosto
				, 0 AS TotalDescuento
				, 0 AS TotalNetoRepuestos
				, 0 AS TotalNetoMOTerceros
				, 0 AS TotalNetoMOPropia
				, fv.VALORTOTAL AS TotalFactura
				, fv.NOMBRE AS Factura
				, SUBSTRING(fv.FECHAACTUAL, 7, 2) + '/' + SUBSTRING(fv.FECHAACTUAL, 5, 2) + '/' + SUBSTRING(fv.FECHAACTUAL, 1, 4) AS FechaFactura
				, VP_OrdenTrabajo.Sucursal
				, VP_OrdenTrabajo.Empresa
				, VP_OrdenTrabajo.TipoCliente
				, SUBSTRING(VP_OrdenTrabajo.Incidentes, 1, 255) AS Incidentes
				, VP_OrdenTrabajo.MesOT
				, VP_OrdenTrabajo.MesUltimoestado
				, VP_OrdenTrabajo.MesTurno
				, VP_OrdenTrabajo.CodigoPostal
				, VP_OrdenTrabajo.CALLE
				, VP_OrdenTrabajo.Celular
				, VP_OrdenTrabajo.TelefonoLaboral
				, VP_OrdenTrabajo.TelefonoParticular
				, VP_OrdenTrabajo.CargoOT
				, VP_OrdenTrabajo.FechaEjecucion
				, VP_OrdenTrabajo.FechaUltimoEstado
				, VP_OrdenTrabajo.impedimento AS Impedimento
				, VP_OrdenTrabajo.Email
				, cantfacturas.cant AS fac
				, cantnotasdecredito.cant AS nota
				, CASE WHEN cantfacturas.cant = cantnotasdecredito.cant THEN 'SI' ELSE 'NO' END AS Anulada
				, VP_OrdenTrabajo.TipoService
				, VP_OrdenTrabajo.AvisoCliente
select top 100 *
			FROM dbo.VP_OrdenTrabajo AS VP_OrdenTrabajo WITH (nolock) 
				OUTER APPLY	(SELECT TOP 1 TROV.NUMERODOCUMENTO
										, tpp.TRANSACCION_ID
										, FV.NOMBRE
										, FV.VALORTOTAL
										, FV.FECHAACTUAL
                              FROM dbo.TRPROCESOPORLOTE AS tpp WITH (nolock) 
								LEFT JOIN dbo.AGENTEPROCESOPORLOTE AS app WITH (nolock) ON 
									tpp.BO_PLACE_ID = app.TRSORIGEN_ID 
								LEFT JOIN dbo.TRFACTURAVENTA AS fv WITH (nolock) ON 
									app.ID = fv.GENERADAPOR_ID AND FV.ESTADO <> 'N' 
								LEFT JOIN dbo.TRORDENVENTA AS TROV WITH (nolock) ON 
									TPP.TRANSACCION_ID = TROV.ID
							  WHERE ((tpp.RELACION_ID IS NULL) OR (tpp.RELACION_ID = '84F37DBB-911D-46C6-8645-92CEE27283D8') OR (tpp.RELACION_ID = '596F22CD-7F97-4681-A154-15AB55FA1040')) 
									AND TROV.ID = TPP.TRANSACCION_ID 
									AND FV.ESTADO <> 'N' 
									AND TROV.NUMERODOCUMENTO = VP_OrdenTrabajo.ORDENTRABAJO
							 ) AS FV
				LEFT JOIN (SELECT TROV.NUMERODOCUMENTO, count(*) AS cant
                                    /*tpp.TRANSACCION_ID, FV.NOMBRE, FV.VALORTOTAL, FV.FECHAACTUAL*/ 
							FROM dbo.TRPROCESOPORLOTE AS tpp WITH (nolock) 
								LEFT JOIN dbo.AGENTEPROCESOPORLOTE AS app WITH (nolock) ON 
									tpp.BO_PLACE_ID = app.TRSORIGEN_ID 
								LEFT JOIN dbo.TRFACTURAVENTA AS fv WITH (nolock) ON 
									app.ID = fv.GENERADAPOR_ID AND FV.ESTADO <> 'N' 
								LEFT JOIN dbo.TRORDENVENTA AS TROV WITH (nolock) ON 
									TPP.TRANSACCION_ID = TROV.ID
                            WHERE ((tpp.RELACION_ID IS NULL) OR (tpp.RELACION_ID = '84F37DBB-911D-46C6-8645-92CEE27283D8') OR (tpp.RELACION_ID = '596F22CD-7F97-4681-A154-15AB55FA1040')) 
									AND TROV.ID = TPP.TRANSACCION_ID 
									AND FV.ESTADO <> 'N'
                            GROUP BY TROV.NUMERODOCUMENTO
							) AS cantfacturas ON 
									VP_OrdenTrabajo.ORDENTRABAJO  = cantfacturas.NUMERODOCUMENTO
-- preguntar que hace
				LEFT JOIN (SELECT TROV.NUMERODOCUMENTO, count(*)AS cant
                                    /*tpp.TRANSACCION_ID, FV.NOMBRE, FV.VALORTOTAL, FV.FECHAACTUAL*/ FROM dbo.TRPROCESOPORLOTE AS tpp WITH (nolock) LEFT 
                                                           JOIN
                                                           dbo.AGENTEPROCESOPORLOTE AS app WITH (nolock) ON tpp.BO_PLACE_ID = app.TRSORIGEN_ID LEFT JOIN
                                                           dbo.TRFACTURAVENTA AS fv WITH (nolock) ON app.ID = fv.GENERADAPOR_ID AND FV.ESTADO <> 'N' LEFT JOIN
                                                           trcreditoventa c WITH (nolock) ON c.vinculotr_id = fv.id LEFT JOIN
                                                           dbo.TRORDENVENTA AS TROV WITH (nolock) ON TPP.TRANSACCION_ID = TROV.ID
                                    WHERE      ((tpp.RELACION_ID IS NULL) OR
                                                           (tpp.RELACION_ID = '84F37DBB-911D-46C6-8645-92CEE27283D8') OR
                                                           (tpp.RELACION_ID = '596F22CD-7F97-4681-A154-15AB55FA1040')) AND TROV.ID = TPP.TRANSACCION_ID AND 
                                                           FV.ESTADO <> 'N' AND 
                                                           c.TIPOTRANSACCION_ID = '{FF5DA972-CD50-4FF6-B1DD-EE55647306B0}'
                                    /*order by trov.numerodocumento*/	
									GROUP BY TROV.NUMERODOCUMENTO
							) AS cantnotasdecredito ON 
										VP_OrdenTrabajo.ORDENTRABAJO = cantnotasdecredito.NUMERODOCUMENTO
WHERE VP_OrdenTrabajo.OrdenTrabajo = '1011689'

--					WHERE VP_OrdenTrabajo.Estado = 'Abierta'
--					WHERE VP_OrdenTrabajo.OrdenTrabajo = '19832'
--       GROUP BY fv.NOMBRE, SUBSTRING(fv.FECHAACTUAL, 7, 2) + '/' + SUBSTRING(fv.FECHAACTUAL, 5, 2) + '/' + SUBSTRING(fv.FECHAACTUAL, 1, 4), 
--                              VP_OrdenTrabajo.OrdenTrabajo, VP_OrdenTrabajo.Cliente, VP_OrdenTrabajo.FechaOT, VP_OrdenTrabajo.FechaFinalizada, 
--                              VP_OrdenTrabajo.Estado, VP_OrdenTrabajo.FechaVentaVehiculo, VP_OrdenTrabajo.Fechaturno, VP_OrdenTrabajo.TelefonoContacto, 
--                              VP_OrdenTrabajo.FechaFinGarantia, VP_OrdenTrabajo.Retira, VP_OrdenTrabajo.TipoTaller, VP_OrdenTrabajo.TipoTrabajo, 
--                              VP_OrdenTrabajo.Detalle, VP_OrdenTrabajo.DESCRIPCION, VP_OrdenTrabajo.Dominio, VP_OrdenTrabajo.Marca, VP_OrdenTrabajo.Modelo, 
--                              VP_OrdenTrabajo.Submodelo, VP_OrdenTrabajo.Motor, VP_OrdenTrabajo.NumeroChasis, VP_OrdenTrabajo.Kilometros, 
--                              VP_OrdenTrabajo.Receptor, VP_OrdenTrabajo.CiudadCliente, VP_OrdenTrabajo.ProvinciaCliente, VP_OrdenTrabajo.Sucursal, 
--                              VP_OrdenTrabajo.Empresa, VP_OrdenTrabajo.TipoCliente, SUBSTRING(VP_OrdenTrabajo.Incidentes, 1, 255), VP_OrdenTrabajo.MesOT, 
--                              VP_OrdenTrabajo.MesUltimoestado, VP_OrdenTrabajo.MesTurno, VP_OrdenTrabajo.CodigoPostal, VP_OrdenTrabajo.CALLE, 
--                              VP_OrdenTrabajo.Celular, VP_OrdenTrabajo.TelefonoLaboral, VP_OrdenTrabajo.TelefonoParticular, fv.VALORTOTAL, 
--                              VP_OrdenTrabajo.CargoOT, VP_OrdenTrabajo.FechaEjecucion, VP_OrdenTrabajo.FechaUltimoEstado, VP_OrdenTrabajo.impedimento, 
--                              VP_OrdenTrabajo.Email, cantfacturas.cant, cantnotasdecredito.cant, VP_OrdenTrabajo.TipoService, VP_OrdenTrabajo.AvisoCliente
--       UNION ALL
--                       SELECT     VP_OrdenTrabajo.OrdenTrabajo, VP_OrdenTrabajo.Cliente, VP_OrdenTrabajo.FechaOT, VP_OrdenTrabajo.FechaFinalizada, 
--                                             VP_OrdenTrabajo.Estado, VP_OrdenTrabajo.FechaVentaVehiculo, VP_OrdenTrabajo.Fechaturno, VP_OrdenTrabajo.TelefonoContacto, 
--                                             VP_OrdenTrabajo.FechaFinGarantia, VP_OrdenTrabajo.Retira, VP_OrdenTrabajo.TipoTaller, VP_OrdenTrabajo.TipoTrabajo, 
--                                             VP_OrdenTrabajo.Detalle, VP_OrdenTrabajo.DESCRIPCION, VP_OrdenTrabajo.Dominio, VP_OrdenTrabajo.Marca, VP_OrdenTrabajo.Modelo, 
--                                             VP_OrdenTrabajo.Submodelo, VP_OrdenTrabajo.Motor, VP_OrdenTrabajo.NumeroChasis, VP_OrdenTrabajo.Kilometros, 
--                                             VP_OrdenTrabajo.Receptor, VP_OrdenTrabajo.CiudadCliente, VP_OrdenTrabajo.ProvinciaCliente, SUM(ISNULL(VP_OrdenTrabajo.Cantidad, 
--                                             0)) AS Cantidad, SUM(ISNULL(VP_OrdenTrabajo.TotalCosto, 0)) AS TotalCosto, SUM(ISNULL(VP_OrdenTrabajo.TotalDescuento, 0)) 
--                                             AS TotalDescuento, SUM(ISNULL(VP_OrdenTrabajo.TotalNeto, 0)) AS TotalNetoRepuestos, 0 AS TotalNetoMOTerceros, 
--                                             0 AS TotalNetoMOPropia, 0 AS TotalFactura, fv.NOMBRE AS Factura, SUBSTRING(fv.FECHAACTUAL, 7, 2) 
--                                             + '/' + SUBSTRING(fv.FECHAACTUAL, 5, 2) + '/' + SUBSTRING(fv.FECHAACTUAL, 1, 4) AS FechaFactura, VP_OrdenTrabajo.Sucursal, 
--                                             VP_OrdenTrabajo.Empresa, VP_OrdenTrabajo.TipoCliente, SUBSTRING(VP_OrdenTrabajo.Incidentes, 1, 255) AS Incidentes, 
--                                             VP_OrdenTrabajo.MesOT, VP_OrdenTrabajo.MesUltimoestado, VP_OrdenTrabajo.MesTurno, VP_OrdenTrabajo.CodigoPostal, 
--                                             VP_OrdenTrabajo.CALLE, VP_OrdenTrabajo.Celular, VP_OrdenTrabajo.TelefonoLaboral, VP_OrdenTrabajo.TelefonoParticular, 
--                                             VP_OrdenTrabajo.CargoOT, VP_OrdenTrabajo.FechaEjecucion, VP_OrdenTrabajo.FechaUltimoEstado, 
--                                             VP_OrdenTrabajo.impedimento AS Impedimento, VP_OrdenTrabajo.Email, cantfacturas.cant AS fac, cantnotasdecredito.cant AS nota, 
--                                             CASE WHEN cantfacturas.cant = cantnotasdecredito.cant THEN 'SI' ELSE 'NO' END AS Anulada, VP_OrdenTrabajo.TipoService, 
--                                             VP_OrdenTrabajo.AvisoCliente
--                       FROM         dbo.VP_OrdenTrabajo AS VP_OrdenTrabajo OUTER APPLY
--                                                 (SELECT     TOP 1 TROV.NUMERODOCUMENTO, tpp.TRANSACCION_ID, FV.NOMBRE, FV.VALORTOTAL, FV.FECHAACTUAL
--                                                   FROM          dbo.TRPROCESOPORLOTE AS tpp WITH (nolock) LEFT JOIN
--                                                                          dbo.AGENTEPROCESOPORLOTE AS app WITH (nolock) ON tpp.BO_PLACE_ID = app.TRSORIGEN_ID LEFT JOIN
--                                                                          dbo.TRFACTURAVENTA AS fv WITH (nolock) ON app.ID = fv.GENERADAPOR_ID AND FV.ESTADO <> 'N' LEFT JOIN
--                                                                          dbo.TRORDENVENTA AS TROV WITH (nolock) ON TPP.TRANSACCION_ID = TROV.ID
--                                                   WHERE      ((tpp.RELACION_ID IS NULL) OR
--                                                                          (tpp.RELACION_ID = '84F37DBB-911D-46C6-8645-92CEE27283D8') OR
--                                                                          (tpp.RELACION_ID = '596F22CD-7F97-4681-A154-15AB55FA1040')) AND TROV.ID = TPP.TRANSACCION_ID AND 
--                                                                          FV.ESTADO <> 'N' AND TROV.NUMERODOCUMENTO = VP_OrdenTrabajo.ORDENTRABAJO) AS FV LEFT JOIN
--                                                 (SELECT     TROV.NUMERODOCUMENTO, count(*) 
--                                                                          AS cant
--                                                   /*tpp.TRANSACCION_ID, FV.NOMBRE, FV.VALORTOTAL, FV.FECHAACTUAL*/ FROM dbo.TRPROCESOPORLOTE AS tpp WITH (nolock) LEFT 
--                                                                          JOIN
--                                                                          dbo.AGENTEPROCESOPORLOTE AS app WITH (nolock) ON tpp.BO_PLACE_ID = app.TRSORIGEN_ID LEFT JOIN
--                                                                          dbo.TRFACTURAVENTA AS fv WITH (nolock) ON app.ID = fv.GENERADAPOR_ID AND FV.ESTADO <> 'N' LEFT JOIN
--                                                                          dbo.TRORDENVENTA AS TROV WITH (nolock) ON TPP.TRANSACCION_ID = TROV.ID
--                                                   WHERE      ((tpp.RELACION_ID IS NULL) OR
--                                                                          (tpp.RELACION_ID = '84F37DBB-911D-46C6-8645-92CEE27283D8') OR
--                                                                          (tpp.RELACION_ID = '596F22CD-7F97-4681-A154-15AB55FA1040')) AND TROV.ID = TPP.TRANSACCION_ID AND 
--                                                                          FV.ESTADO <> 'N'
--                                                   GROUP BY TROV.NUMERODOCUMENTO) AS cantfacturas ON 
--                                             cantfacturas.NUMERODOCUMENTO = VP_OrdenTrabajo.ORDENTRABAJO LEFT JOIN
--                                                 (SELECT     TROV.NUMERODOCUMENTO, count(*) 
--                                                                          AS cant
--                                                   /*tpp.TRANSACCION_ID, FV.NOMBRE, FV.VALORTOTAL, FV.FECHAACTUAL*/ FROM dbo.TRPROCESOPORLOTE AS tpp WITH (nolock) LEFT 
--                                                                          JOIN
--                                                                          dbo.AGENTEPROCESOPORLOTE AS app WITH (nolock) ON tpp.BO_PLACE_ID = app.TRSORIGEN_ID LEFT JOIN
--                                                                          dbo.TRFACTURAVENTA AS fv WITH (nolock) ON app.ID = fv.GENERADAPOR_ID AND FV.ESTADO <> 'N' LEFT JOIN
--                                                                          trcreditoventa c WITH (nolock) ON c.vinculotr_id = fv.id LEFT JOIN
--                                                                          dbo.TRORDENVENTA AS TROV WITH (nolock) ON TPP.TRANSACCION_ID = TROV.ID
--                                                   WHERE      ((tpp.RELACION_ID IS NULL) OR
--                                                                          (tpp.RELACION_ID = '84F37DBB-911D-46C6-8645-92CEE27283D8') OR
--                                                                          (tpp.RELACION_ID = '596F22CD-7F97-4681-A154-15AB55FA1040')) AND TROV.ID = TPP.TRANSACCION_ID AND 
--                                                                          FV.ESTADO <> 'N' AND 
--                                                                          c.TIPOTRANSACCION_ID = '{FF5DA972-CD50-4FF6-B1DD-EE55647306B0}'
--                                                   /*order by trov.numerodocumento*/ GROUP BY TROV.NUMERODOCUMENTO) AS cantnotasdecredito ON 
--                                             cantnotasdecredito.NUMERODOCUMENTO = VP_OrdenTrabajo.ORDENTRABAJO
--                       WHERE     (VP_OrdenTrabajo.Tipo = 'Producto')
--                       GROUP BY fv.NOMBRE, SUBSTRING(fv.FECHAACTUAL, 7, 2) + '/' + SUBSTRING(fv.FECHAACTUAL, 5, 2) + '/' + SUBSTRING(fv.FECHAACTUAL, 1, 4), 
--                                             VP_OrdenTrabajo.OrdenTrabajo, VP_OrdenTrabajo.Cliente, VP_OrdenTrabajo.FechaOT, VP_OrdenTrabajo.FechaFinalizada, 
--                                             VP_OrdenTrabajo.Estado, VP_OrdenTrabajo.FechaVentaVehiculo, VP_OrdenTrabajo.Fechaturno, VP_OrdenTrabajo.TelefonoContacto, 
--                                             VP_OrdenTrabajo.FechaFinGarantia, VP_OrdenTrabajo.Retira, VP_OrdenTrabajo.TipoTaller, VP_OrdenTrabajo.TipoTrabajo, 
--                                             VP_OrdenTrabajo.Detalle, VP_OrdenTrabajo.DESCRIPCION, VP_OrdenTrabajo.Dominio, VP_OrdenTrabajo.Marca, VP_OrdenTrabajo.Modelo, 
--                                             VP_OrdenTrabajo.Submodelo, VP_OrdenTrabajo.Motor, VP_OrdenTrabajo.NumeroChasis, VP_OrdenTrabajo.Kilometros, 
--                                             VP_OrdenTrabajo.Receptor, VP_OrdenTrabajo.CiudadCliente, VP_OrdenTrabajo.ProvinciaCliente, VP_OrdenTrabajo.Sucursal, 
--                                             VP_OrdenTrabajo.Empresa, VP_OrdenTrabajo.TipoCliente, SUBSTRING(VP_OrdenTrabajo.Incidentes, 1, 255), VP_OrdenTrabajo.MesOT, 
--                                             VP_OrdenTrabajo.MesUltimoestado, VP_OrdenTrabajo.MesTurno, VP_OrdenTrabajo.CodigoPostal, VP_OrdenTrabajo.CALLE, 
--                                             VP_OrdenTrabajo.Celular, VP_OrdenTrabajo.TelefonoLaboral, VP_OrdenTrabajo.TelefonoParticular, fv.VALORTOTAL, 
--                                             VP_OrdenTrabajo.CargoOT, VP_OrdenTrabajo.FechaEjecucion, VP_OrdenTrabajo.FechaUltimoEstado, VP_OrdenTrabajo.impedimento, 
--                                             VP_OrdenTrabajo.Email, cantfacturas.cant, cantnotasdecredito.cant, VP_OrdenTrabajo.TipoService, VP_OrdenTrabajo.AvisoCliente
--                       UNION ALL
--                       SELECT     VP_OrdenTrabajo.OrdenTrabajo, VP_OrdenTrabajo.Cliente, VP_OrdenTrabajo.FechaOT, VP_OrdenTrabajo.FechaFinalizada, 
--                                             VP_OrdenTrabajo.Estado, VP_OrdenTrabajo.FechaVentaVehiculo, VP_OrdenTrabajo.Fechaturno, VP_OrdenTrabajo.TelefonoContacto, 
--                                             VP_OrdenTrabajo.FechaFinGarantia, VP_OrdenTrabajo.Retira, VP_OrdenTrabajo.TipoTaller, VP_OrdenTrabajo.TipoTrabajo, 
--                                             VP_OrdenTrabajo.Detalle, VP_OrdenTrabajo.DESCRIPCION, VP_OrdenTrabajo.Dominio, VP_OrdenTrabajo.Marca, VP_OrdenTrabajo.Modelo, 
--                                             VP_OrdenTrabajo.Submodelo, VP_OrdenTrabajo.Motor, VP_OrdenTrabajo.NumeroChasis, VP_OrdenTrabajo.Kilometros, 
--                                             VP_OrdenTrabajo.Receptor, VP_OrdenTrabajo.CiudadCliente, VP_OrdenTrabajo.ProvinciaCliente, SUM(ISNULL(VP_OrdenTrabajo.Cantidad, 
--                                             0)) AS Cantidad, SUM(ISNULL(VP_OrdenTrabajo.TotalCosto, 0)) AS TotalCosto, SUM(ISNULL(VP_OrdenTrabajo.TotalDescuento, 0)) 
--                                             AS TotalDescuento, 0 AS TotalNetoRepuestos, 0 AS TotalNetoMOTerceros, SUM(ISNULL(VP_OrdenTrabajo.TotalNeto, 0)) 
--                                             AS TotalNetoMOPropia, 0 AS TotalFactura, fv.NOMBRE AS Factura, SUBSTRING(fv.FECHAACTUAL, 7, 2) + '/' + SUBSTRING(fv.FECHAACTUAL, 
--                                             5, 2) + '/' + SUBSTRING(fv.FECHAACTUAL, 1, 4) AS FechaFactura, VP_OrdenTrabajo.Sucursal, VP_OrdenTrabajo.Empresa, 
--                                             VP_OrdenTrabajo.TipoCliente, SUBSTRING(VP_OrdenTrabajo.Incidentes, 1, 255) AS Incidentes, VP_OrdenTrabajo.MesOT, 
--                                             VP_OrdenTrabajo.MesUltimoestado, VP_OrdenTrabajo.MesTurno, VP_OrdenTrabajo.CodigoPostal, VP_OrdenTrabajo.CALLE, 
--                                             VP_OrdenTrabajo.Celular, VP_OrdenTrabajo.TelefonoLaboral, VP_OrdenTrabajo.TelefonoParticular, VP_OrdenTrabajo.CargoOT, 
--                                             VP_OrdenTrabajo.FechaEjecucion, VP_OrdenTrabajo.FechaUltimoEstado, VP_OrdenTrabajo.impedimento AS Impedimento, 
--                                             VP_OrdenTrabajo.Email, cantfacturas.cant AS fac, cantnotasdecredito.cant AS nota, 
--                                             CASE WHEN cantfacturas.cant = cantnotasdecredito.cant THEN 'SI' ELSE 'NO' END AS Anulada, VP_OrdenTrabajo.TipoService, 
--                                             VP_OrdenTrabajo.AvisoCliente
--                       FROM         dbo.VP_OrdenTrabajo AS VP_OrdenTrabajo OUTER APPLY
--                                                 (SELECT     TOP 1 TROV.NUMERODOCUMENTO, tpp.TRANSACCION_ID, FV.NOMBRE, FV.VALORTOTAL, FV.FECHAACTUAL
--                                                   FROM          dbo.TRPROCESOPORLOTE AS tpp WITH (nolock) LEFT JOIN
--                                                                          dbo.AGENTEPROCESOPORLOTE AS app WITH (nolock) ON tpp.BO_PLACE_ID = app.TRSORIGEN_ID LEFT JOIN
--                                                                          dbo.TRFACTURAVENTA AS fv WITH (nolock) ON app.ID = fv.GENERADAPOR_ID AND FV.ESTADO <> 'N' LEFT JOIN
--                                                                          dbo.TRORDENVENTA AS TROV WITH (nolock) ON TPP.TRANSACCION_ID = TROV.ID
--                                                   WHERE      ((tpp.RELACION_ID IS NULL) OR
--                                                                          (tpp.RELACION_ID = '84F37DBB-911D-46C6-8645-92CEE27283D8') OR
--                                                                          (tpp.RELACION_ID = '596F22CD-7F97-4681-A154-15AB55FA1040')) AND TROV.ID = TPP.TRANSACCION_ID AND 
--                                                                          FV.ESTADO <> 'N' AND TROV.NUMERODOCUMENTO = VP_OrdenTrabajo.ORDENTRABAJO) AS FV LEFT JOIN
--                                                 (SELECT     TROV.NUMERODOCUMENTO, count(*) 
--                                                                          AS cant
--                                                   /*tpp.TRANSACCION_ID, FV.NOMBRE, FV.VALORTOTAL, FV.FECHAACTUAL*/ FROM dbo.TRPROCESOPORLOTE AS tpp WITH (nolock) LEFT 
--                                                                          JOIN
--                                                                          dbo.AGENTEPROCESOPORLOTE AS app WITH (nolock) ON tpp.BO_PLACE_ID = app.TRSORIGEN_ID LEFT JOIN
--                                                                          dbo.TRFACTURAVENTA AS fv WITH (nolock) ON app.ID = fv.GENERADAPOR_ID AND FV.ESTADO <> 'N' LEFT JOIN
--                                                                          dbo.TRORDENVENTA AS TROV WITH (nolock) ON TPP.TRANSACCION_ID = TROV.ID
--                                                   WHERE      ((tpp.RELACION_ID IS NULL) OR
--                                                                          (tpp.RELACION_ID = '84F37DBB-911D-46C6-8645-92CEE27283D8') OR
--                                                                          (tpp.RELACION_ID = '596F22CD-7F97-4681-A154-15AB55FA1040')) AND TROV.ID = TPP.TRANSACCION_ID AND 
--                                                                          FV.ESTADO <> 'N'
--                                                   GROUP BY TROV.NUMERODOCUMENTO) AS cantfacturas ON 
--                                             cantfacturas.NUMERODOCUMENTO = VP_OrdenTrabajo.ORDENTRABAJO LEFT JOIN
--                                                 (SELECT     TROV.NUMERODOCUMENTO, count(*) 
--                                                                          AS cant
--                                                   /*tpp.TRANSACCION_ID, FV.NOMBRE, FV.VALORTOTAL, FV.FECHAACTUAL*/ FROM dbo.TRPROCESOPORLOTE AS tpp WITH (nolock) LEFT 
--                                                                          JOIN
--                                                                          dbo.AGENTEPROCESOPORLOTE AS app WITH (nolock) ON tpp.BO_PLACE_ID = app.TRSORIGEN_ID LEFT JOIN
--                                                                          dbo.TRFACTURAVENTA AS fv WITH (nolock) ON app.ID = fv.GENERADAPOR_ID AND FV.ESTADO <> 'N' LEFT JOIN
--                                                                          trcreditoventa c WITH (nolock) ON c.vinculotr_id = fv.id LEFT JOIN
--                                                                          dbo.TRORDENVENTA AS TROV WITH (nolock) ON TPP.TRANSACCION_ID = TROV.ID
--                                                   WHERE      ((tpp.RELACION_ID IS NULL) OR
--                                                                          (tpp.RELACION_ID = '84F37DBB-911D-46C6-8645-92CEE27283D8') OR
--                                                                          (tpp.RELACION_ID = '596F22CD-7F97-4681-A154-15AB55FA1040')) AND TROV.ID = TPP.TRANSACCION_ID AND 
--                                                                          FV.ESTADO <> 'N' AND 
--                                                                          c.TIPOTRANSACCION_ID = '{FF5DA972-CD50-4FF6-B1DD-EE55647306B0}'
--                                                   /*order by trov.numerodocumento*/ GROUP BY TROV.NUMERODOCUMENTO) AS cantnotasdecredito ON 
--                                             cantnotasdecredito.NUMERODOCUMENTO = VP_OrdenTrabajo.ORDENTRABAJO
--                       WHERE     (VP_OrdenTrabajo.Tipo = 'Servicio') AND (VP_OrdenTrabajo.Rubro = '02 - Mano de Obra ')
--                       GROUP BY fv.NOMBRE, SUBSTRING(fv.FECHAACTUAL, 7, 2) + '/' + SUBSTRING(fv.FECHAACTUAL, 5, 2) + '/' + SUBSTRING(fv.FECHAACTUAL, 1, 4), 
--                                             VP_OrdenTrabajo.OrdenTrabajo, VP_OrdenTrabajo.Cliente, VP_OrdenTrabajo.FechaOT, VP_OrdenTrabajo.FechaFinalizada, 
--                                             VP_OrdenTrabajo.Estado, VP_OrdenTrabajo.FechaVentaVehiculo, VP_OrdenTrabajo.Fechaturno, VP_OrdenTrabajo.TelefonoContacto, 
--                                             VP_OrdenTrabajo.FechaFinGarantia, VP_OrdenTrabajo.Retira, VP_OrdenTrabajo.TipoTaller, VP_OrdenTrabajo.TipoTrabajo, 
--                                             VP_OrdenTrabajo.Detalle, VP_OrdenTrabajo.DESCRIPCION, VP_OrdenTrabajo.Dominio, VP_OrdenTrabajo.Marca, VP_OrdenTrabajo.Modelo, 
--                                             VP_OrdenTrabajo.Submodelo, VP_OrdenTrabajo.Motor, VP_OrdenTrabajo.NumeroChasis, VP_OrdenTrabajo.Kilometros, 
--                                             VP_OrdenTrabajo.Receptor, VP_OrdenTrabajo.CiudadCliente, VP_OrdenTrabajo.ProvinciaCliente, VP_OrdenTrabajo.Sucursal, 
--                                             VP_OrdenTrabajo.Empresa, VP_OrdenTrabajo.TipoCliente, SUBSTRING(VP_OrdenTrabajo.Incidentes, 1, 255), VP_OrdenTrabajo.MesOT, 
--                                             VP_OrdenTrabajo.MesUltimoestado, VP_OrdenTrabajo.MesTurno, VP_OrdenTrabajo.CodigoPostal, VP_OrdenTrabajo.CALLE, 
--                                             VP_OrdenTrabajo.Celular, VP_OrdenTrabajo.TelefonoLaboral, VP_OrdenTrabajo.TelefonoParticular, fv.VALORTOTAL, 
--                                             VP_OrdenTrabajo.CargoOT, VP_OrdenTrabajo.FechaEjecucion, VP_OrdenTrabajo.FechaUltimoEstado, VP_OrdenTrabajo.impedimento, 
--                                             VP_OrdenTrabajo.Email, cantfacturas.cant, cantnotasdecredito.cant, VP_OrdenTrabajo.TipoService, VP_OrdenTrabajo.AvisoCliente
--                       UNION ALL
--                       SELECT     VP_OrdenTrabajo.OrdenTrabajo, VP_OrdenTrabajo.Cliente, VP_OrdenTrabajo.FechaOT, VP_OrdenTrabajo.FechaFinalizada, 
--                                             VP_OrdenTrabajo.Estado, VP_OrdenTrabajo.FechaVentaVehiculo, VP_OrdenTrabajo.Fechaturno, VP_OrdenTrabajo.TelefonoContacto, 
--                                             VP_OrdenTrabajo.FechaFinGarantia, VP_OrdenTrabajo.Retira, VP_OrdenTrabajo.TipoTaller, VP_OrdenTrabajo.TipoTrabajo, 
--                                             VP_OrdenTrabajo.Detalle, VP_OrdenTrabajo.DESCRIPCION, VP_OrdenTrabajo.Dominio, VP_OrdenTrabajo.Marca, VP_OrdenTrabajo.Modelo, 
--                                             VP_OrdenTrabajo.Submodelo, VP_OrdenTrabajo.Motor, VP_OrdenTrabajo.NumeroChasis, VP_OrdenTrabajo.Kilometros, 
--                                             VP_OrdenTrabajo.Receptor, VP_OrdenTrabajo.CiudadCliente, VP_OrdenTrabajo.ProvinciaCliente, SUM(ISNULL(VP_OrdenTrabajo.Cantidad, 
--                                             0)) AS Cantidad, SUM(ISNULL(VP_OrdenTrabajo.TotalCosto, 0)) AS TotalCosto, SUM(ISNULL(VP_OrdenTrabajo.TotalDescuento, 0)) 
--                                             AS TotalDescuento, 0 AS TotalNetoRepuestos, SUM(ISNULL(VP_OrdenTrabajo.TotalNeto, 0)) AS TotalNetoMOTerceros, 
--                                             0 AS TotalNetoMOPropia, 0 AS TotalFactura, fv.NOMBRE AS Factura, SUBSTRING(fv.FECHAACTUAL, 7, 2) 
--                                             + '/' + SUBSTRING(fv.FECHAACTUAL, 5, 2) + '/' + SUBSTRING(fv.FECHAACTUAL, 1, 4) AS FechaFactura, VP_OrdenTrabajo.Sucursal, 
--                                             VP_OrdenTrabajo.Empresa, VP_OrdenTrabajo.TipoCliente, SUBSTRING(VP_OrdenTrabajo.Incidentes, 1, 255) AS Incidentes, 
--                                             VP_OrdenTrabajo.MesOT, VP_OrdenTrabajo.MesUltimoestado, VP_OrdenTrabajo.MesTurno, VP_OrdenTrabajo.CodigoPostal, 
--                                             VP_OrdenTrabajo.CALLE, VP_OrdenTrabajo.Celular, VP_OrdenTrabajo.TelefonoLaboral, VP_OrdenTrabajo.TelefonoParticular, 
--                                             VP_OrdenTrabajo.CargoOT, VP_OrdenTrabajo.FechaEjecucion, VP_OrdenTrabajo.FechaUltimoEstado, 
--                                             VP_OrdenTrabajo.impedimento AS Impedimento, VP_OrdenTrabajo.Email, cantfacturas.cant AS fac, cantnotasdecredito.cant AS nota, 
--                                             CASE WHEN cantfacturas.cant = cantnotasdecredito.cant THEN 'SI' ELSE 'NO' END AS Anulada, VP_OrdenTrabajo.TipoService, 
--                                             VP_OrdenTrabajo.AvisoCliente
--                       FROM         dbo.VP_OrdenTrabajo AS VP_OrdenTrabajo OUTER APPLY
--                                                 (SELECT     TOP 1 TROV.NUMERODOCUMENTO, tpp.TRANSACCION_ID, FV.NOMBRE, FV.VALORTOTAL, FV.FECHAACTUAL
--                                                   FROM          dbo.TRPROCESOPORLOTE AS tpp WITH (nolock) LEFT JOIN
--                                                                          dbo.AGENTEPROCESOPORLOTE AS app WITH (nolock) ON tpp.BO_PLACE_ID = app.TRSORIGEN_ID LEFT JOIN
--                                                                          dbo.TRFACTURAVENTA AS fv WITH (nolock) ON app.ID = fv.GENERADAPOR_ID AND FV.ESTADO <> 'N' LEFT JOIN
--                                                                          dbo.TRORDENVENTA AS TROV WITH (nolock) ON TPP.TRANSACCION_ID = TROV.ID
--                                                   WHERE      ((tpp.RELACION_ID IS NULL) OR
--                                                                          (tpp.RELACION_ID = '84F37DBB-911D-46C6-8645-92CEE27283D8') OR
--                                                                          (tpp.RELACION_ID = '596F22CD-7F97-4681-A154-15AB55FA1040')) AND TROV.ID = TPP.TRANSACCION_ID AND 
--                                                                          FV.ESTADO <> 'N' AND TROV.NUMERODOCUMENTO = VP_OrdenTrabajo.ORDENTRABAJO) AS FV LEFT JOIN
--                                                 (SELECT     TROV.NUMERODOCUMENTO, count(*) 
--                                                                          AS cant
--                                                   /*tpp.TRANSACCION_ID, FV.NOMBRE, FV.VALORTOTAL, FV.FECHAACTUAL*/ FROM dbo.TRPROCESOPORLOTE AS tpp WITH (nolock) LEFT 
--                                                                          JOIN
--                                                                          dbo.AGENTEPROCESOPORLOTE AS app WITH (nolock) ON tpp.BO_PLACE_ID = app.TRSORIGEN_ID LEFT JOIN
--                                                                          dbo.TRFACTURAVENTA AS fv WITH (nolock) ON app.ID = fv.GENERADAPOR_ID AND FV.ESTADO <> 'N' LEFT JOIN
--                                                                          dbo.TRORDENVENTA AS TROV WITH (nolock) ON TPP.TRANSACCION_ID = TROV.ID
--                                                   WHERE      ((tpp.RELACION_ID IS NULL) OR
--                                                                          (tpp.RELACION_ID = '84F37DBB-911D-46C6-8645-92CEE27283D8') OR
--                                                                          (tpp.RELACION_ID = '596F22CD-7F97-4681-A154-15AB55FA1040')) AND TROV.ID = TPP.TRANSACCION_ID AND 
--                                                                          FV.ESTADO <> 'N'
--                                                   GROUP BY TROV.NUMERODOCUMENTO) AS cantfacturas ON 
--                                             cantfacturas.NUMERODOCUMENTO = VP_OrdenTrabajo.ORDENTRABAJO LEFT JOIN
--                                                 (SELECT     TROV.NUMERODOCUMENTO, count(*) 
--                                                                          AS cant
--                                                   /*tpp.TRANSACCION_ID, FV.NOMBRE, FV.VALORTOTAL, FV.FECHAACTUAL*/ FROM dbo.TRPROCESOPORLOTE AS tpp WITH (nolock) LEFT 
--                                                                          JOIN
--                                                                          dbo.AGENTEPROCESOPORLOTE AS app WITH (nolock) ON tpp.BO_PLACE_ID = app.TRSORIGEN_ID LEFT JOIN
--                                                                          dbo.TRFACTURAVENTA AS fv WITH (nolock) ON app.ID = fv.GENERADAPOR_ID AND FV.ESTADO <> 'N' LEFT JOIN
--                                                                          trcreditoventa c WITH (nolock) ON c.vinculotr_id = fv.id LEFT JOIN
--                                                                          dbo.TRORDENVENTA AS TROV WITH (nolock) ON TPP.TRANSACCION_ID = TROV.ID
--                                                   WHERE      ((tpp.RELACION_ID IS NULL) OR
--                                                                          (tpp.RELACION_ID = '84F37DBB-911D-46C6-8645-92CEE27283D8') OR
--                                                                          (tpp.RELACION_ID = '596F22CD-7F97-4681-A154-15AB55FA1040')) AND TROV.ID = TPP.TRANSACCION_ID AND 
--                                                                          FV.ESTADO <> 'N' AND 
--                                                                          c.TIPOTRANSACCION_ID = '{FF5DA972-CD50-4FF6-B1DD-EE55647306B0}'
--                                                   /*order by trov.numerodocumento*/ GROUP BY TROV.NUMERODOCUMENTO) AS cantnotasdecredito ON 
--                                             cantnotasdecredito.NUMERODOCUMENTO = VP_OrdenTrabajo.ORDENTRABAJO
--                       WHERE     (VP_OrdenTrabajo.Tipo = 'Servicio') AND (VP_OrdenTrabajo.Rubro = '03 - Trabajos de Terceros')
--                       GROUP BY fv.NOMBRE, SUBSTRING(fv.FECHAACTUAL, 7, 2) + '/' + SUBSTRING(fv.FECHAACTUAL, 5, 2) + '/' + SUBSTRING(fv.FECHAACTUAL, 1, 4), 
--                                             VP_OrdenTrabajo.OrdenTrabajo, VP_OrdenTrabajo.Cliente, VP_OrdenTrabajo.FechaOT, VP_OrdenTrabajo.FechaFinalizada, 
--                                             VP_OrdenTrabajo.Estado, VP_OrdenTrabajo.FechaVentaVehiculo, VP_OrdenTrabajo.Fechaturno, VP_OrdenTrabajo.TelefonoContacto, 
--                                             VP_OrdenTrabajo.FechaFinGarantia, VP_OrdenTrabajo.Retira, VP_OrdenTrabajo.TipoTaller, VP_OrdenTrabajo.TipoTrabajo, 
--                                             VP_OrdenTrabajo.Detalle, VP_OrdenTrabajo.DESCRIPCION, VP_OrdenTrabajo.Dominio, VP_OrdenTrabajo.Marca, VP_OrdenTrabajo.Modelo, 
--                                             VP_OrdenTrabajo.Submodelo, VP_OrdenTrabajo.Motor, VP_OrdenTrabajo.NumeroChasis, VP_OrdenTrabajo.Kilometros, 
--                                             VP_OrdenTrabajo.Receptor, VP_OrdenTrabajo.CiudadCliente, VP_OrdenTrabajo.ProvinciaCliente, VP_OrdenTrabajo.Sucursal, 
--                                             VP_OrdenTrabajo.Empresa, VP_OrdenTrabajo.TipoCliente, SUBSTRING(VP_OrdenTrabajo.Incidentes, 1, 255), VP_OrdenTrabajo.MesOT, 
--                                             VP_OrdenTrabajo.MesUltimoestado, VP_OrdenTrabajo.MesTurno, VP_OrdenTrabajo.CodigoPostal, VP_OrdenTrabajo.CALLE, 
--                                             VP_OrdenTrabajo.Celular, VP_OrdenTrabajo.TelefonoLaboral, VP_OrdenTrabajo.TelefonoParticular, fv.VALORTOTAL, 
--                                             VP_OrdenTrabajo.CargoOT, VP_OrdenTrabajo.FechaEjecucion, VP_OrdenTrabajo.FechaUltimoEstado, VP_OrdenTrabajo.impedimento, 
--                                             VP_OrdenTrabajo.Email, cantfacturas.cant, cantnotasdecredito.cant, VP_OrdenTrabajo.TipoService, VP_OrdenTrabajo.AvisoCliente
--                       UNION ALL
--                       SELECT     VP_OrdenTrabajo.OrdenTrabajo, VP_OrdenTrabajo.Cliente, VP_OrdenTrabajo.FechaOT, VP_OrdenTrabajo.FechaFinalizada, 
--                                             VP_OrdenTrabajo.Estado, VP_OrdenTrabajo.FechaVentaVehiculo, VP_OrdenTrabajo.Fechaturno, VP_OrdenTrabajo.TelefonoContacto, 
--                                             VP_OrdenTrabajo.FechaFinGarantia, VP_OrdenTrabajo.Retira, VP_OrdenTrabajo.TipoTaller, VP_OrdenTrabajo.TipoTrabajo, 
--                                             VP_OrdenTrabajo.Detalle, VP_OrdenTrabajo.DESCRIPCION, VP_OrdenTrabajo.Dominio, VP_OrdenTrabajo.Marca, VP_OrdenTrabajo.Modelo, 
--                                             VP_OrdenTrabajo.Submodelo, VP_OrdenTrabajo.Motor, VP_OrdenTrabajo.NumeroChasis, VP_OrdenTrabajo.Kilometros, 
--                                             VP_OrdenTrabajo.Receptor, VP_OrdenTrabajo.CiudadCliente, VP_OrdenTrabajo.ProvinciaCliente, SUM(ISNULL(VP_OrdenTrabajo.Cantidad, 
--                                             0)) AS 'Cantidad', 0 AS 'TotalCosto', SUM(ISNULL(VP_OrdenTrabajo.TotalDescuento, 0)) AS 'TotalDescuento', 0 AS 'TotalNetoRepuestos', 
--                                             0 AS 'TotalNetoMOTerceros', 0 AS 'TotalNetoMOPropia', 0 AS TotalFactura, fv.NOMBRE AS Factura, SUBSTRING(fv.FECHAACTUAL, 7, 2) 
--                                             + '/' + SUBSTRING(fv.FECHAACTUAL, 5, 2) + '/' + SUBSTRING(fv.FECHAACTUAL, 1, 4) AS FechaFactura, VP_OrdenTrabajo.Sucursal, 
--                                             VP_OrdenTrabajo.Empresa, VP_OrdenTrabajo.TipoCliente, SUBSTRING(VP_OrdenTrabajo.Incidentes, 1, 255) AS Incidentes, 
--                                             VP_OrdenTrabajo.MesOT, VP_OrdenTrabajo.MesUltimoestado, VP_OrdenTrabajo.MesTurno, VP_OrdenTrabajo.CodigoPostal, 
--                                             VP_OrdenTrabajo.CALLE, VP_OrdenTrabajo.Celular, VP_OrdenTrabajo.TelefonoLaboral, VP_OrdenTrabajo.TelefonoParticular, 
--                                             VP_OrdenTrabajo.CargoOT, VP_OrdenTrabajo.FechaEjecucion, VP_OrdenTrabajo.FechaUltimoEstado, 
--                                             VP_OrdenTrabajo.impedimento AS Impedimento, VP_OrdenTrabajo.Email, cantfacturas.cant AS fac, cantnotasdecredito.cant AS nota, 
--                                             CASE WHEN cantfacturas.cant = cantnotasdecredito.cant THEN 'SI' ELSE 'NO' END AS Anulada, VP_OrdenTrabajo.TipoService, 
--                                             VP_OrdenTrabajo.AvisoCliente
--                       FROM         dbo.VP_OrdenTrabajo AS VP_OrdenTrabajo OUTER APPLY
--                                                 (SELECT     TOP 1 TROV.NUMERODOCUMENTO, tpp.TRANSACCION_ID, FV.NOMBRE, FV.VALORTOTAL, FV.FECHAACTUAL
--                                                   FROM          dbo.TRPROCESOPORLOTE AS tpp WITH (nolock) LEFT JOIN
--                                                                          dbo.AGENTEPROCESOPORLOTE AS app WITH (nolock) ON tpp.BO_PLACE_ID = app.TRSORIGEN_ID LEFT JOIN
--                                                                          dbo.TRFACTURAVENTA AS fv WITH (nolock) ON app.ID = fv.GENERADAPOR_ID AND FV.ESTADO <> 'N' LEFT JOIN
--                                                                          dbo.TRORDENVENTA AS TROV WITH (nolock) ON TPP.TRANSACCION_ID = TROV.ID
--                                                   WHERE      ((tpp.RELACION_ID IS NULL) OR
--                                                                          (tpp.RELACION_ID = '84F37DBB-911D-46C6-8645-92CEE27283D8') OR
--                                                                          (tpp.RELACION_ID = '596F22CD-7F97-4681-A154-15AB55FA1040')) AND TROV.ID = TPP.TRANSACCION_ID AND 
--                                                                          FV.ESTADO <> 'N' AND TROV.NUMERODOCUMENTO = VP_OrdenTrabajo.ORDENTRABAJO) AS FV LEFT JOIN
--                                                 (SELECT     TROV.NUMERODOCUMENTO, count(*) 
--                                                                          AS cant
--                                                   /*tpp.TRANSACCION_ID, FV.NOMBRE, FV.VALORTOTAL, FV.FECHAACTUAL*/ FROM dbo.TRPROCESOPORLOTE AS tpp WITH (nolock) LEFT 
--                                                                          JOIN
--                                                                          dbo.AGENTEPROCESOPORLOTE AS app WITH (nolock) ON tpp.BO_PLACE_ID = app.TRSORIGEN_ID LEFT JOIN
--                                                                          dbo.TRFACTURAVENTA AS fv WITH (nolock) ON app.ID = fv.GENERADAPOR_ID AND FV.ESTADO <> 'N' LEFT JOIN
--                                                                          dbo.TRORDENVENTA AS TROV WITH (nolock) ON TPP.TRANSACCION_ID = TROV.ID
--                                                   WHERE      ((tpp.RELACION_ID IS NULL) OR
--                                                                          (tpp.RELACION_ID = '84F37DBB-911D-46C6-8645-92CEE27283D8') OR
--                                                                          (tpp.RELACION_ID = '596F22CD-7F97-4681-A154-15AB55FA1040')) AND TROV.ID = TPP.TRANSACCION_ID AND 
--                                                                          FV.ESTADO <> 'N'
--                                                   GROUP BY TROV.NUMERODOCUMENTO) AS cantfacturas ON 
--													cantfacturas.NUMERODOCUMENTO = VP_OrdenTrabajo.ORDENTRABAJO LEFT JOIN
--                                                 (SELECT     TROV.NUMERODOCUMENTO, count(*) 
--                                                                          AS cant
--                                                   /*tpp.TRANSACCION_ID, FV.NOMBRE, FV.VALORTOTAL, FV.FECHAACTUAL*/ FROM dbo.TRPROCESOPORLOTE AS tpp WITH (nolock) LEFT 
--                                                                          JOIN
--                                                                          dbo.AGENTEPROCESOPORLOTE AS app WITH (nolock) ON tpp.BO_PLACE_ID = app.TRSORIGEN_ID LEFT JOIN
--                                                                          dbo.TRFACTURAVENTA AS fv WITH (nolock) ON app.ID = fv.GENERADAPOR_ID AND FV.ESTADO <> 'N' LEFT JOIN
--                                                                          trcreditoventa c WITH (nolock) ON c.vinculotr_id = fv.id LEFT JOIN
--                                                                          dbo.TRORDENVENTA AS TROV WITH (nolock) ON TPP.TRANSACCION_ID = TROV.ID
--                                                   WHERE      ((tpp.RELACION_ID IS NULL) OR
--                                                                          (tpp.RELACION_ID = '84F37DBB-911D-46C6-8645-92CEE27283D8') OR
--                                                                          (tpp.RELACION_ID = '596F22CD-7F97-4681-A154-15AB55FA1040')) AND TROV.ID = TPP.TRANSACCION_ID AND 
--                                                                          FV.ESTADO <> 'N' AND 
--                                                                          c.TIPOTRANSACCION_ID = '{FF5DA972-CD50-4FF6-B1DD-EE55647306B0}'
--                                                   /*order by trov.numerodocumento*/ GROUP BY TROV.NUMERODOCUMENTO) AS cantnotasdecredito ON 
--                                             cantnotasdecredito.NUMERODOCUMENTO = VP_OrdenTrabajo.ORDENTRABAJO
--                       GROUP BY fv.NOMBRE, SUBSTRING(fv.FECHAACTUAL, 7, 2) + '/' + SUBSTRING(fv.FECHAACTUAL, 5, 2) + '/' + SUBSTRING(fv.FECHAACTUAL, 1, 4), 
--                                             VP_OrdenTrabajo.OrdenTrabajo, VP_OrdenTrabajo.Cliente, VP_OrdenTrabajo.FechaOT, VP_OrdenTrabajo.FechaFinalizada, 
--                                             VP_OrdenTrabajo.Estado, VP_OrdenTrabajo.FechaVentaVehiculo, VP_OrdenTrabajo.Fechaturno, VP_OrdenTrabajo.TelefonoContacto, 
--                                             VP_OrdenTrabajo.FechaFinGarantia, VP_OrdenTrabajo.Retira, VP_OrdenTrabajo.TipoTaller, VP_OrdenTrabajo.TipoTrabajo, 
--                                             VP_OrdenTrabajo.Detalle, VP_OrdenTrabajo.DESCRIPCION, VP_OrdenTrabajo.Dominio, VP_OrdenTrabajo.Marca, VP_OrdenTrabajo.Modelo, 
--                                             VP_OrdenTrabajo.Submodelo, VP_OrdenTrabajo.Motor, VP_OrdenTrabajo.NumeroChasis, VP_OrdenTrabajo.Kilometros, 
--                                             VP_OrdenTrabajo.Receptor, VP_OrdenTrabajo.CiudadCliente, VP_OrdenTrabajo.ProvinciaCliente, VP_OrdenTrabajo.Sucursal, 
--                                             VP_OrdenTrabajo.Empresa, VP_OrdenTrabajo.TipoCliente, SUBSTRING(VP_OrdenTrabajo.Incidentes, 1, 255), VP_OrdenTrabajo.MesOT, 
--                                             VP_OrdenTrabajo.MesUltimoestado, VP_OrdenTrabajo.MesTurno, VP_OrdenTrabajo.CodigoPostal, VP_OrdenTrabajo.CALLE, 
--                                             VP_OrdenTrabajo.Celular, VP_OrdenTrabajo.TelefonoLaboral, VP_OrdenTrabajo.TelefonoParticular, fv.VALORTOTAL, 
--                                             VP_OrdenTrabajo.CargoOT, VP_OrdenTrabajo.FechaEjecucion, VP_OrdenTrabajo.FechaUltimoEstado, VP_OrdenTrabajo.impedimento, 
--                                             VP_OrdenTrabajo.Email, cantfacturas.cant, cantnotasdecredito.cant, VP_OrdenTrabajo.TipoService, VP_OrdenTrabajo.AvisoCliente) 
--                      AS q
--WHERE OrdenTrabajo = 19832
--GROUP BY Empresa, Sucursal, TipoTaller, OrdenTrabajo, Fechaturno, FechaOT, FechaEjecucion, FechaFinalizada, Estado, Impedimento, Receptor, Cliente, 
--                      Modelo, Submodelo, NumeroChasis, Dominio, Kilometros, TipoTrabajo, Incidentes, TelefonoContacto, Celular, TelefonoParticular, TelefonoLaboral, 
--                      Factura, FechaFactura, CargoOT, TipoCliente, CALLE, CiudadCliente, CodigoPostal, ProvinciaCliente, Marca, Detalle, DESCRIPCION, Motor, 
--                      FechaVentaVehiculo, FechaFinGarantia, Retira, FechaUltimoEstado, Email, MesOT, MesUltimoestado, MesTurno, Anulada, TipoService, AvisoCliente
