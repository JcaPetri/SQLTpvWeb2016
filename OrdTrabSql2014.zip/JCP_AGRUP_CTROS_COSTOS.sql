SELECT [OT010_OT_ID], CASE WHEN SUBSTRING([OT_CtroCto],LEN([OT_CtroCto]),1) = ' / ' THEN
								LEFT([OT_CtroCto], LEN([OT_CtroCto])-1)
								ELSE [OT_CtroCto]
						  END  AS [OT_CtroCto]
					 FROM (
								SELECT [OT010_OT_ID], CASE WHEN [CtoCod01] IS NULL THEN '' ELSE [CtoCod01] + ' / ' END + 
															CASE WHEN [CtoCod02] IS NULL THEN '' ELSE [CtoCod02] + ' / ' END + 
															CASE WHEN [CtoCod03] IS NULL THEN '' ELSE [CtoCod03] + ' / ' END + 
															CASE WHEN [CtoCod04] IS NULL THEN '' ELSE [CtoCod04] + ' / ' END + 
															CASE WHEN [CtoCod05] IS NULL THEN '' ELSE [CtoCod05] + ' / ' END + 
															CASE WHEN [CtoCod06] IS NULL THEN '' ELSE [CtoCod06] + ' / ' END + 
															CASE WHEN [CtoCod07] IS NULL THEN '' ELSE [CtoCod07] + ' / ' END + 
															CASE WHEN [CtoCod08] IS NULL THEN '' ELSE [CtoCod08] + ' / ' END + 
															CASE WHEN [CtoCod09] IS NULL THEN '' ELSE [CtoCod09] + ' / ' END + 
															CASE WHEN [CtoCod10] IS NULL THEN '' ELSE [CtoCod10] + ' / ' END + 

															CASE WHEN [CtoCod11] IS NULL THEN '' ELSE [CtoCod11] + ' / ' END + 
															CASE WHEN [CtoCod12] IS NULL THEN '' ELSE [CtoCod12] + ' / ' END + 
															CASE WHEN [CtoCod13] IS NULL THEN '' ELSE [CtoCod13] + ' / ' END + 
															CASE WHEN [CtoCod14] IS NULL THEN '' ELSE [CtoCod14] + ' / ' END + 
															CASE WHEN [CtoCod15] IS NULL THEN '' ELSE [CtoCod15] + ' / ' END + 
															CASE WHEN [CtoCod16] IS NULL THEN '' ELSE [CtoCod16] + ' / ' END + 
															CASE WHEN [CtoCod17] IS NULL THEN '' ELSE [CtoCod17] + ' / ' END + 
															CASE WHEN [CtoCod18] IS NULL THEN '' ELSE [CtoCod18] + ' / ' END + 
															CASE WHEN [CtoCod19] IS NULL THEN '' ELSE [CtoCod19] + ' / ' END + 
															CASE WHEN [CtoCod20] IS NULL THEN '' ELSE [CtoCod20] + ' / ' END + 

															CASE WHEN [CtoCod21] IS NULL THEN '' ELSE [CtoCod21] + ' / ' END + 
															CASE WHEN [CtoCod22] IS NULL THEN '' ELSE [CtoCod22] + ' / ' END + 
															CASE WHEN [CtoCod23] IS NULL THEN '' ELSE [CtoCod23] + ' / ' END + 
															CASE WHEN [CtoCod24] IS NULL THEN '' ELSE [CtoCod24] + ' / ' END + 
															CASE WHEN [CtoCod25] IS NULL THEN '' ELSE [CtoCod25] + ' / ' END + 
															CASE WHEN [CtoCod26] IS NULL THEN '' ELSE [CtoCod26] + ' / ' END + 
															CASE WHEN [CtoCod27] IS NULL THEN '' ELSE [CtoCod27] + ' / ' END + 
															CASE WHEN [CtoCod28] IS NULL THEN '' ELSE [CtoCod28] + ' / ' END + 
															CASE WHEN [CtoCod29] IS NULL THEN '' ELSE [CtoCod29] + ' / ' END + 
															CASE WHEN [CtoCod30] IS NULL THEN '' ELSE [CtoCod30] + ' / ' END + 

															CASE WHEN [CtoCod31] IS NULL THEN '' ELSE [CtoCod31] + ' / ' END + 
															CASE WHEN [CtoCod32] IS NULL THEN '' ELSE [CtoCod32] + ' / ' END + 
															CASE WHEN [CtoCod33] IS NULL THEN '' ELSE [CtoCod33] + ' / ' END + 
															CASE WHEN [CtoCod34] IS NULL THEN '' ELSE [CtoCod34] + ' / ' END + 
															CASE WHEN [CtoCod35] IS NULL THEN '' ELSE [CtoCod35] + ' / ' END + 
															CASE WHEN [CtoCod36] IS NULL THEN '' ELSE [CtoCod36] + ' / ' END + 
															CASE WHEN [CtoCod37] IS NULL THEN '' ELSE [CtoCod37] + ' / ' END + 
															CASE WHEN [CtoCod38] IS NULL THEN '' ELSE [CtoCod38] 
													  END  AS [OT_CtroCto]
														, CANT
								FROM (
										SELECT [OT010_OT_ID]
												, MIN(CASE WHEN [OT010_OT_CCTOCOD] IS NULL THEN 'A DEF' END) AS [CtoCod01]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '1110600' THEN '1110600' + '-' + [GRL030_DESCABR]  END) AS [CtoCod02]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '1110400' THEN '1110400' + '-' + [GRL030_DESCABR] END) AS [CtoCod03]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '2020105' THEN '2020105' + '-' + [GRL030_DESCABR] END) AS [CtoCod04]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '1110100' THEN '1110100' + '-' + [GRL030_DESCABR] END) AS [CtoCod05]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '2020101' THEN '2020101' + '-' + [GRL030_DESCABR] END) AS [CtoCod06]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '4030105' THEN '4030105' + '-' + [GRL030_DESCABR] END) AS [CtoCod07]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '4030101' THEN '4030101' + '-' + [GRL030_DESCABR] END) AS [CtoCod08]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '1120600' THEN '1120600' + '-' + [GRL030_DESCABR] END) AS [CtoCod09]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '2020103' THEN '2020103' + '-' + [GRL030_DESCABR] END) AS [CtoCod10]

												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '1130600' THEN '1130600' + '-' + [GRL030_DESCABR] END) AS [CtoCod11]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '2020109' THEN '2020109' + '-' + [GRL030_DESCABR] END) AS [CtoCod12]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '1120400' THEN '1120400' + '-' + [GRL030_DESCABR] END) AS [CtoCod13]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '2020110' THEN '2020110' + '-' + [GRL030_DESCABR] END) AS [CtoCod14]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '2020106' THEN '2020106' + '-' + [GRL030_DESCABR] END) AS [CtoCod15]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '1130400' THEN '1130400' + '-' + [GRL030_DESCABR] END) AS [CtoCod16]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '1120100' THEN '1120100' + '-' + [GRL030_DESCABR] END) AS [CtoCod17]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '2020405' THEN '2020405' + '-' + [GRL030_DESCABR] END) AS [CtoCod18]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '1110300' THEN '1110300' + '-' + [GRL030_DESCABR] END) AS [CtoCod19]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '1130100' THEN '1130100' + '-' + [GRL030_DESCABR] END) AS [CtoCod20]

												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '2020401' THEN '2020401' + '-' + [GRL030_DESCABR] END) AS [CtoCod21]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '2020705' THEN '2020705' + '-' + [GRL030_DESCABR] END) AS [CtoCod22]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '2020406' THEN '2020406' + '-' + [GRL030_DESCABR] END) AS [CtoCod23]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '2020102' THEN '2020102' + '-' + [GRL030_DESCABR] END) AS [CtoCod24]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '2020701' THEN '2020701' + '-' + [GRL030_DESCABR] END) AS [CtoCod25]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '1120300' THEN '1120300' + '-' + [GRL030_DESCABR] END) AS [CtoCod26]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '4030102' THEN '4030102' + '-' + [GRL030_DESCABR] END) AS [CtoCod27]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '2020104' THEN '2020104' + '-' + [GRL030_DESCABR] END) AS [CtoCod28]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '2020403' THEN '2020403' + '-' + [GRL030_DESCABR] END) AS [CtoCod29]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '1130300' THEN '1130300' + '-' + [GRL030_DESCABR] END) AS [CtoCod30]

												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '4030405' THEN '4030405' + '-' + [GRL030_DESCABR] END) AS [CtoCod31]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '4030104' THEN '4030104' + '-' + [GRL030_DESCABR] END) AS [CtoCod32]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '4030109' THEN '4030109' + '-' + [GRL030_DESCABR] END) AS [CtoCod33]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '2020402' THEN '2020402' + '-' + [GRL030_DESCABR] END) AS [CtoCod34]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '2021301' THEN '2021301' + '-' + [GRL030_DESCABR] END) AS [CtoCod35]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '2020409' THEN '2020409' + '-' + [GRL030_DESCABR] END) AS [CtoCod36]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '1110900' THEN '1110900' + '-' + [GRL030_DESCABR] END) AS [CtoCod37]
												, MIN(CASE [OT010_OT_CCTOCOD] WHEN '1110500' THEN '1110500' + '-' + [GRL030_DESCABR] END) AS [CtoCod38]

												, COUNT(*) AS CANT
										  FROM [PVTWEB].[dbo].[OT010_OTDET] AS OTD WITH(NOLOCK)
												LEFT OUTER JOIN 
																(SELECT [GRL030_CODIGO]
																	  ,[GRL030_DESCRIPC]
																	  ,[GRL030_DESCABR]
																	  ,[GRL030_ABRTIPO]
																	  ,[GRL030_AGR01]
																  FROM [PVTWEB].[dbo].[GRL030_ABRDESC] WITH(NOLOCK)
																) AS ABR ON
															OTD.[OT010_OT_CCTOCOD] = ABR.[GRL030_CODIGO]
--										  WHERE [OT010_OT_ID] = '6C6F7336-6B70-4898-B42D-A1F04A3554AA'
--											WHERE (LEFT([OT010_OT_CARGOITEM],4) <> 'Anul' AND LEFT([OT010_OT_CARGOITEM],4) <> 'Abie'
--													AND LEFT([OT010_OT_CARGOITEM],4) <> 'Ejec' AND LEFT([OT010_OT_CARGOITEM],4) <> 'Fina'
--													AND [OT010_OT_TIPTRAB] <> 'Mensual')
--												  AND [OT010_OT_SUCU] LIKE 'Tagle%'
								--		WHERE [OT010_OT_ID] = '0022B670-1205-47FC-B586-DE8D949749E9'
										--WHERE [OT010_OT_CCTOCOD] = '2020105'
										GROUP BY [OT010_OT_ID]
										--, [OT010_OT_CARGOGRAL]
								--		HAVING COUNT(*) > 1
								--		ORDER BY [OT010_OT_ID]
									) AS MIng
						) AS CtroCtos